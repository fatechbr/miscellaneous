/// <reference path="\Base\helpers.js" />

var VisitaCorporate = {
    OnLoad: function () {
        VisitaCorporate.ExibirProduto();
        VisitaCorporate.ExibirEscritorioBSP();
        VisitaCorporate.RecuperarEnderecoCliente();
        VisitaCorporate.RecuperarEnderecoBSP();
        VisitaCorporate.HabilitaCorretora();
        VisitaCorporate.SetaCamposDoReporteDaVisitaParaObrigatorio();

        VisitaCorporate.ConfiguracaoDeEventos();
    },

    ConfiguracaoDeEventos: function () {
        Xrm.Page.getAttribute("bso_cliente").addOnChange(VisitaCorporate.RecuperarEnderecoCliente);
        Xrm.Page.getAttribute("bso_local").addOnChange(VisitaCorporate.OnChange_bso_local);
        Xrm.Page.getAttribute("bso_escritoriobsp").addOnChange(VisitaCorporate.RecuperarEnderecoBSP);
        Xrm.Page.getAttribute("bso_participacaocorretor").addOnChange(VisitaCorporate.HabilitaCorretora);
        Xrm.Page.getAttribute("bso_aberturaparavenda").addOnChange(VisitaCorporate.ExibirProduto);
        Xrm.Page.getAttribute("bso_cep").addOnChange(VisitaCorporate.ExibirProduto);
        Xrm.Page.getAttribute("bso_cep").addOnChange(VisitaCorporate.OnChangeCEP);

        //Xrm.Page.data.entity.addOnSave(VisitaCorporate.AlertaCamposObrigatorios_ConclusaoVisita);
    },

    OnChangeCEP: function () {
        Helpers.PreencheEnderecoPorCEP("bso_cep", "bso_logradouro", "bso_numero", "bso_bairro", "bso_cidade", "bso_estado", null);
    },

    OnChange_bso_local: function () {
        VisitaCorporate.ExibirEscritorioBSP();
        VisitaCorporate.LimparCampoEndereco();
    },

    OcultarParticipacaoBradesco: function () {
        // Função não está mais sendo utilizada
        var Participacao = Xrm.Page.getAttribute("bso_participacaobanco");

        if (Participacao && Participacao.getValue()) {
            Xrm.Page.ui.tabs.get("tab_Participantes").sections.get("sectionParticipacaobsp").setVisible(true);
        }
        else {
            Xrm.Page.ui.tabs.get("tab_Participantes").sections.get("sectionParticipacaobsp").setVisible(false);
        }
    },

    OcultarParticipacaoCorretora: function () {
        // Função não está mais sendo utilizada
        var Participacao = Xrm.Page.getAttribute("bso_participacaocorretor");

        if (Participacao && Participacao.getValue()) {
            Xrm.Page.ui.tabs.get("tab_Participantes").sections.get("sectionParticipacaoCorretora").setVisible(true);
        }
        else {
            Xrm.Page.ui.tabs.get("tab_Participantes").sections.get("sectionParticipacaoCorretora").setVisible(false);
        }
    },

    HabilitaCorretora: function () {
        var ParticipacaoCorretora = Xrm.Page.getAttribute("bso_participacaocorretor").getValue();

        if (ParticipacaoCorretora == true) {
            Xrm.Page.ui.controls.get("bso_corretora").setVisible(true);
        }
        else {
            Xrm.Page.ui.controls.get("bso_corretora").setVisible(false);
        }
    },

    SalvarComo: function () {
        //criação do objeto de parametros a serem passados
        var parameters = {};

        // Campos da seção Informações Adicionais foram comentados pois os mesmos não devem ser preenchidos automaticamente
        // Elaine Tojal - 05/10/2016

        //atribuição de valores retirados da tela
        var Cliente = Xrm.Page.getAttribute("bso_cliente").getValue();
        var Assunto = Xrm.Page.getAttribute("subject").getValue();
        var Descricao = Xrm.Page.getAttribute("description").getValue();
        //var AberturaVenda = Xrm.Page.getAttribute("bso_aberturaparavenda").getValue();
        //var Motivo = Xrm.Page.getAttribute("bso_motivodavisita").getValue();
        //var Produtos = Xrm.Page.getAttribute("bso_produtos").getValue();
        //var Termometro = Xrm.Page.getAttribute("bso_termometrosatisfacao").getValue();
        //var PrincipaisPontos = Xrm.Page.getAttribute("bso_principaispontosdiscutidos").getValue();
        //var Pendencias = Xrm.Page.getAttribute("bso_pendenciaseproximospassos").getValue();
        var Local = Xrm.Page.getAttribute("bso_local").getValue();
        var Cep = Xrm.Page.getAttribute("bso_cep").getValue();
        //var Endereco = Xrm.Page.getAttribute("bso_endereco").getValue();
        var EscritorioBSP = Xrm.Page.getAttribute("bso_escritoriobsp").getValue();

        //atribuição de dados do cliente (campo consulta) nos parametros
        if (Cliente) {
            parameters["bso_cliente"] = Cliente[0].id;
            parameters["bso_clientename"] = Cliente[0].name;
        }

        if (Assunto != null)
            parameters["subject"] = Assunto;

        if (Descricao != null)
            parameters["description"] = Descricao;

        //if (AberturaVenda != null)
        //    parameters["bso_aberturaparavenda"] = AberturaVenda;

        //if (Motivo != null)
        //    parameters["bso_motivodavisita"] = Motivo;

        //if (Produtos != null)
        //    parameters["bso_produtos"] = Produtos;

        //if (Termometro != null)
        //    parameters["bso_termometrosatisfacao"] = Termometro;

        //if (PrincipaisPontos != null)
        //    parameters["bso_principaispontosdiscutidos"] = PrincipaisPontos;

        //if (Pendencias != null)
        //    parameters["bso_pendenciaseproximospassos"] = Pendencias;

        if (Local != null)
            parameters["bso_local"] = Local;

        if (Cep != null)
            parameters["bso_cep"] = Cep;

        //if (Endereco != null)
        //    parameters["bso_endereco"] = Endereco;

        // Atribuição de dados do Escritório BSP (Campo Consulta) nos parâmetros
        if (EscritorioBSP) {
            parameters["bso_escritoriobsp"] = EscritorioBSP[0].id;
            parameters["bso_escritoriobspname"] = EscritorioBSP[0].name;
        }

        //chama a nova janela pasando os parametros para os campos virem preenchidos
        Xrm.Utility.openEntityForm("bso_visitacorporate", null, parameters);
    },

    ExibirCep: function () {
        var Local = Xrm.Page.getAttribute("bso_local").getValue();

        if (Local && Local == 861500000 || Local && Local == 861500001) {
            Xrm.Page.ui.controls.get("bso_cep").setVisible(false);
        }
        else {
            Xrm.Page.ui.controls.get("bso_cep").setVisible(true);
        }
    },

    ExibirEscritorioBSP: function () {
        var Local = Xrm.Page.getAttribute("bso_local").getValue();

        if (Local && Local == 861500001) {
            Xrm.Page.ui.controls.get("bso_escritoriobsp").setVisible(true);
            //Xrm.Page.ui.controls.get("bso_cep").setVisible(false);
        }
        else {
            Xrm.Page.ui.controls.get("bso_escritoriobsp").setVisible(false);
        }
    },

    ExibirProduto: function () {
        var abertura = Xrm.Page.getAttribute("bso_aberturaparavenda").getValue();

        if (abertura) {
            Xrm.Page.ui.controls.get("bso_produtos").setVisible(true);
        }
        else {
            Xrm.Page.ui.controls.get("bso_produtos").setVisible(false);
        }
    },

    LimparCampoEndereco: function () {
        var Local = Xrm.Page.getAttribute("bso_local").getValue();
        var CEP = Xrm.Page.getAttribute("bso_cep").getValue();
        //var Endereco = Xrm.Page.getAttribute("bso_endereco").getValue();
        var EnderecoBsp = Xrm.Page.getAttribute("bso_escritoriobsp").getValue();
        var Cliente = Xrm.Page.data.entity.attributes.get("bso_cliente").getValue();

        Xrm.Page.getAttribute("bso_logradouro").setValue(null);
        Xrm.Page.getAttribute("bso_cidade").setValue(null);
        Xrm.Page.getAttribute("bso_estado").setValue(null);
        Xrm.Page.getAttribute("bso_cep").setValue(null);
        Xrm.Page.getAttribute("bso_numero").setValue(null);
        Xrm.Page.getAttribute("bso_bairro").setValue(null);
        Xrm.Page.getAttribute("bso_complemento").setValue(null);
        //Xrm.Page.getAttribute("bso_pais").setValue(null);

        if (Local && Local == 861500002 && CEP != null) {
            //Xrm.Page.getAttribute("bso_endereco").setValue(null);
            Xrm.Page.getAttribute("bso_escritoriobsp").setValue(null);//*
        }
        else if (Local && Local == 861500003 && EnderecoBsp != null) {
            Xrm.Page.getAttribute("bso_escritoriobsp").setValue(null);
            //Xrm.Page.getAttribute("bso_endereco").setValue(null);
        }
        else if (Local && Local == 861500000 && Cliente != null) {
            Xrm.Page.getAttribute("bso_escritoriobsp").setValue(null);//*
            VisitaCorporate.RecuperarEnderecoCliente();
        }
    },

    RecuperarEnderecoCliente: function () {
        var Cliente = Xrm.Page.data.entity.attributes.get("bso_cliente").getValue();
        var Local = Xrm.Page.getAttribute("bso_local").getValue();

        if (Cliente && Local && Local == 861500000) {
            var ID = Cliente[0].id.substr(1, 36);
            var query = "accounts?$select=address1_line1,address1_city,address1_stateorprovince,address1_postalcode,address1_country&$filter=accountid eq " + ID;
            var consulta = Helpers.Buscar(query);
            if (consulta.length > 0) {
                Xrm.Page.getAttribute("bso_logradouro").setValue(consulta[0]["address1_line1"]);
                Xrm.Page.getAttribute("bso_cidade").setValue(consulta[0]["address1_city"]);
                Xrm.Page.getAttribute("bso_estado").setValue(consulta[0]["address1_stateorprovince"]);
                Xrm.Page.getAttribute("bso_cep").setValue(consulta[0]["address1_postalcode"]);
               //Xrm.Page.getAttribute("bso_pais").setValue(consulta[0]["address1_country"]);
            }
        }
    },

    RecuperarEnderecoBSP: function () {
        var EscritorioBSP = Xrm.Page.getAttribute("bso_escritoriobsp").getValue();
        var Local = Xrm.Page.getAttribute("bso_local").getValue();

        if (EscritorioBSP && Local && Local == 861500001) {
            var ID = EscritorioBSP[0].id.substr(1, 36);
            var query = "sites?$select=address1_line1,address1_city,address1_stateorprovince,address1_postalcode,address1_country&$filter=siteid eq " + ID;

            var consulta = Helpers.Buscar(query);
            if (consulta.length > 0) {
                Xrm.Page.getAttribute("bso_logradouro").setValue(consulta[0]["address1_line1"]);
                Xrm.Page.getAttribute("bso_cidade").setValue(consulta[0]["address1_city"]);
                Xrm.Page.getAttribute("bso_estado").setValue(consulta[0]["address1_stateorprovince"]);
                Xrm.Page.getAttribute("bso_cep").setValue(consulta[0]["address1_postalcode"]);
                //Xrm.Page.getAttribute("bso_pais").setValue(consulta[0]["address1_country"]);
            }
        }
    },

    SetaCamposDoReporteDaVisitaParaObrigatorio: function () {

        var tipoForm = Xrm.Page.ui.getFormType();

        if (tipoForm == 2) {
            Xrm.Page.data.entity.attributes.get("bso_motivodavisita").setRequiredLevel("required");
            Xrm.Page.data.entity.attributes.get("bso_termometrosatisfacao").setRequiredLevel("required");
            Xrm.Page.data.entity.attributes.get("bso_principaispontosdiscutidos").setRequiredLevel("required");
        }

    },

    AlertaCamposObrigatorios_ConclusaoVisita: function () {

        var MotivoVisita = Xrm.Page.data.entity.attributes.get("bso_motivodavisita").getValue();
        var Termometro = Xrm.Page.data.entity.attributes.get("bso_termometrosatisfacao").getValue();
        var AberturaVenda = Xrm.Page.data.entity.attributes.get("bso_aberturaparavenda").getValue();
        var PontosDiscutidos = Xrm.Page.data.entity.attributes.get("bso_principaispontosdiscutidos").getValue();
        var contador = 0;

        if (MotivoVisita == null)
            contador++;
        if (Termometro == null)
            contador++;
        if (PontosDiscutidos == null)
            contador++;

        if (contador > 1) {
            alert("Você não pode concluir sem preencher o seu reporte da visita");
            return false;
        } else if (MotivoVisita == null) {
            alert("Reporte preenchido incorretamente, o campo Motivo da Visita deve estar preenchido para concluir esta Visita");
            return false;
        } else if (Termometro == null) {
            alert("Reporte preenchido incorretamente, o campo Termometro de Satisfação deve estar preenchido para concluir esta Visita.");
            return false;
        } else if (PontosDiscutidos == null) {
            alert("Reporte preenchido incorretamente, o campo Principais Pontos Discutidos deve estar preenchido para concluir esta Visita.");
            return false;
        } else {
            return true;
        }
    },

    //marcarcomoconcluida

    MarcarComoConcluida: function () {

        if (VisitaCorporate.AlertaCamposObrigatorios_ConclusaoVisita()) {
            Xrm.Page.data.save().then(function () {
                var visita = {};
                visita.statecode = 1;
                visita.statuscode = 2;
                var id = Xrm.Page.data.entity.getId().substr(1, 36);
                var query = "bso_visitacorporates(" + id + ")";
                var retorno = Helpers.Atualizar(query, visita);
                if (retorno == null)
                    Xrm.Page.data.refresh();
                else
                    alert("Não foi possível concluir esse visita. Favor verificar se os dados foram preenchidos corretamente e tente novamente.");
            }, function () {
                alert("Não foi possível concluir esta visita. Favor verificar se os dados foram preenchidos corretamente e tente novamente.")
            });
        }
    },

    MarcarComoCancelada: function () {
        var visita = {};
        visita.statecode = 2;
        visita.statuscode = 3;
        var id = Xrm.Page.data.entity.getId().substr(1, 36);
        var query = "bso_visitacorporates(" + id + ")";
        var retorno = Helpers.Atualizar(query, visita);
        if (retorno == null)
            Xrm.Page.data.refresh();
        else
            alert("Não foi possível cancelar esse compromisso. Favor verificar se os dados foram preenchidos corretamente e tente novamente.");
    }
}
