var PessoaJuridica = {
    OnLoad: function (context) {
        if (Xrm.Page.context.client.getClient() == "Mobile")
            return;
        Xrm.Page.getAttribute("telephone1").addOnChange(PessoaJuridica.OnChangeTelephone1);
        Xrm.Page.getAttribute("telephone3").addOnChange(PessoaJuridica.OnChangeTelephone3);
        Xrm.Page.getAttribute("fax").addOnChange(PessoaJuridica.OnChangeFax);



        debugger;


        //subgrid_mapeamento_concorrente
        PessoaJuridica.SetDisableSubgrid("subgrid_mapeamento_concorrente");
    },

    SetDisableSubgrid: function (gridName) {
        var contentFrame = window.top.document.getElementById("contentIFrame0")
        if (!contentFrame) {
            setTimeout(PessoaJuridica.SetDisableSubgrid.call(null, gridName), 1000);
        } else {
            var grid_span = contentFrame.contentWindow.document.getElementById(gridName + "_span");
            if (grid_span) {

                debugger;

                grid_span.disabled = "disabled";

                var div = document.createElement("div");
                div.style.position = "absolute";
                div.style.top = "0px";
                div.style.left ="0px";
                div.style.width = "100%";
                div.style.height = "100%";
                //div.style.background = "red";
                div.style.color = "white";
                div.style.opacity = "0.5";
                div.style.zIndex = "10000";

                grid_span.children[0].appendChild(div);
            }
        }
    },

    OnChangeTelephone1: function () {
        Helpers.Mascara("telephone1", "telefone");
    },

    OnChangeTelephone3: function () {
        Helpers.Mascara("telephone3", "telefone");
    },

    OnChangeFax: function () {
        Helpers.Mascara("fax", "telefone");
    },

    GerarImpressaoRelatorioPJ: function () {
        if (Xrm.Page.context.client.getClient() == "Mobile")
            return;

        var consulta = Helpers.Buscar("reports?$select=reportid,filename&$filter=name eq 'Relatorio Impressao de PJ'");

        if (consulta) {
            var UrlCompleta = parent.Xrm.Page.context.getClientUrl() +
                "/crmreports/viewer/viewer.aspx?action=run&context=records&helpID="
                + consulta[0].filename + "&id={" + consulta[0].reportid + "}&records="
                + Xrm.Page.data.entity.getId() + "&recordstype=1";

            window.open(UrlCompleta);
        }
    }
}