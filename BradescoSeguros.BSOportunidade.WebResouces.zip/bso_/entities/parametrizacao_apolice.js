ParametrizacaoApolice = function () {
    var formType = {
        Undefined: 0,
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        QuickCreate: 5,//Deprecated
        BulkEdit: 6,
        ReadOptimized: 11	//Deprecated
    };

    var tipoParametrizacao = {
        QuantidadeVidas: 1,
        Faturamento: 2,
        Frequencia: 3,
        Indicador: 4
    };

    //control of all fields
    var controlAllAttribute = function (attributesException) {

        //var attributesException = [
        //   { Name: "<<attributeName>>", Value: null, Disabled: false, Visible: false, SubmitMode: "dirty", RequiredLevel: "recommended" }
        //];

        if (attributesException != null && !Array.isArray(attributesException)) throw new Error("The 'attributesException' object is invalid.");

        Xrm.Page.data.entity.attributes.forEach(function (attribute, index) {

            var control = Xrm.Page.getControl(attribute.getName());

            if (control != null) {

                if (!control.getDisabled()) { control.setDisabled(true); }
                if (!control.getVisible()) { control.setVisible(false); }
                if (attribute.getSubmitMode() !== "never") { attribute.setSubmitMode("never"); }
                if (attribute.getRequiredLevel() !== "none") { attribute.setRequiredLevel("none"); }

                if (attributesException != null && attributesException.length > 0) {
                    for (var i in attributesException) {

                        var attributeException = attributesException[i];

                        if ((attributeException == null) || (attributeException != null && attributeException.Name === undefined)) {
                            if (window.console) console.log("The property 'Name' is required.");
                            continue;
                        } else {
                            if (!Xrm.Page.getControl(attributeException.Name)) {
                                if (window.console) console.log("The attribute '" + attributeException.Name + "' could not be found.");
                                continue;
                            }
                        }

                        if (attributeException.Name.toLowerCase() === attribute.getName().toLowerCase()) {

                            if (attributeException.Value !== undefined) {
                                attribute.setValue(attributeException.Value);
                            }

                            if (attributeException.Disabled !== undefined) {
                                if (attributeException.Disabled != null && (typeof (attributeException.Disabled) === "boolean")) {
                                    if (attributeException.Disabled != control.getDisabled()) {
                                        control.setDisabled(attributeException.Disabled);
                                    }
                                } else if (window.console) console.log("The attribute '" + attributeException.Name + "' is with property 'Disabled (" + attributeException.SubmitMode + ")' invalid.");
                            }

                            if (attributeException.Visible !== undefined) {
                                if (attributeException.Visible != null && (typeof (attributeException.Visible) === "boolean")) {
                                    if (attributeException.Visible != control.getVisible()) {
                                        control.setVisible(attributeException.Visible);
                                    }
                                } else if (window.console) console.log("The attribute '" + attributeException.Name + "' is with property 'Visible (" + attributeException.Visible + ")' invalid.");
                            }

                            if (attributeException.SubmitMode != null && (typeof (attributeException.SubmitMode) === "string")) {
                                switch (attributeException.SubmitMode) {
                                    case "always":
                                    case "never":
                                    case "dirty":
                                        if (attributeException.SubmitMode.toLowerCase() !== attribute.getSubmitMode().toLowerCase()) {
                                            attribute.setSubmitMode(attributeException.SubmitMode);
                                        }
                                        break;
                                    default:
                                        attribute.setSubmitMode("never");
                                        if (window.console) console.log("The attribute '" + attributeException.Name + "' is with property 'SubmitMode (" + attributeException.SubmitMode + ")' invalid.");
                                }
                            }

                            if (attributeException.RequiredLevel != null && (typeof (attributeException.RequiredLevel) === "string")) {
                                switch (attributeException.RequiredLevel) {
                                    case "none":
                                    case "required":
                                    case "recommended":
                                        if (attributeException.RequiredLevel.toLowerCase() !== attribute.getRequiredLevel().toLowerCase()) {
                                            attribute.setRequiredLevel(attributeException.RequiredLevel);
                                        }
                                        break;
                                    default:
                                        attribute.setRequiredLevel("none");
                                        if (window.console) console.log("The attribute '" + attributeException.Name + "' is with property 'RequiredLevel (" + attributeException.RequiredLevel + ")' invalid.");
                                }
                            }

                            continue;
                        }
                    }
                }
            }
        });
    };

    //control of all tabs and sections
    var controlAllBehavior = function (customBehavior) {
        debugger;
        //var tabs = [
        //   { Name: "<<tabName>>", IsVisible: false, DisplayState: "collapsed", 
        //      Sections: [
        //          { 
        //              Name: "<<sectionName>>", IsVisible: false, 
        //              Controls: [
        //                  { Name: "<<attributeName>>", Value: null, IsDisabled: false, IsVisible: false, SubmitMode: "dirty", RequiredLevel: "recommended" }
        //              ]
        //          }
        //      ]}
        //];

        if (customBehavior != null && !Array.isArray(customBehavior)) if (window.console) console.error("The object 'customBehavior' is invalid.");
        for (var t in Xrm.Page.ui.tabs.get()) {

            debugger;

            var tab = Xrm.Page.ui.tabs.get()[t];
            var foundTab = false;

            try {

                if (customBehavior != null && customBehavior.length > 0) {
                    for (var tt in customBehavior) {

                        var tabCustomBehavior = customBehavior[tt];

                        if (tabCustomBehavior.Name.toLowerCase() === tab.getName()) {

                            if (window.console) console.log("# Custom tab definition: " + tabCustomBehavior.Name);

                            if (window.console) console.log("# - Custom tab behavior:: Is visibled");
                            if (tabCustomBehavior.IsVisible !== undefined) {
                                if (tabCustomBehavior.IsVisible != null && (typeof (tabCustomBehavior.IsVisible) === "boolean")) {
                                    if (tabCustomBehavior.IsVisible != tab.getVisible()) {
                                        tab.setVisible(tabCustomBehavior.IsVisible);
                                    }
                                } else if (window.console) console.warn("In the 'IsVisible' property of the '" + tabCustomBehavior.Name + "' tab the value(" + tabCustomBehavior.IsVisible + ") is invalid.");
                            }

                            if (window.console) console.log("# - Custom tab behavior:: Display state");
                            if (tabCustomBehavior.DisplayState !== undefined) {
                                if (tabCustomBehavior.DisplayState != null && (typeof (tabCustomBehavior.DisplayState) === "string")) {
                                    switch (tabCustomBehavior.DisplayState) {
                                        case "expanded":
                                        case "collapsed":
                                            if (tabCustomBehavior.DisplayState.toLowerCase() !== tab.getDisplayState()) {
                                                tab.setDisplayState(tabCustomBehavior.DisplayState);
                                            }
                                            break;
                                        default:
                                            tab.setDisplayState("collapsed");
                                            if (window.console) console.log("In the 'DisplayState' property of the '" + tabCustomBehavior.Name + "' tab the value(" + tabCustomBehavior.DisplayState + ") is invalid.");
                                    }
                                } else if (window.console) console.log("In the 'DisplayState' property of the '" + tabCustomBehavior.Name + "' tab the value(" + tabCustomBehavior.DisplayState + ") is invalid.");
                            }

                            for (var s in tab.sections.get()) {

                                debugger;

                                var section = tab.sections.get()[s];
                                var foundSection = false;

                                if (tabCustomBehavior.Sections != null && tabCustomBehavior.Sections.length > 0) {
                                    for (var ss in tabCustomBehavior.Sections) {

                                        var sectionCustomBehavior = tabCustomBehavior.Sections[ss];

                                        if (sectionCustomBehavior.Name.toLowerCase() === section.getName()) {

                                            if (window.console) console.log("       ## Custom section definition: " + sectionCustomBehavior.Name);

                                            //Default section definition
                                            if (window.console) console.log("       ## - Custom section behavior:: Is visibled");
                                            if (sectionCustomBehavior.IsVisible !== undefined) {
                                                if (sectionCustomBehavior.IsVisible != null && (typeof (sectionCustomBehavior.IsVisible) === "boolean")) {
                                                    if (sectionCustomBehavior.IsVisible != section.getVisible()) {
                                                        debugger;
                                                        section.setVisible(sectionCustomBehavior.IsVisible);
                                                    }
                                                } else if (window.console) console.log("In the 'IsVisible' property of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + tabCustomBehavior.DisplayState + ") is invalid.");
                                            }


                                            for (var c in section.controls.get()) {

                                                debugger;

                                                var control = section.controls.get()[c];
                                                var foundControl = false;

                                                if (sectionCustomBehavior.Controls != null && sectionCustomBehavior.Controls.length > 0) {
                                                    for (var cc in sectionCustomBehavior.Controls) {

                                                        var controlCustomBehavior = sectionCustomBehavior.Controls[cc];

                                                        if (controlCustomBehavior.Name.toLowerCase() === control.getName()) {

                                                            if (window.console) console.log("           ### Custom control definition: " + controlCustomBehavior.Name);

                                                            //Custom control definition

                                                            if (window.console) console.log("           ### - Custom control behavior:: Value");
                                                            if (controlCustomBehavior.Value !== undefined) {
                                                                control.getAttribute().setValue(controlCustomBehavior.Value);
                                                            }

                                                            if (window.console) console.log("           ### - Custom control behavior:: Is disabled");
                                                            if (controlCustomBehavior.IsDisabled !== undefined) {
                                                                if (controlCustomBehavior.IsDisabled != null && (typeof (controlCustomBehavior.IsDisabled) === "boolean")) {
                                                                    if (controlCustomBehavior.IsDisabled != control.getDisabled()) {
                                                                        control.setDisabled(controlCustomBehavior.IsDisabled);
                                                                    }
                                                                } else if (window.console) console.log("In the 'IsDisabled' property of the '" + controlCustomBehavior.Name + "' control of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + tabCustomBehavior.IsDisabled + ") is invalid.");
                                                            }

                                                            if (window.console) console.log("           ### - Custom control behavior:: Is visibled");
                                                            if (controlCustomBehavior.IsVisible !== undefined) {
                                                                if (controlCustomBehavior.IsVisible != null && (typeof (controlCustomBehavior.IsVisible) === "boolean")) {
                                                                    if (controlCustomBehavior.IsVisible != control.getVisible()) {
                                                                        control.setVisible(controlCustomBehavior.IsVisible);
                                                                    }
                                                                } else if (window.console) console.log("In the 'IsVisible' property of the '" + controlCustomBehavior.Name + "' control of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + controlCustomBehavior.IsVisible + ") is invalid.");
                                                            }

                                                            if (window.console) console.log("           ### - Custom control behavior:: Submit mode");
                                                            if (controlCustomBehavior.SubmitMode !== undefined) {
                                                                if (controlCustomBehavior.SubmitMode != null && (typeof (controlCustomBehavior.SubmitMode) === "string")) {
                                                                    switch (controlCustomBehavior.SubmitMode) {
                                                                        case "always":
                                                                        case "never":
                                                                        case "dirty":
                                                                            if (controlCustomBehavior.SubmitMode.toLowerCase() !== control.getAttribute().getSubmitMode()) {
                                                                                control.getAttribute().setSubmitMode(controlCustomBehavior.SubmitMode);
                                                                            }
                                                                            break;
                                                                        default:
                                                                            if (window.console) console.log("In the 'SubmitMode' property of the '" + controlCustomBehavior.Name + "' control of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + controlCustomBehavior.SubmitMode + ") is invalid.");
                                                                    }
                                                                } else if (window.console) console.log("In the 'SubmitMode' property of the '" + controlCustomBehavior.Name + "' control of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + controlCustomBehavior.SubmitMode + ") is invalid.");
                                                            }

                                                            if (window.console) console.log("           ### - Custom control behavior:: Required level");
                                                            if (controlCustomBehavior.RequiredLevel !== undefined) {
                                                                if (controlCustomBehavior.RequiredLevel != null && (typeof (controlCustomBehavior.RequiredLevel) === "string")) {
                                                                    switch (controlCustomBehavior.RequiredLevel) {
                                                                        case "none":
                                                                        case "required":
                                                                        case "recommended":
                                                                            if (controlCustomBehavior.RequiredLevel.toLowerCase() !== control.getAttribute().getRequiredLevel()) {
                                                                                control.getAttribute().setRequiredLevel(controlCustomBehavior.RequiredLevel);
                                                                            }
                                                                            break;
                                                                        default:
                                                                            if (window.console) console.log("In the 'RequiredLevel' property of the '" + controlCustomBehavior.Name + "' control of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + controlCustomBehavior.RequiredLevel + ") is invalid.");
                                                                    }
                                                                } else if (window.console) console.log("In the 'RequiredLevel' property of the '" + controlCustomBehavior.Name + "' control of the '" + sectionCustomBehavior.Name + "' section of the '" + tabCustomBehavior.Name + "' tab the value(" + controlCustomBehavior.RequiredLevel + ") is invalid.");
                                                            }


                                                            if (window.console) console.log("           ### break");
                                                            foundControl = true;
                                                            break;
                                                        }
                                                    }
                                                }



                                                if (foundControl) { continue; }

                                                if (window.console) console.log("           *** Default control definition: " + control.getName());

                                                //Default definition
                                                if (window.console) console.log("           *** - Default control behavior:: Is disabled");
                                                if (!control.getDisabled()) { control.setDisabled(true); }
                                                if (window.console) console.log("           *** - Default control behavior:: Is visibled");
                                                if (control.getVisible()) { control.setVisible(false); }
                                                if (window.console) console.log("           *** - Default control behavior:: Submit mode");
                                                if (control.getAttribute().getSubmitMode() !== "never") { control.getAttribute().setSubmitMode("never"); }
                                                if (window.console) console.log("           *** - Default control behavior:: Required level");
                                                if (control.getAttribute().getRequiredLevel() !== "none") { control.getAttribute().setRequiredLevel("none"); }
                                            }


                                            if (window.console) console.log("       ## break");
                                            foundSection = true;
                                            break;
                                        }
                                    }
                                }




                                if (foundSection) { continue; }

                                if (window.console) console.log("       ** Default section definition: " + section.getName());

                                //Default section definition
                                if (window.console) console.log("       ** - Section default behavior:: Is visibled");
                                if (section.getVisible()) { section.setVisible(false); }

                                for (var c in section.controls.get()) {

                                    var control = section.controls.get()[c];

                                    if (window.console) console.log("           *** Default control definition: " + control.getName());

                                    //Default definition
                                    if (window.console) console.log("           *** - Default control behavior:: Is disabled");
                                    if (!control.getDisabled()) { control.setDisabled(true); }
                                    if (window.console) console.log("           *** - Default control behavior:: Is visibled");
                                    if (control.getVisible()) { control.setVisible(false); }
                                    if (window.console) console.log("           *** - Default control behavior:: Submit mode");
                                    if (control.getAttribute().getSubmitMode() !== "never") { control.getAttribute().setSubmitMode("never"); }
                                    if (window.console) console.log("           *** - Default control behavior:: Required level");
                                    if (control.getAttribute().getRequiredLevel() !== "none") { control.getAttribute().setRequiredLevel("none"); }
                                }
                            }

                            if (window.console) console.log("# break");
                            foundTab = true;
                            break;

                        }
                    }
                }

            } catch (e) {
                if (window.console) console.error("The error occurred while processing the custom behavior. Detail: Detail: " + e.message);
            }

            if (foundTab) { continue; }

            if (window.console) console.log("* Default tab definition: " + tab.getName());

            //Default definition
            if (window.console) console.log("* - Tab default behavior:: Is visibled?");
            if (tab.getVisible()) { tab.setVisible(false); }
            if (window.console) console.log("* - Tab default behavior:: Display state:");
            if (tab.getDisplayState() !== "expanded") { tab.setDisplayState("expanded"); }

            for (var s in tab.sections.get()) {

                debugger;

                var section = tab.sections.get()[s];

                if (window.console) console.log("       ** Default section definition: " + section.getName());

                //Default definition
                if (window.console) console.log("       ** - Section default behavior:: Is visibled");
                if (section.getVisible()) { section.setVisible(false); }

                for (var c in section.controls.get()) {

                    debugger;

                    var control = section.controls.get()[c];

                    if (window.console) console.log("           *** Default control definition: " + control.getName());

                    //Default definition
                    if (window.console) console.log("           *** - Default control behavior:: Is disabled");
                    if (!control.getDisabled()) { control.setDisabled(true); }
                    if (window.console) console.log("           *** - Default control behavior:: Is visibled");
                    if (control.getVisible()) { control.setVisible(false); }
                    if (window.console) console.log("           *** - Default control behavior:: Submit mode");
                    if (control.getAttribute().getSubmitMode() !== "never") { control.getAttribute().setSubmitMode("never"); }
                    if (window.console) console.log("           *** - Default control behavior:: Required level");
                    if (control.getAttribute().getRequiredLevel() !== "none") { control.getAttribute().setRequiredLevel("none"); }
                }
            }
        }
    };

    var onChangeTipoParametrizacao = function (eventArgs) {
        debugger;

        var bsoTipoParametrizacao = Xrm.Page.getAttribute("bso_tipo_parametrizacao");

        if (bsoTipoParametrizacao != null) {

            var customBehavior = [{ Name: "tab_geral", IsVisible: true, DisplayState: "expanded", Sections: [] }];

            var bsoTipoParametrizacaoOption = bsoTipoParametrizacao.getSelectedOption();

            var bsoTipoParametrizacaoIsEditable = false;

            if (Xrm.Page.ui.getFormType() == formType.Create) {
                bsoTipoParametrizacaoIsEditable = true;
            } else {
                if (bsoTipoParametrizacao.getIsDirty() || bsoTipoParametrizacaoOption == null) {
                    bsoTipoParametrizacaoIsEditable = true;
                }
            }

            customBehavior[0].Sections.push({
                Name: "tab_geral_section_geral", IsVisible: true,
                Controls: [
                    { Name: "bso_name", Value: ((bsoTipoParametrizacaoOption != null) ? bsoTipoParametrizacaoOption.text : null), IsDisabled: true, IsVisible: false, SubmitMode: "dirty", RequiredLevel: "none" },
                    { Name: "bso_tipo_parametrizacao", IsDisabled: !bsoTipoParametrizacaoIsEditable, IsVisible: true, SubmitMode: (bsoTipoParametrizacaoIsEditable ? "dirty" : "never"), RequiredLevel: (bsoTipoParametrizacaoIsEditable ? "required" : "none") }
                ]
            });

            if (bsoTipoParametrizacaoOption != null) {

                switch (bsoTipoParametrizacaoOption.value) {
                    case tipoParametrizacao.QuantidadeVidas:

                        if (Xrm.Page.ui.getFormType() == formType.Create || Xrm.Page.getAttribute("bso_ramo").getValue() == null) {
                            customBehavior[0].Sections[0].Controls.push({ Name: "bso_ramo", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        } else {
                            customBehavior[0].Sections[0].Controls.push({ Name: "bso_ramo", IsDisabled: true, IsVisible: true, SubmitMode: "never", RequiredLevel: "none" });
                        }

                        customBehavior[0].Sections.push({
                            Name: "tab_geral_section_quantidade", IsVisible: true, Controls: [
                                        { Name: "bso_quantidade_classificacao", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                        { Name: "bso_quantidade_valor_de", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                        { Name: "bso_quantidade_valor_ate", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" }
                            ]
                        });

                        break;
                    case tipoParametrizacao.Faturamento:

                        if (Xrm.Page.ui.getFormType() == formType.Create || Xrm.Page.getAttribute("bso_ramo").getValue() == null) {
                            customBehavior[0].Sections[0].Controls.push({ Name: "bso_ramo", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        } else {
                            customBehavior[0].Sections[0].Controls.push({ Name: "bso_ramo", IsDisabled: true, IsVisible: true, SubmitMode: "never", RequiredLevel: "none" });
                        }

                        var moedaReal = [{ id: "{B20CA356-FF81-E411-B174-005056860028}", name: "Real", entityType: "transactioncurrency" }];

                        customBehavior[0].Sections.push({
                            Name: "tab_geral_section_faturamento", IsVisible: true, Controls: [
                                { Name: "bso_faturamento_classificacao", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "bso_faturamento_valor_de", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "bso_faturamento_valor_ate", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "transactioncurrencyid", Value: moedaReal, IsDisabled: true, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" }
                            ]
                        });

                        break;
                    case tipoParametrizacao.Frequencia:

                        if (Xrm.Page.ui.getFormType() == formType.Create || Xrm.Page.getAttribute("bso_ramo").getValue() == null) {
                            customBehavior[0].Sections[0].Controls.push({ Name: "bso_ramo", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        } else {
                            customBehavior[0].Sections[0].Controls.push({ Name: "bso_ramo", IsDisabled: true, IsVisible: true, SubmitMode: "never", RequiredLevel: "none" });
                        }

                        customBehavior[0].Sections.push({
                            Name: "tab_geral_section_frequencia", IsVisible: true, Controls: [
                                { Name: "bso_frequencia", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "bso_frequencia_fator_ritmo_visita", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" }
                            ]
                        });

                        break;
                    case tipoParametrizacao.Indicador:
                        customBehavior[0].Sections.push({
                            Name: "tab_geral_section_indicador", IsVisible: true, Controls: [
                                { Name: "bso_indicador", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "bso_indicador_valor_verde", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "bso_indicador_valor_amarelo", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" },
                                { Name: "bso_indicador_valor_vermelho", IsDisabled: false, IsVisible: true, SubmitMode: "dirty", RequiredLevel: "required" }
                            ]
                        });

                        break;
                    default:
                        alert("O valor de par�metro � inv�lido!");
                        break;
                }

                controlAllBehavior(customBehavior);

            } else {
                controlAllBehavior(customBehavior);
            }
        }
    };

    var onChangeTipoParametrizacao3 = function (eventArgs) {
        debugger;


        //var tabs = [
        //   { Name: "<<tabName>>", IsVisible: false, DisplayState: "collapsed", 
        //      Sections: [
        //          { 
        //              Name: "<<sectionName>>", IsVisible: false, 
        //              Controls: [
        //                  { Name: "<<controlName>>", Value: null, IsDisabled: false, IsVisible: false, SubmitMode: "dirty", RequiredLevel: "recommended" }
        //              ]
        //          }
        //      ]}
        //];

        //var customBehavior = [
        //     {
        //         Name: "tab_geral", IsVisible: false, DisplayState: "collapsed",
        //         Sections: [
        //             {
        //                 Name: "tab_geral_section_quantidade", IsVisible: false,
        //                 Controls: [
        //                     { Name: "bso_ramo", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_quantidade_classificacao", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_quantidade_valor_de", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_quantidade_valor_ate", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_faturamento_classificacao", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_faturamento_valor_de", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_faturamento_valor_ate", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "transactioncurrencyid", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_frequencia", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_frequencia_fator_ritmo_visita", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_indicador", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "required" },
        //                     { Name: "bso_indicador_valor_verde", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_indicador_valor_amarelo", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_indicador_valor_vermelho", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                 ]
        //             },
        //             {
        //                 Name: "tab_geral_section_faturamento", IsVisible: false,
        //                 Controls: [
        //                     { Name: "bso_faturamento_classificacao", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_faturamento_valor_de", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_faturamento_valor_ate", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "transactioncurrencyid", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                 ]
        //             },
        //             {
        //                 Name: "tab_geral_section_frequencia", IsVisible: false,
        //                 Controls: [
        //                     { Name: "bso_frequencia", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_frequencia_fator_ritmo_visita", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                 ]
        //             },
        //             {
        //                 Name: "tab_geral_section_indicador", IsVisible: false,
        //                 Controls: [
        //                     { Name: "bso_indicador", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "required" },
        //                     { Name: "bso_indicador_valor_verde", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_indicador_valor_amarelo", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                     { Name: "bso_indicador_valor_vermelho", Value: null, IsDisabled: true, IsVisible: false, SubmitMode: "never", RequiredLevel: "none" },
        //                 ]
        //             },
        //         ]
        //     }
        //];

        //controlAllBehavior(customBehavior);






        //return;

        var bsoTipoParametrizacao = Xrm.Page.getAttribute("bso_tipo_parametrizacao");

        if (bsoTipoParametrizacao != null) {

            var attributesException = new Array();
            var tabsAndSectionsException = new Array();

            var bsoTipoParametrizacaoOption = bsoTipoParametrizacao.getSelectedOption();

            if (Xrm.Page.ui.getFormType() == formType.Create || bsoTipoParametrizacaoOption == null) {
                attributesException.push({ Name: "bso_tipo_parametrizacao", Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
            } else {
                attributesException.push({ Name: "bso_tipo_parametrizacao", Disabled: true, Visible: true, SubmitMode: "never", RequiredLevel: "none" });
            }

            if (bsoTipoParametrizacaoOption != null) {

                switch (bsoTipoParametrizacaoOption.value) {
                    case tipoParametrizacao.QuantidadeVidas:
                        if (Xrm.Page.ui.getFormType() == formType.Create || Xrm.Page.getAttribute("bso_ramo").getValue() == null) {
                            attributesException.push({ Name: "bso_ramo", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        } else {
                            attributesException.push({ Name: "bso_ramo", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        }
                        attributesException.push({ Name: "bso_quantidade_classificacao", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_quantidade_valor_de", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_quantidade_valor_ate", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(true);
                        break;
                    case tipoParametrizacao.Faturamento:
                        attributesException.push({ Name: "bso_ramo", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_faturamento_classificacao", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_faturamento_valor_de", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_faturamento_valor_ate", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        var moedaReal = [{ id: "{B20CA356-FF81-E411-B174-005056860028}", name: "Real", entityType: "transactioncurrency" }];
                        attributesException.push({ Name: "transactioncurrencyid", Value: moedaReal, Disabled: true, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(true);
                        break;
                    case tipoParametrizacao.Frequencia:
                        attributesException.push({ Name: "bso_ramo", Value: null, Disabled: false, Visible: true, SubmitMode: "dirty", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_frequencia", Value: null, Disabled: false, Visible: true, SubmitMode: "never", RequiredLevel: "none" });
                        attributesException.push({ Name: "bso_frequencia_fator_ritmo_visita", Value: null, Disabled: false, Visible: true, SubmitMode: "never", RequiredLevel: "none" });
                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(false);
                        break;
                    case tipoParametrizacao.Indicador:
                        attributesException.push({ Name: "bso_indicador", Value: null, Disabled: false, Visible: true, SubmitMode: "never", RequiredLevel: "required" });
                        attributesException.push({ Name: "bso_indicador_valor_verde", Value: null, Disabled: false, Visible: true, SubmitMode: "never", RequiredLevel: "none" });
                        attributesException.push({ Name: "bso_indicador_valor_amarelo", Value: null, Disabled: false, Visible: true, SubmitMode: "never", RequiredLevel: "none" });
                        attributesException.push({ Name: "bso_indicador_valor_vermelho", Value: null, Disabled: false, Visible: true, SubmitMode: "never", RequiredLevel: "none" });
                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(false);
                        break;
                    default:
                        alert("O valor de par�metro � inv�lido!");
                        break;
                }

                Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text);

            } else {
                var attributesExceptionOld = [
                    { Name: "bso_ramo", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_quantidade_classificacao", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_quantidade_valor_de", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_quantidade_valor_ate", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_faturamento_classificacao", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_faturamento_valor_de", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_faturamento_valor_ate", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "transactioncurrencyid", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_frequencia", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_frequencia_fator_ritmo_visita", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_indicador", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "required" },
                    { Name: "bso_indicador_valor_verde", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_indicador_valor_amarelo", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                    { Name: "bso_indicador_valor_vermelho", Value: null, Disabled: true, Visible: false, SubmitMode: "never", RequiredLevel: "none" },
                ];

                Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(false);

                attributesException = attributesException.concat(attributesExceptionOld);
            }

            controlAllAttribute(attributesException);
        }
    };

    var onChangeTipoParametrizacao2 = function (eventArgs) {
        debugger;

        Xrm.Page.getAttribute("bso_ramo").setRequiredLevel("none");
        Xrm.Page.getControl("bso_ramo").setVisible(false);

        //Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_classificacao").setVisible(false);
        Xrm.Page.getAttribute("bso_classificacao_cliente").setRequiredLevel("none");
        Xrm.Page.getControl("bso_classificacao_cliente").setVisible(false);
        Xrm.Page.getAttribute("bso_frequencia").setRequiredLevel("none");
        Xrm.Page.getControl("bso_frequencia").setVisible(false);
        Xrm.Page.getAttribute("bso_indicador").setRequiredLevel("none");
        Xrm.Page.getControl("bso_indicador").setVisible(false);

        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(false);
        Xrm.Page.getAttribute("bso_quantidade_valor_de").setRequiredLevel("none");
        Xrm.Page.getControl("bso_quantidade_valor_de").setVisible(false);
        Xrm.Page.getAttribute("bso_quantidade_valor_ate").setRequiredLevel("none");
        Xrm.Page.getControl("bso_quantidade_valor_ate").setVisible(false);

        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(false);
        Xrm.Page.getAttribute("bso_faturamento_valor_de").setRequiredLevel("none");
        Xrm.Page.getControl("bso_faturamento_valor_de").setVisible(false);
        Xrm.Page.getAttribute("bso_faturamento_valor_ate").setRequiredLevel("none");
        Xrm.Page.getControl("bso_faturamento_valor_ate").setVisible(false);

        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(false);
        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setRequiredLevel("none");
        Xrm.Page.getControl("bso_frequencia_fator_ritmo_visita").setVisible(false);

        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(false);
        Xrm.Page.getAttribute("bso_indicador_valor_verde").setRequiredLevel("none");
        Xrm.Page.getControl("bso_indicador_valor_verde").setVisible(false);
        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setRequiredLevel("none");
        Xrm.Page.getControl("bso_indicador_valor_amarelo").setVisible(false);
        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setRequiredLevel("none");
        Xrm.Page.getControl("bso_indicador_valor_vermelho").setVisible(false);

        var bsoTipoParametrizacao = Xrm.Page.getAttribute("bso_tipo_parametrizacao");

        if (bsoTipoParametrizacao != null) {
            var bsoTipoParametrizacaoOption = bsoTipoParametrizacao.getSelectedOption();

            if (bsoTipoParametrizacaoOption != null) {

                switch (bsoTipoParametrizacaoOption.value) {
                    case tipoParametrizacao.QuantidadeVidas:
                        Xrm.Page.getAttribute("bso_ramo").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_ramo").setVisible(true);

                        //Xrm.Page.getControl(arg).setDisabled(bool)

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_classificacao").setVisible(true);
                        Xrm.Page.getAttribute("bso_classificacao_cliente").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_classificacao_cliente").setVisible(true);
                        Xrm.Page.getAttribute("bso_frequencia").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_frequencia").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(true);
                        Xrm.Page.getAttribute("bso_quantidade_valor_de").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_quantidade_valor_de").setVisible(true);
                        Xrm.Page.getAttribute("bso_quantidade_valor_ate").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_quantidade_valor_ate").setVisible(true);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(false);
                        Xrm.Page.getAttribute("transactioncurrencyid").setValue(null);
                        Xrm.Page.getAttribute("bso_faturamento_valor_de").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_faturamento_valor_de").setVisible(false);
                        Xrm.Page.getAttribute("bso_faturamento_valor_de").setValue(null);
                        Xrm.Page.getAttribute("bso_faturamento_valor_ate").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_faturamento_valor_ate").setVisible(false);
                        Xrm.Page.getAttribute("bso_faturamento_valor_ate").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_frequencia_fator_ritmo_visita").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_verde").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_amarelo").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_vermelho").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setValue(null);
                        break;
                    case tipoParametrizacao.Faturamento:
                        Xrm.Page.getAttribute("bso_ramo").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_ramo").setVisible(true);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_classificacao").setVisible(true);
                        Xrm.Page.getAttribute("bso_classificacao_cliente").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_classificacao_cliente").setVisible(true);
                        Xrm.Page.getAttribute("bso_classificacao_cliente").setValue(null);
                        Xrm.Page.getAttribute("bso_frequencia").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_frequencia").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_de").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_quantidade_valor_de").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_de").setValue(null);
                        Xrm.Page.getAttribute("bso_quantidade_valor_ate").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_quantidade_valor_ate").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_ate").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(true);
                        Xrm.Page.getAttribute("transactioncurrencyid").setValue([{ id: "{B20CA356-FF81-E411-B174-005056860028}", name: "Real", entityType: "transactioncurrency" }]);
                        Xrm.Page.getAttribute("bso_faturamento_valor_de").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_faturamento_valor_de").setVisible(true);
                        Xrm.Page.getAttribute("bso_faturamento_valor_ate").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_faturamento_valor_ate").setVisible(true);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_frequencia_fator_ritmo_visita").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_verde").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_amarelo").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_vermelho").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setValue(null);
                        break;
                    case tipoParametrizacao.Frequencia:
                        Xrm.Page.getAttribute("bso_ramo").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_ramo").setVisible(true);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_classificacao").setVisible(true);
                        Xrm.Page.getAttribute("bso_classificacao_cliente").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_classificacao_cliente").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_frequencia").setVisible(true);
                        Xrm.Page.getAttribute("bso_indicador").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador").setVisible(false);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_de").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_quantidade_valor_de").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_ate").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_quantidade_valor_ate").setVisible(false);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(false);
                        Xrm.Page.getAttribute("transactioncurrencyid").setValue(null);
                        Xrm.Page.getAttribute("bso_faturamento_valor_de").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_faturamento_valor_de").setVisible(false);
                        Xrm.Page.getAttribute("bso_faturamento_valor_ate").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_faturamento_valor_ate").setVisible(false);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(true);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_frequencia_fator_ritmo_visita").setVisible(true);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_verde").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_amarelo").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setValue(null);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_indicador_valor_vermelho").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setValue(null);
                        break;
                    case tipoParametrizacao.Indicador:
                        Xrm.Page.getAttribute("bso_ramo").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_ramo").setVisible(false);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_classificacao").setVisible(true);
                        Xrm.Page.getAttribute("bso_classificacao_cliente").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_classificacao_cliente").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_frequencia").setVisible(false);
                        Xrm.Page.getAttribute("bso_indicador").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_indicador").setVisible(true);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_quantidade").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_de").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_quantidade_valor_de").setVisible(false);
                        Xrm.Page.getAttribute("bso_quantidade_valor_ate").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_quantidade_valor_ate").setVisible(false);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_faturamento").setVisible(false);
                        Xrm.Page.getAttribute("transactioncurrencyid").setValue(null);
                        Xrm.Page.getAttribute("bso_faturamento_valor_de").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_faturamento_valor_de").setVisible(false);
                        Xrm.Page.getAttribute("bso_faturamento_valor_ate").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_faturamento_valor_ate").setVisible(false);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_frequencia").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setRequiredLevel("none");
                        Xrm.Page.getControl("bso_frequencia_fator_ritmo_visita").setVisible(false);
                        Xrm.Page.getAttribute("bso_frequencia_fator_ritmo_visita").setValue(null);

                        Xrm.Page.ui.tabs.get("tab_geral").sections.get("tab_geral_section_indicador").setVisible(true);
                        Xrm.Page.getAttribute("bso_indicador_valor_verde").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_indicador_valor_verde").setVisible(true);
                        Xrm.Page.getAttribute("bso_indicador_valor_amarelo").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_indicador_valor_amarelo").setVisible(true);
                        Xrm.Page.getAttribute("bso_indicador_valor_vermelho").setRequiredLevel("required");
                        Xrm.Page.getControl("bso_indicador_valor_vermelho").setVisible(true);
                        break;
                    default:
                        alert("O valor de par�metro � inv�lido!");
                        break;
                }

                Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text);

                //var bsoRamo = Xrm.Page.getAttribute("bso_ramo");
                //if (bsoRamo != null) {
                //    var bsoRamoOption = bsoRamo.getSelectedOption();
                //    if (bsoRamoOption != null) {
                //        Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text + " - " + bsoRamoOption.text);
                //    }
                //}

                //var bsoIndicador = Xrm.Page.getAttribute("bso_indicador");
                //if (bsoIndicador != null) {
                //    var bsoIndicadorOption = bsoIndicador.getSelectedOption();
                //    if (bsoIndicadorOption != null) {
                //        Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text + " - " + bsoIndicadorOption.text);
                //    }
                //}
            }
        }
    };


    return {
        OnLoad: function () {
            onChangeTipoParametrizacao();
        },

        OnSave: function (econtext) {

        },

        OnChangeTipoParametrizacao: onChangeTipoParametrizacao,

        OnChangeRamo: function () {

            var bsoTipoParametrizacao = Xrm.Page.getAttribute("bso_tipo_parametrizacao");

            if (bsoTipoParametrizacao != null) {

                var bsoTipoParametrizacaoOption = bsoTipoParametrizacao.getSelectedOption();
                if (bsoTipoParametrizacaoOption != null) {

                    Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text);

                    var bsoRamo = Xrm.Page.getAttribute("bso_ramo");
                    if (bsoRamo != null) {
                        var bsoRamoOption = bsoRamo.getSelectedOption();
                        if (bsoRamoOption != null) {
                            Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text + " - " + bsoRamoOption.text);
                        }
                    }
                }
            }
        },

        OnChangeIndicador: function () {

            var bsoTipoParametrizacao = Xrm.Page.getAttribute("bso_tipo_parametrizacao");

            if (bsoTipoParametrizacao != null) {

                var bsoTipoParametrizacaoOption = bsoTipoParametrizacao.getSelectedOption();
                if (bsoTipoParametrizacaoOption != null) {

                    Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text);

                    var bsoIndicador = Xrm.Page.getAttribute("bso_indicador");
                    if (bsoIndicador != null) {
                        var bsoIndicadorOption = bsoIndicador.getSelectedOption();
                        if (bsoIndicadorOption != null) {
                            Xrm.Page.getAttribute("bso_name").setValue(bsoTipoParametrizacaoOption.text + " - " + bsoIndicadorOption.text);
                        }
                    }
                }
            }
        },
    };
}();
