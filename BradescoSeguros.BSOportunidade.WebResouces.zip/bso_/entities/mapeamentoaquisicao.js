﻿/// <reference path="bso_scripts_common.js" />

var MapeamentoAquisicao = {

    OnLoad: function () {
        MapeamentoAquisicao.SelecionarProdutoPadrao(1); //Saude      
        Xrm.Page.getAttribute("bso_gerente_comercial").addOnChange(MapeamentoAquisicao.OnChange_GECOM);
     
        if (GEM.Crm.Common.Methods.isCreateForm()) {
            MapeamentoAquisicao.PreencherSucursalSupex();
        }
    },

    SelecionarProdutoPadrao: function (opt_set_produto) {
        Xrm.Page.getAttribute("bso_produto").setValue(opt_set_produto);
    },

    OnChange_GECOM: function () {
        MapeamentoAquisicao.ObterAgenciasPorGECOM();
    },


    PreencherSucursalSupex: function () {
        // businessunitid, businessunitidname
        var userId = Xrm.Page.context.getUserId();
        //Remove braces
        userId = userId.substr(1, 36);
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers(" + userId + ")?$select=_businessunitid_value&$expand=businessunitid($select=businessunitid,_parentbusinessunitid_value)", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    var unidadeNegocioId = result["_businessunitid_value"];
                    var unidadeNegocioId_name = result["_businessunitid_value@OData.Community.Display.V1.FormattedValue"];
                    var unidadeNegocioPaiId = result["businessunitid"]["_parentbusinessunitid_value"];
                    var unidadeNegocioPaiId_name = result["businessunitid"]["_parentbusinessunitid_value@OData.Community.Display.V1.FormattedValue"];
                    if (unidadeNegocioId != null && unidadeNegocioPaiId != null) {
                        var lookupReference = [];
                        lookupReference[0] = {};
                        lookupReference[0].id = unidadeNegocioId;
                        lookupReference[0].entityType = "businessunit";
                        lookupReference[0].name = unidadeNegocioId_name;
                        Xrm.Page.getAttribute("bso_sucursal").setValue(lookupReference);
                        Xrm.Page.getAttribute("bso_nome_supex").setValue(unidadeNegocioPaiId_name);
                        GEM.Crm.Common.Methods.disableFields(["bso_nome_supex"]);
                    }
                }
            }
        };
        req.send();
    },

  

    ObterAgenciasPorGECOM: function () {
        var userId = Xrm.Page.getAttribute("bso_gerente_comercial").getValue()[0].id;
        userId = userId.substr(1, 36);
        var codsAgencias = "";
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/camp_estruturadistribuicaos?$select=bso_condigodaagencia&$filter=( _camp_usuarioid_value eq " + userId + " or _camp_usuariosup_value eq " + userId + ") and statecode eq 0 and camp_canal eq 861500001 and bso_condigodaagencia ne null", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        codsAgencias += "<value>" + results.value[i]["bso_condigodaagencia"] + "</value>";
                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();


        if (codsAgencias == "") {
            codsAgencias = "<value>-1</value>";
        }
        var fetchXMLCustom = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
        "<entity name='bso_agencia'>" +
        "<attribute name='bso_agenciaid' />" +
        "<attribute name='bso_name' />" +
        "<attribute name='bso_codigodaagencia' />" +
        "<attribute name='bso_classificacao' />" +
        "<order attribute='bso_name' descending='false' />" +
          "<filter type='and'>" +
              "<condition attribute='bso_codigodaagencia' operator='in' >" +
               codsAgencias +
              "</condition>" +
            "</filter>" +
        "</entity>" +
        "</fetch>";

        var layoutXml = "<grid name='resultset' " +
                            "object='10007' " +
                            "jump='bso_agenciaid' " +
                            "select='1' " +
                                "icon='1' " +
                                "preview='1'>" +
                                "<row name='result' " +
                                "id='bso_agenciaid'>" +
                                "<cell name='bso_name' " +
                                "width='150' />" +
                                "<cell name='bso_codigodaagencia' " +
                                "width='125' />" +
                                "<cell name='bso_classificacao' " +
                                "width='100' />" +
                                "</row>" +
                                "</grid>";

        //Guid utilizado como referencia para uso em tempo de execução do formulário apenas.
        //Nao é gravado na base.
        var viewId = "{00000000-0000-0000-0000-000000000001}";
        var entityName = "bso_agencia";
        var viewDisplayName = "AgenciasPorGECOM";
        var fetchXml = fetchXMLCustom;
        var isDefault = true;
        Xrm.Page.getControl("bso_agencia").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, isDefault);
    },




}