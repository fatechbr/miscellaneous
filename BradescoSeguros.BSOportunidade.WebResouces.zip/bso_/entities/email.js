/// <reference path="\Base\helpers.js" />

var ReferenteAAtual = Xrm.Page.getAttribute("regardingobjectid").getValue();

var Email = {
    OnLoad: function () {

        //Verifica Direção para exibir ou não o contador:
        var direcao = Xrm.Page.getAttribute("directioncode").getValue();
        var liminares = Xrm.Page.getAttribute("bso_notificado").getValue();

        if (direcao == false && liminares == true) {
            Xrm.Page.ui.tabs.get("Email").sections.get("controle_sla").setVisible(true);
        }
        else {
            Xrm.Page.ui.tabs.get("Email").sections.get("controle_sla").setVisible(false);
        }

        //Email.getAssinatura();
        //Email.CopiarParaDoEmailDeOrigemParaORemetente();

        Email.PegarFila();
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        //debugger;
        Email.CheckUserRole();

        // var definirAcao = function () {
        // if (parent.document.getElementsByClassName("attachmentFileName") != null && parent.document.getElementsByClassName("attachmentFileName") != undefined && parent.document.getElementsByClassName("attachmentFileName").length > 0) {
        // console.log("Exists!");
        // clearInterval(checkExist);
        // console.log('Teste');

        // var acaoClicar = function () {
        // console.log("Teste 1");
        // var attribute = this.getAttribute("href");
        // var result;

        // toDataURL('https://bsoportunidades.bradescoseguros.com.br' + attribute, function (dataUrl) {
        // result = dataUrl;

        // var html = "<img src='" + result + "' />";
        // var newWindow = window.open();
        // newWindow.document.write(html);
        // });
        // };

        // var classname = parent.document.getElementsByClassName("attachmentFileName");

        // for (var i = 0; i < classname.length; i++) {
        // classname[i].addEventListener('click', acaoClicar, false);
        // }
        // }
        // };

        // var checkExist = setInterval(definirAcao, 100);

        // var botaoConcluido = parent.document.getElementsByClassName("doneLink");

        // var awaitCheckExist = function () {
        // setTimeout(definirAcao, 3000);
        // };

        // for (var i = 0; i < botaoConcluido.length; i++) {
        // botaoConcluido[i].addEventListener('click', awaitCheckExist, false);
        // }
    },

    getAssinatura: function () {
        try {
            if (Xrm.Page.getAttribute("statuscode").getText() == "Rascunho") {
                var organizationUrl = Xrm.Page.context.getClientUrl();

                var query = "bso_AssinaturadeEmail";

                var req = new XMLHttpRequest();

                req.open("POST", organizationUrl + "/api/data/v8.0/" + query, true);
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.onreadystatechange = function () {
                    if (this.readyState == 4) {
                        req.onreadystatechange = null;
                        if (this.status == 200) {
                            result = JSON.parse(this.response);
                            if (!Xrm.Page.getAttribute("bso_possui_assinatura").getValue()) {
                                if (Xrm.Page.getAttribute("description").getValue() != null) {
                                    descricao = '<br><br>' + result.EmailSignature + Xrm.Page.getAttribute("description").getValue();
                                } else {
                                    descricao = '<br><br>' + result.EmailSignature;
                                }

                                Xrm.Page.getAttribute("description").setValue(descricao);
                                Xrm.Page.getAttribute("bso_possui_assinatura").setValue(true);

                                if (Xrm.Page.ui.getFormType() == 2) {
                                    Xrm.Page.data.entity.save();
                                }
                            }
                            else {
                                alert("Não existe uma assinatura cadastrada ou habilitada para seu usuário. Para adicionar uma, vá para Configurações >> Modelos >> Assinaturas de Email >> Novo.\r\n\r\n"
                                    + "Importante: após salvar uma assinatura, marcar a opção 'Definir como Padrão.'");
                            }
                        }
                        //else {
                        //    var error = JSON.parse(this.response).error;
                        //    alert(error.message);
                        //}
                    }
                };
                req.send();
            }
        }
        catch (err) { }
    },

    //Valida se o usuário possui alguma role contida na entidade de parâmetros. 
    CheckUserRole: function () {
        debugger;
        var parametersname = [];
        parametersname = Email.GetCorportateEmailControl(); // Invoca o método que busca os parâmetros da entidade Controle Corporate – E-mail.
        var currentUserRoles = Xrm.Page.context.getUserRoles();

        var exibeAlerta = false;

        for (var i = 0; i < currentUserRoles.length; i++) {
            for (var j = 0; j < parametersname.length; j++) {

                var userRoleId = currentUserRoles[i];
                var userRoleName = Email.GetRoleName(userRoleId); // Busca o nome da role baseada no ID da role.

                if (userRoleName === parametersname[j]) {
                    //alerta para o usuário 
                    if (Xrm.Page.getAttribute('regardingobjectid').getValue() === null) {
                        exibeAlerta = true;
                        break;
                    }
                }
            }
        }

        if (exibeAlerta) {
            Xrm.Page.ui.setFormNotification("Atenção: \n Caso este e-mail esteja relacionado a uma Oportunidade existente, recomenda-se o preenchimento do campo Referente a.", "WARNING");
            Xrm.Page.getAttribute("regardingobjectid").setRequiredLevel("recommended"); //"Referente a" se torna recomendado.
            Xrm.Page.getControl("regardingobjectid").setFocus();
        }
    },

    GetRoleName: function (roleId) {
        var serverUrl = Xrm.Page.context.getClientUrl();
        var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$filter=RoleId eq guid'" + roleId + "'";
        var roleName = null;
        $.ajax(
            {
                type: "GET",
                async: false,
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: odataSelect,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data, textStatus, XmlHttpRequest) {
                    roleName = data.d.results[0].Name;
                },
                error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
            });
        return roleName;
    },

    GetCorportateEmailControl: function () {
        var req = new XMLHttpRequest();
        var parametersname = [];

        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_controlecorporateemails?$select=bso_name", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        parametersname[i] = results.value[i]["bso_name"];
                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();
        return parametersname;
    },

    //getAssinatura: function ()
    //{
    //    try
    //    {
    //        if (Xrm.Page.getAttribute("statuscode").getText() == "Rascunho")
    //        {
    //            var query = "bso_AssinaturadeEmail";
    //            var result = Helpers.ExecutarAcao(query, null, false);

    //            if (!Xrm.Page.getAttribute("bso_possui_assinatura").getValue())
    //            {
    //                if (Xrm.Page.getAttribute("description").getValue() != null)
    //                {
    //                    descricao = '<br><br>' + result.EmailSignature + Xrm.Page.getAttribute("description").getValue();
    //                } else
    //                {
    //                    descricao = '<br><br>' + result.EmailSignature;
    //                }
    //                Xrm.Page.getAttribute("description").setValue(descricao);
    //                Xrm.Page.getAttribute("bso_possui_assinatura").setValue(true);
    //            }
    //        }

    //    }
    //    catch (err) { }
    //},

    CopiarParaDoEmailDeOrigemParaORemetente: function () {
        if (Xrm.Page.getAttribute("statuscode").getValue() == 1) {
            var emailid = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
            var email = Helpers.Buscar("emails?$select=_parentactivityid_value&$filter=activityid eq " + emailid);
            if (email) {
                if (email[0]._parentactivityid_value) {
                    var para = Helpers.Buscar("activityparties?$filter=participationtypemask%20eq%202 and _activityid_value eq " + email[0]._parentactivityid_value);
                    if (para[0]) {
                        if (para[0]["_partyid_value@Microsoft.Dynamics.CRM.lookuplogicalname"] == "queue") {
                            var de = Helpers.CreateLookup(
                                para[0]._partyid_value,
                                para[0]["_partyid_value@OData.Community.Display.V1.FormattedValue"],
                                para[0]["_partyid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                            );
                            Xrm.Page.getAttribute("from").setValue(de);
                        }
                    }
                }
            }
        }
    },       

    PegarFila: function () {
        if (Xrm.Page.getAttribute("statuscode").getText() == "Rascunho") {
            var userid = Xrm.Page.context.getUserId().replace("{", "").replace("}", "");
            var filaFinal;

            var usuarioLogadoFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "  <entity name='systemuser'>" +
                "    <attribute name='fullname' />" +
                "    <attribute name='businessunitid' />" +
                "    <attribute name='title' />" +
                "    <attribute name='positionid' />" +
                "    <attribute name='systemuserid' />" +
                "    <attribute name='bso_gerentedeatendimentoid' />" +
                "    <order attribute='fullname' descending='false' />" +
                "    <filter type='and'>" +
                "      <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{" + userid + "}' />" +
                "    </filter>" +
                "  </entity>" +
                "</fetch>";

            var queueRecords = XrmServiceToolkit.Soap.Fetch(usuarioLogadoFetchXML);

            if (queueRecords.length > 0) {
                if (queueRecords[0].attributes.hasOwnProperty("businessunitid")) {
                    var unidadeNegocios = queueRecords[0].attributes["businessunitid"].formattedValue;

                    //Testes
                    //if ((unidadeNegocios.includes('Célula') || unidadeNegocios.includes('CÉLULA') || unidadeNegocios.includes('celula') ||
                    //    unidadeNegocios.includes('CELULA') || unidadeNegocios.includes('BSOportunidades')) && !unidadeNegocios.includes('Arcor')) {

                    if ((includes(unidadeNegocios, 'Célula') || includes(unidadeNegocios, 'CÉLULA') || includes(unidadeNegocios, 'celula') ||
                        includes(unidadeNegocios, 'CELULA') || includes('BSOportunidades')) && !includes(unidadeNegocios, 'Arcor')) {

                        var usuarioLogadoFilasFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                            "  <entity name='queue'>" +
                            "    <attribute name='name' />" +
                            "    <attribute name='emailaddress' />" +
                            "    <attribute name='queueid' />" +
                            "    <order attribute='name' descending='false' />" +
                            "    <link-entity name='queuemembership' from='queueid' to='queueid' visible='false' intersect='true'>" +
                            "      <link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='ae'>" +
                            "        <filter type='and'>" +
                            "          <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{" + userid + "}' />" +
                            "        </filter>" +
                            "      </link-entity>" +
                            "    </link-entity>" +
                            "  </entity>" +
                            "</fetch>";

                        var queueRecordsUsuarioLogadoFilas = XrmServiceToolkit.Soap.Fetch(usuarioLogadoFilasFetchXML);

                        if (queueRecordsUsuarioLogadoFilas.length > 0) {
                            var usuarioLogadoFilas = new Array();

                            for (var i = 0; i < queueRecordsUsuarioLogadoFilas.length; i++) {
                                usuarioLogadoFilas.push(queueRecordsUsuarioLogadoFilas[i].attributes["queueid"].value);
                            }
                        }

                        if (queueRecords[0].attributes.hasOwnProperty("bso_gerentedeatendimentoid")) {

                            var gerenteAtendimento = queueRecords[0].attributes["bso_gerentedeatendimentoid"];

                            var gerenteAtendimentoFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                "  <entity name='queue'>" +
                                "    <attribute name='name' />" +
                                "    <attribute name='emailaddress' />" +
                                "    <attribute name='queueid' />" +
                                "    <attribute name='ownerid' />" +
                                "    <order attribute='name' descending='false' />" +
                                "    <link-entity name='queuemembership' from='queueid' to='queueid' visible='false' intersect='true'>" +
                                "      <link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='ae'>" +
                                "        <filter type='and'>" +
                                "          <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{" + gerenteAtendimento.id + "}' />" +
                                "        </filter>" +
                                "      </link-entity>" +
                                "    </link-entity>" +
                                "  </entity>" +
                                "</fetch>";

                            var queueRecords2 = XrmServiceToolkit.Soap.Fetch(gerenteAtendimentoFetchXML);

                            if (queueRecords2.length > 0) {
                                var gerenteAtendimentoFilas = new Array();

                                for (var i = 0; i < queueRecords2.length; i++) {
                                    gerenteAtendimentoFilas.push(queueRecords2[i].attributes["queueid"].value);
                                }
                            }

                            for (var i = 0; i < gerenteAtendimentoFilas.length; i++) {
                                if (includes(usuarioLogadoFilas, gerenteAtendimentoFilas[i])) {

                                    var result = filterItems(queueRecords2, gerenteAtendimentoFilas[i]);

                                    //var result = queueRecords2.find(obj => {
                                    //    return obj.id === gerenteAtendimentoFilas[i]
                                    //});

                                    if (result[0].attributes.hasOwnProperty("emailaddress")) {
                                        if (result[0].attributes["ownerid"].id == gerenteAtendimento.id) {
                                            filaFinal = result[0];
                                        }
                                    }
                                }
                            }

                            var emailFrom = new Array();
                            emailFrom[0] = new Object();
                            emailFrom[0].id = filaFinal.attributes["queueid"].value;
                            emailFrom[0].name = filaFinal.attributes["name"].value;
                            emailFrom[0].entityType = "queue";

                            Xrm.Page.getAttribute("from").setValue(emailFrom);
                        }
                    }
                }
            }
        }
    },

    OnChangeReferenteA: function () {
        ReferenteANovo = Xrm.Page.getAttribute("regardingobjectid").getValue();

        if (ReferenteAAtual != null) {
            if (ReferenteANovo != null && (ReferenteANovo[0].id != ReferenteAAtual[0].id)) {
                //alerta de confirmação.
                var Response = confirm("Esta atividade está em tratativa em outro registro. Deseja confirmar a alteração?"); //prompt message

                if (Response != true) {
                    Xrm.Page.getAttribute("regardingobjectid").setValue(ReferenteAAtual);
                }
            }
        }
    }
}

//Solução alternativa para função JS homônima
function includes(container, value) {
    var returnValue = false;
    var pos = container.indexOf(value);
    if (pos >= 0) {
        returnValue = true;
    }
    return returnValue;
}

function filterItems(array, query) {
    return array.filter(function (el) {
        query = query + "";
        return el.id === query.toLowerCase();
    })
}

function toDataURL(url, callback) {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onload = function () {
        var fileReader = new FileReader();
        fileReader.onloadend = function () {
            callback(fileReader.result);
        }
        fileReader.readAsDataURL(httpRequest.response);
    };
    httpRequest.open('GET', url);
    httpRequest.responseType = 'blob';
    httpRequest.send();
}