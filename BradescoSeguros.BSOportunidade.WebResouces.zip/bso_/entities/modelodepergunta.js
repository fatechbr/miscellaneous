var ModeloDePergunta = {
    OnLoad: function () {
        //debugger;
        var contexto = Xrm.Page.ui.getFormType();
        var modeloPesquisa = Xrm.Page.getAttribute("bso_modelodepesquisaid").getValue();
        var modeloPesquisaId = modeloPesquisa[0].id;
        var razaoStatus = 0;
        var Campanhas = 0;

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/bso_modelodepesquisaSet(guid'" + modeloPesquisaId + "')?$select=statecode,statuscode", true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                this.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.responseText).d;
                    var statecode = result.statecode;
                    var statuscode = result.statuscode;
                    razaoStatus = result.statuscode.Value;
                }

                if (contexto == 1 && razaoStatus == 100000001) {
                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/CampaignSet?$select=Name&$filter=bso_ModelodePesquisaId/Id eq (guid'" + modeloPesquisaId + "') and StatusCode/Value eq 861500001", true);
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            this.onreadystatechange = null;
                            if (this.status === 200) {
                                var returned = JSON.parse(this.responseText).d;
                                var results = returned.results;
                                for (var i = 0; i < results.length; i++) {
                                    var name = results[i].Name;
                                }
                                Campanhas = results.length;

                                if (Campanhas > 0) {
                                    alert("Não é possível criar um modelo, pois existem Campanhas com o status 'Pesquisa enviada', utilizando o Modelo de pesquisa envolvido.");
                                    Xrm.Page.getControl("bso_hierarquiadapergunta").setDisabled(true);
                                    Xrm.Page.getAttribute("bso_hierarquiadapergunta").setRequiredLevel("none");
                                    Xrm.Page.getControl("bso_grupo_pergunta").setDisabled(true);
                                    Xrm.Page.getAttribute("bso_grupo_pergunta").setRequiredLevel("none");
                                    Xrm.Page.getControl("bso_tipoderesposta").setDisabled(true);
                                    Xrm.Page.getAttribute("bso_tipoderesposta").setRequiredLevel("none");
                                    Xrm.Page.getControl("bso_name").setDisabled(true);
                                    Xrm.Page.getAttribute("bso_name").setRequiredLevel("none");
                                    Xrm.Page.getControl("bso_ultimapergunta").setDisabled(true);
                                    Xrm.Page.getAttribute("bso_ultimapergunta").setRequiredLevel("none");
                                }
                            }
                        }
                    };
                    req.send();
                }
            }
        };
        req.send();

        if (contexto != 1) {
            ModeloDePergunta.ExibirSubgrids();
        }

        // configuração de onchanges 
        Xrm.Page.getAttribute("bso_tipoderesposta").addOnChange(ModeloDePergunta.ExibirSubgrids);
    },


    FiltrarSubGrid: function () {
        var subGrid = window.parent.document.getElementById("grid_respostas_relacionadas_n_n");
        var perguntaPai = Xrm.Page.getAttribute("bso_pergunta_relacionadaid").getValue();
        if (perguntaPai != null) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>";

            fetchXml += "<entity name='bso_modeloderesposta'>";
            fetchXml += "<attribute name='bso_name' />";
            fetchXml += "<attribute name='createdon' />";
            fetchXml += "<attribute name='bso_ultimapergunta' />";
            fetchXml += "<attribute name='bso_tipoderesposta' />";
            fetchXml += "<attribute name='bso_hierarquiadapergunta' />";
            fetchXml += "<attribute name='bso_modelodeperguntaid' />";
            fetchXml += "<order attribute='bso_name' descending='false' />";
            fetchXml += "<filter type='and'>";
            fetchXml += "<condition attribute='bso_modelodeperguntaid' operator='eq' uitype='bso_modelodepergunta' value='" + perguntaPai[0].id + "' />";
            fetchXml += "<condition attribute='statecode' operator='eq' value='0' />";
            fetchXml += "</filter>";
            fetchXml += "</entity>";
            fetchXml += "</fetch>";
            if (subGrid.control != null) {
                subGrid.control.SetParameter("fetchXml", fetchXml);
                subGrid.control.refresh();
            }
            else {
                setTimeout(FiltrarSubGrid, 500);
            }
        }
    },

    ExibirSubgrids: function () {
        if (Xrm.Page.getAttribute('bso_tipoderesposta').getValue != null) {
            var tipo = Xrm.Page.getAttribute('bso_tipoderesposta').getSelectedOption().text;

            if (tipo == "Opções" || tipo == "Múltipla Escolha" || tipo == "Lista" || tipo == "Régua") {
                Xrm.Page.ui.tabs.get('respostas').setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get('respostas').setVisible(false);
            }
        }
    }    
}