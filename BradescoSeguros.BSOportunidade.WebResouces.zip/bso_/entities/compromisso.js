/// <reference path="\Base\helpers.js" />
/// <reference path="bso_scripts_common.js" />

var TAB_NAME_COMPROMISSO_MERCADO = "appointment";
var TAB_NAME_COMPROMISSO_REDE = "agendaonline";
var OPT_CANAL_MERCADO = 861500000;
var OPT_CANAL_REDE = 861500001;
var OPT_TIPO_COMPROMISSO_OUTROS = 11;
var OPT_TIPO_COMPROMISSO_VISITA_AGENCIA = 2;
var OPT_TIPO_COMPROMISSO_REMOTO = 1;
var OPT_TIPO_COMPROMISSO_VISITA_CORRETOR = 3;
var SECTION_NAME_AGENDAMENTO_AGENCIA = 'section_agencia';
var FIELD_ENVIAR_EMAIL_PARA = "requiredattendees1";
var dataMinima = new Date();
var dataMaxima = new Date();

var Compromisso = {

    OnLoad: function () {
        if (Compromisso.VerificarCanal() == "mercado") {
            Compromisso.ObterDatasLimites();
            //Xrm.Page.data.entity.addOnSave(Compromisso.OnSave);
        }

        console.log("init");
        var optSetCanal = Xrm.Page.getAttribute("bso_canalatendimentousuario");
        if (optSetCanal) {
            switch (optSetCanal.getValue()) {
                case OPT_CANAL_REDE:
                    Compromisso.OnLoadRede();
                    break;
                case OPT_CANAL_MERCADO:
                    Compromisso.OnLoadMercado();
                    break;
                case null:
                    Compromisso.ObterCanalAtendimentoUsuario();
                    break;
                default:
                    Compromisso.OnLoadMercado();
                    break;
            }
        }
    },

    OnSave: function (econtext) {
        if (Compromisso.VerificarCanal() == "mercado" || Compromisso.VerificarCanal() == null) {
            var eventArgs = econtext.getEventArgs();
            if (Compromisso.VerificaFeriado()) {
                eventArgs.preventDefault();
            }
            if (Compromisso.VerificaFinalDeSemana()) {
                eventArgs.preventDefault();
            }
        }
    },

    ObterDatasLimites: function () {
        dataMinima.setDate(dataMinima.getDate() - 30);
        dataMaxima.setDate(dataMaxima.getDate() + 30);
    },

    VerificaDataDeInicio: function () {
        var scheduledstart = Xrm.Page.getAttribute("scheduledstart").getValue();
        if (scheduledstart != null && scheduledstart < dataMinima) {
            alert("Não é permitido a inclusão de compromissos retroativos com mais de 30 dias.");
            Xrm.Page.getAttribute("scheduledstart").setValue(null);
            Xrm.Page.getAttribute("scheduledend").setValue(null);
            return false;
        }
        else if (scheduledstart != null && scheduledstart > dataMaxima) {
            alert("Não é permitido a inclusão de compromissos com mais de 30 dias.");
            Xrm.Page.getAttribute("scheduledstart").setValue(null);
            Xrm.Page.getAttribute("scheduledend").setValue(null);
            return false;
        }
        return true;
    },

    VerificaDataFinal: function () {
        var scheduledend = Xrm.Page.getAttribute("scheduledend").getValue();
        if (scheduledend != null && scheduledend < dataMinima) {
            alert("Não é permitido a inclusão de compromissos retroativos com mais de 30 dias.");
            Xrm.Page.getAttribute("scheduledend").setValue(null);
            return false;
        }
        else if (scheduledend != null && scheduledend > dataMaxima) {
            alert("Não é permitido a inclusão de compromissos com mais de 30 dias.");
            Xrm.Page.getAttribute("scheduledend").setValue(null);
            return false;
        }
        return true;
    },

    VerificarCanal: function () {
        var usuarioId = Xrm.Page.context.getUserId().substr(1, 36);

        var query = "systemusers(" + usuarioId + ")?$select=bso_canal_atendimento_usuario";
        var consulta = Helpers.Buscar(query);
        if (consulta == null || consulta == undefined || consulta.bso_canal_atendimento_usuario == null) {
            return null;
        }
        else {
            return consulta["bso_canal_atendimento_usuario@OData.Community.Display.V1.FormattedValue"].toLowerCase();
        }
    },

    //Carrega guia de acordo com o Canal de Atendimento do usuário.
    ObterCanalAtendimentoUsuario: function () {
        var userId = Xrm.Page.context.getUserId();
        //Remove braces
        userId = userId.substr(1, 36);
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers(" + userId + ")?$select=bso_canal_atendimento_usuario", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    var bso_canaldeatendimento = result["bso_canal_atendimento_usuario"];
                    if (bso_canaldeatendimento == OPT_CANAL_REDE) {
                        console.log("Rede");
                        Compromisso.OnLoadRede();
                    } else {
                        console.log("Mercado");
                        Compromisso.OnLoadMercado();
                    }
                } else {
                    Compromisso.OnLoadMercado();
                }
            }
        };
        req.send();
    },

    OnLoadMercado: function () {
        //Campo oculto para segmentar registros
        Xrm.Page.getAttribute("bso_canalatendimentousuario").setValue(861500000);
        Xrm.Page.ui.tabs.get(TAB_NAME_COMPROMISSO_REDE).setVisible(false);
        Xrm.Page.ui.tabs.get(TAB_NAME_COMPROMISSO_MERCADO).setVisible(true);
        Compromisso.OcultarSucCpd();
        Compromisso.RecuperarEstruturaComercial();
        Compromisso.ConfiguracaoDeEventos();
    },

    OnLoadRede: function () {
        //Campo oculto para segmentar registros
        Xrm.Page.getAttribute("bso_canalatendimentousuario").setValue(861500001);
        Xrm.Page.ui.tabs.get(TAB_NAME_COMPROMISSO_MERCADO).setVisible(false);
        Xrm.Page.ui.tabs.get(TAB_NAME_COMPROMISSO_REDE).setVisible(true);
        //Xrm.Page.getAttribute("bso_tipodecompromisso").setRequiredLevel("none");
        Xrm.Page.getAttribute("bso_atividade").setRequiredLevel("required");
        Compromisso.ConfiguracaoDeEventosRede();
    },

    /*REDE*/
    ConfiguracaoDeEventosRede: function () {
        if (!Compromisso.FormularioMobile()) {
            Compromisso.OnChange_ModifiedOnRede();
        }
        if (GEM.Crm.Common.Methods.isCreateForm() == false) {
            Xrm.Page.getControl("bso_tipo_recorrencia").setDisabled(true);
            Xrm.Page.getControl("bso_termino_recorrencia").setDisabled(true);
        }

        Compromisso.OnChange_ControleTipoCompromissoRede();
        Compromisso.ObterAgenciasPorGECOM();
        Compromisso.ObterAgenciasPorSucursal();
        Xrm.Page.getAttribute("requiredattendees").setValue(null);
        Xrm.Page.getAttribute("requiredattendees").addOnChange(Compromisso.OnChange_Convidados);
        Xrm.Page.getAttribute("bso_atividade").addOnChange(Compromisso.OnChange_ControleTipoCompromissoRede);
        Xrm.Page.getAttribute("bso_atividade").addOnChange(Compromisso.PreencherAssuntoRede);
        Xrm.Page.getAttribute("bso_agencia").addOnChange(Compromisso.OnChange_Agencia);
        Xrm.Page.getAttribute("bso_cep").addOnChange(Compromisso.OnChange_CEPRede);
        Xrm.Page.getAttribute("bso_atualizarendereco").addOnChange(Compromisso.AtualizarEnderecoGoogleMaps);
        Xrm.Page.getAttribute("modifiedon").addOnChange(Compromisso.OnChange_ModifiedOnRede);
        Xrm.Page.data.entity.addOnSave(Compromisso.OnSaveRede);
    },

    FormularioMobile: function () {
        return (Xrm.Page.context.client.getClient() == "Mobile");
    },

    ObterAgenciasPorGECOM: function () {
        var userId = Xrm.Page.context.getUserId();
        userId = userId.substr(1, 36);
        var codsAgencias = "";

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/camp_estruturadistribuicaos?$select=bso_condigodaagencia&$filter=( _camp_usuarioid_value eq " + userId + " or _camp_usuariosup_value eq " + userId + ") and statecode eq 0 and camp_canal eq 861500001 and bso_condigodaagencia ne null", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        codsAgencias += "<value>" + results.value[i]["bso_condigodaagencia"] + "</value>";
                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();


        if (codsAgencias == "") {
            codsAgencias = "<value>-1</value>";
        }
        var fetchXMLCustom = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
            "<entity name='bso_agencia'>" +
            "<attribute name='bso_agenciaid' />" +
            "<attribute name='bso_name' />" +
            "<attribute name='bso_codigodaagencia' />" +
            "<attribute name='bso_classificacao' />" +
            "<order attribute='bso_name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='bso_codigodaagencia' operator='in' >" +
            codsAgencias +
            "</condition>" +
            "</filter>" +
            "</entity>" +
            "</fetch>";

        var layoutXml = "<grid name='resultset' " +
            "object='10007' " +
            "jump='bso_agenciaid' " +
            "select='1' " +
            "icon='1' " +
            "preview='1'>" +
            "<row name='result' " +
            "id='bso_agenciaid'>" +
            "<cell name='bso_name' " +
            "width='150' />" +
            "<cell name='bso_codigodaagencia' " +
            "width='125' />" +
            "<cell name='bso_classificacao' " +
            "width='100' />" +
            "</row>" +
            "</grid>";

        //Guid utilizado como referencia para uso em tempo de execução do formulário apenas.
        //Nao é gravado na base.
        var viewId = "{00000000-0000-0000-0000-000000000001}";
        var entityName = "bso_agencia";
        var viewDisplayName = "AgenciasPorGECOM";
        var fetchXml = fetchXMLCustom;
        var isDefault = false;
        Xrm.Page.getControl("bso_agencia").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, isDefault);
    },


    ObterAgenciasPorSucursal: function () {
        var userId = Xrm.Page.context.getUserId();
        userId = userId.substr(1, 36);
        var codsAgencias = "";
        var idBU = "";
        var guidEmpty = "00000000-0000-0000-0000-000000000000";
        var listaUsurariosSucursal = "\"" + guidEmpty + "\"";

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers(" + userId + ")?$select=_businessunitid_value", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    idBU = result["_businessunitid_value"];

                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();

        if (idBU != "") {

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers?$select=systemuserid&$filter=_businessunitid_value eq " + idBU, false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        for (var i = 0; i < results.value.length; i++) {
                            listaUsurariosSucursal += ",\"" + results.value[i]["systemuserid"] + "\"";
                        }
                    } else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();
        }



        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/camp_estruturadistribuicaos?$select=bso_condigodaagencia&$filter=Microsoft.Dynamics.CRM.In(PropertyName='camp_usuarioid',PropertyValues=[" + listaUsurariosSucursal + "]) and statecode eq 0 and camp_canal eq 861500001 and bso_condigodaagencia ne null", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        codsAgencias += "<value>" + results.value[i]["bso_condigodaagencia"] + "</value>";
                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();


        if (codsAgencias == "") {
            codsAgencias = "<value>-1</value>";
        }
        var fetchXMLCustom = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
            "<entity name='bso_agencia'>" +
            "<attribute name='bso_agenciaid' />" +
            "<attribute name='bso_name' />" +
            "<attribute name='bso_codigodaagencia' />" +
            "<attribute name='bso_classificacao' />" +
            "<order attribute='bso_name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='bso_codigodaagencia' operator='in' >" +
            codsAgencias +
            "</condition>" +
            "</filter>" +
            "</entity>" +
            "</fetch>";

        var layoutXml = "<grid name='resultset' " +
            "object='10007' " +
            "jump='bso_agenciaid' " +
            "select='1' " +
            "icon='1' " +
            "preview='1'>" +
            "<row name='result' " +
            "id='bso_agenciaid'>" +
            "<cell name='bso_name' " +
            "width='150' />" +
            "<cell name='bso_codigodaagencia' " +
            "width='125' />" +
            "<cell name='bso_classificacao' " +
            "width='100' />" +
            "</row>" +
            "</grid>";

        //Guid utilizado como referencia para uso em tempo de execução do formulário apenas.
        //Nao é gravado na base.
        var viewId = "{00000000-0000-0000-0000-000000000002}";
        var entityName = "bso_agencia";
        var viewDisplayName = "AgenciasPorSucursal";
        var fetchXml = fetchXMLCustom;
        var isDefault = true;
        Xrm.Page.getControl("bso_agencia").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, isDefault);
    },

    PreencherAssuntoRede: function () {
        var assunto = Xrm.Page.getAttribute("subject");
        if (assunto) {
            GEM.Crm.Common.Functions.concatenateString("bso_atividade,-,scheduledstart", "subject");
        }
    },

    SalvarNovoRede: function () {
        //criação do objeto de parametros a serem passados
        var parameters = {};
        //Texto
        var Assunto = Xrm.Page.getAttribute("subject").getValue();
        var Descricao = Xrm.Page.getAttribute("description").getValue();
        var Cliente = Xrm.Page.getAttribute("bso_cliente").getValue();
        var Cep = Xrm.Page.getAttribute("bso_cep").getValue();
        var Rua = Xrm.Page.getAttribute("bso_rua").getValue();
        var Bairro = Xrm.Page.getAttribute("bso_bairro").getValue();
        var Cidade = Xrm.Page.getAttribute("bso_cidade").getValue();
        var Estado = Xrm.Page.getAttribute("bso_estado").getValue();
        var UrlMapa = Xrm.Page.getAttribute("bso_urlmapa").getValue();
        var Outros = Xrm.Page.getAttribute("bso_outros").getValue();

        //OptionSet
        var Atividade = Xrm.Page.getAttribute("bso_atividade").getValue();
        var Lembrete = Xrm.Page.getAttribute("bso_adicionarlembrete").getValue();

        //Two Options
        var Remotoprevidencia = Xrm.Page.getAttribute("bso_acompremotoprevidencia").getValue();
        var DefasagensResultados = Xrm.Page.getAttribute("bso_acompanhamentodefasagensresultados").getValue();
        var PrevidenciaGerente = Xrm.Page.getAttribute("bso_acompanhamentoprevidencia").getValue();
        var AlinhamentoGeral = Xrm.Page.getAttribute("bso_alinhamentogerentegeral").getValue();
        var ReunioesProdutos = Xrm.Page.getAttribute("bso_reunioesprodutosgerentes").getValue();
        var VisitaCorretor = Xrm.Page.getAttribute("bso_visitaexterna").getValue();

        //Data
        var DataInicio = Xrm.Page.getAttribute("scheduledstart").getValue();
        var DataTemino = Xrm.Page.getAttribute("scheduledend").getValue();

        //Consulta
        var Agencia = Xrm.Page.getAttribute("bso_agencia").getValue();

        //atribuição de dados da agencia (campo consulta) nos parametros
        if (Agencia) {
            parameters["bso_agencia"] = Agencia[0].id;
            parameters["bso_agencianame"] = Agencia[0].name;
        }

        if (Assunto != null)
            parameters["subject"] = Assunto;

        if (Descricao != null)
            parameters["description"] = Descricao;

        if (Cliente != null)
            parameters["bso_cliente"] = Cliente;

        if (Cep != null)
            parameters["bso_cep"] = Cep;

        if (Rua != null)
            parameters["bso_rua"] = Rua;

        if (Bairro != null)
            parameters["bso_bairro"] = Bairro;

        if (Cidade != null)
            parameters["bso_cidade"] = Cidade;

        if (Estado != null)
            parameters["bso_estado"] = Estado;

        if (UrlMapa != null)
            parameters["bso_urlmapa"] = UrlMapa;

        if (Outros != null)
            parameters["bso_outros"] = Outros;

        if (Atividade != null)
            parameters["bso_atividade"] = Atividade;

        if (Lembrete != null)
            parameters["bso_adicionarlembrete"] = Lembrete;

        if (Remotoprevidencia != null)
            parameters["bso_acompremotoprevidencia"] = +Remotoprevidencia;

        if (DefasagensResultados != null)
            parameters["bso_acompanhamentodefasagensresultados"] = +DefasagensResultados;

        if (PrevidenciaGerente != null)
            parameters["bso_acompanhamentoprevidencia"] = +PrevidenciaGerente;

        if (AlinhamentoGeral != null)
            parameters["bso_alinhamentogerentegeral"] = +AlinhamentoGeral;

        if (ReunioesProdutos != null)
            parameters["bso_reunioesprodutosgerentes"] = +ReunioesProdutos;

        if (VisitaCorretor != null) {
            parameters["bso_visitaexterna"] = +VisitaCorretor;
        }


        if (Compromisso.FormularioMobile() == false) {
            //Set Timezone
            if (DataInicio != null)
                parameters["scheduledstart"] = DataInicio.format("yyyy-MM-dd'T'HH:mm:ss.sszzz");

            if (DataTemino != null)
                parameters["scheduledend"] = DataTemino.format("yyyy-MM-dd'T'HH:mm:ss.sszzz");
        } else {
            if (DataInicio != null)
                parameters["scheduledstart"] = DataInicio;

            if (DataTemino != null)
                parameters["scheduledend"] = DataTemino;
        }

        //chama a nova janela pasando os parametros para os campos virem preenchidos
        Xrm.Utility.openEntityForm("appointment", null, parameters);
    },

    OnSaveRede: function (evt) {


        var eventArgs = evt.getEventArgs();
        var optTipoCompromisso = Xrm.Page.getAttribute('bso_atividade');
        if (optTipoCompromisso) {
            var optValueTipoCompromisso = optTipoCompromisso.getValue();
            switch (optValueTipoCompromisso) {
                case OPT_TIPO_COMPROMISSO_REMOTO:
                    var previdencia = Xrm.Page.getAttribute("bso_acompremotoprevidencia");
                    var defasagensresultados = Xrm.Page.getAttribute("bso_acompanhamentodefasagensresultados");
                    if ((!previdencia && !defasagensresultados) || (previdencia.getValue() != true && defasagensresultados.getValue() != true)) {
                        alert("Você deve selecionar pelo menos um item de detalhamento de atividade.");
                        eventArgs.preventDefault();
                    }
                    break;
                case OPT_TIPO_COMPROMISSO_VISITA_AGENCIA:
                    var previdencia = Xrm.Page.getAttribute("bso_acompanhamentoprevidencia");
                    var alinhamento = Xrm.Page.getAttribute("bso_alinhamentogerentegeral");
                    var reunioesprodutos = Xrm.Page.getAttribute("bso_reunioesprodutosgerentes");
                    if ((!previdencia && !alinhamento && !reunioesprodutos) ||
                        (previdencia.getValue() != true && alinhamento.getValue() != true && reunioesprodutos.getValue() != true)
                    ) {
                        alert("Você deve selecionar pelo menos um item de detalhamento de atividade.");
                        eventArgs.preventDefault();
                    }
                    break;
            }
        }

        /*  if (Xrm.Page.getAttribute("requiredattendees") != null && Xrm.Page.getAttribute("requiredattendees").getValue() != null) {
              var convidados = Xrm.Page.getAttribute("requiredattendees").getValue();
              var listaConvidados = Xrm.Page.getAttribute("bso_convidados").getValue();
  
              if (listaConvidados == null) { listaConvidados = ""; } else {
                  listaConvidados = " + " + listaConvidados;
              }
              if (convidados != null) {
                  for (var i = 0; i < convidados.length; i++) {
                      listaConvidados = convidados[i].name + " " + listaConvidados;
                  }
                  Xrm.Page.getAttribute("bso_convidados").setValue(listaConvidados);
              }
              //Xrm.Page.data.entity.save().then(Compromisso.Salvar_Convidados,Compromisso.Salvar_Convidados)
  
              setTimeout(function () {
                  Xrm.Page.ui.close();
              }, 1500);
  
  
          }*/

    },

    Salvar_Convidados: function () {
        vId = Xrm.Page.data.entity.getId();
        Xrm.Utility.openEntityForm("appointment", vId);
    },

    OnChange_ModifiedOnRede: function () {

        if (GEM.Crm.Common.Methods.isUpdateForm() || Xrm.Page.data.entity.getId() != '') {
            var adicionarLembrete = Xrm.Page.getControl("bso_adicionarlembrete");
            if (adicionarLembrete) {
                adicionarLembrete.setDisabled(true);
            }
        }
    },

    OnChange_Agencia: function () {
        var agencia = Xrm.Page.getAttribute("bso_agencia").getValue();
        Xrm.Page.getAttribute("bso_rua").setValue(null);
        Xrm.Page.getAttribute("bso_bairro").setValue(null);
        Xrm.Page.getAttribute("bso_cidade").setValue(null);
        Xrm.Page.getAttribute("bso_estado").setValue(null);
        Xrm.Page.getAttribute("bso_cep").setValue(null);
        Xrm.Page.getAttribute("bso_classificacao").setValue(null);
        if (agencia) {
            Compromisso.ObterDadosAgencia(agencia[0].id)
        }
    },

    ObterDadosAgencia: function (idAgencia) {
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_agencias(" + idAgencia.substr(1, 36) + ")?$select=bso_rua,bso_cidade,bso_estado,bso_cep,bso_classificacao&$filter=statecode eq 0", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var agencia = JSON.parse(this.response);
                    if (agencia) {
                        Xrm.Page.getAttribute("bso_rua").setValue(agencia["bso_rua"]);
                        Xrm.Page.getAttribute("bso_cidade").setValue(agencia["bso_cidade"]);
                        Xrm.Page.getAttribute("bso_estado").setValue(agencia["bso_estado"]);
                        Xrm.Page.getAttribute("bso_cep").setValue(('00000000' + agencia["bso_cep"]).slice(-8));
                        Xrm.Page.getAttribute("bso_classificacao").setValue(agencia["bso_classificacao"]);
                        if (GEM.Crm.Common.Methods.isCreateForm() == true) {
                            Xrm.Page.data.entity.save(null);
                        }
                    }
                } else {
                    console.log("Agencia não encontrada.");
                }
            }
        };
        req.send();
    },

    OnChange_CEPRede: function () {
        if (Xrm.Page.getAttribute("bso_cep").getValue() != null) {
            GEM.Crm.Common.Methods.fillAddressByCEP("bso_cep", "bso_rua", "bso_bairro", "bso_cidade", "bso_estado", null);
        }
    },

    AtualizarEnderecoGoogleMaps: function () {
        if (Xrm.Page.getAttribute("bso_atualizarendereco").getValue() != null &&
            Xrm.Page.getAttribute("bso_atualizarendereco").getValue() == true) {

            Xrm.Page.getControl("bso_atualizarendereco").setDisabled(true);
            //Atualiza Mapa e Link
            if (Compromisso.FormularioMobile() == true) {



                var rua = Xrm.Page.getAttribute("bso_rua").getValue();
                var bairro = Xrm.Page.getAttribute("bso_bairro").getValue();
                var cidade = Xrm.Page.getAttribute("bso_cidade").getValue();
                var estado = Xrm.Page.getAttribute("bso_estado").getValue();
                var cep = Xrm.Page.getAttribute("bso_cep").getValue();
                var address = "";

                if (rua != null)
                    address = address + rua;

                if (bairro != null)
                    address = address + " - " + bairro;

                if (cidade != null)
                    address = address + "," + cidade;

                if (estado != null)
                    address = address + " - " + estado;

                if (cep != null)
                    address = address + "," + cep;


                var urlMapa = "https://www.google.com/maps/search/?api=1&query=" + address;

                Xrm.Page.getAttribute("bso_urlmapa").setValue(encodeURI(urlMapa));
                var botaoAtualizarEndereco = Xrm.Page.getAttribute("bso_atualizarendereco");
                if (botaoAtualizarEndereco) {
                    Xrm.Page.getControl("bso_atualizarendereco").setDisabled(false);
                    botaoAtualizarEndereco.setValue(false);
                }

            } else {
                var webResourceControl = Xrm.Page.getControl("WebResource_googleMaps");
                var src = webResourceControl.getSrc();
                webResourceControl.setSrc(null);
                webResourceControl.setSrc(src);
            }
        }
    },

    OnChange_ControleTipoCompromissoRede: function () {
        var optTipoCompromisso = Xrm.Page.getAttribute('bso_atividade');
        if (optTipoCompromisso) {
            var optValueTipoCompromisso = optTipoCompromisso.getValue();
            Compromisso.MostrarSecoesPorTipoCompromissoRede(optValueTipoCompromisso);
        }
    },

    MostrarSecoesPorTipoCompromissoRede: function (optValueTipoCompromisso) {
        switch (optValueTipoCompromisso) {
            case OPT_TIPO_COMPROMISSO_REMOTO:
                //Ligacao remota nao faz o uso do email.
                Xrm.Page.getAttribute("bso_agencia").setRequiredLevel("required");
                GEM.Crm.Common.Methods.showSection("agendaonline", "section_DetalhamentoAtividade");
                GEM.Crm.Common.Methods.showFields(["bso_acompremotoprevidencia", "bso_acompanhamentodefasagensresultados"]);
                GEM.Crm.Common.Methods.hideFields(["bso_adicionarlembrete", "bso_acompanhamentoprevidencia", "bso_alinhamentogerentegeral", "bso_reunioesprodutosgerentes", "bso_visitaexterna"]);
                GEM.Crm.Common.Methods.cleanAttributes(["bso_adicionarlembrete", "bso_acompanhamentoprevidencia", "bso_alinhamentogerentegeral", "bso_reunioesprodutosgerentes", "bso_visitaexterna"]);
                break;
            case OPT_TIPO_COMPROMISSO_VISITA_AGENCIA:
                Xrm.Page.getAttribute("bso_agencia").setRequiredLevel("required");
                GEM.Crm.Common.Methods.showSection("agendaonline", "section_DetalhamentoAtividade");
                GEM.Crm.Common.Methods.showFields(["bso_adicionarlembrete", "bso_acompanhamentoprevidencia", "bso_alinhamentogerentegeral", "bso_reunioesprodutosgerentes"]);
                GEM.Crm.Common.Methods.hideFields(["bso_visitaexterna", "bso_acompremotoprevidencia", "bso_acompanhamentodefasagensresultados"]);
                GEM.Crm.Common.Methods.cleanAttributes(["bso_visitaexterna", "bso_acompremotoprevidencia", "bso_acompanhamentodefasagensresultados"]);
                break;
            case OPT_TIPO_COMPROMISSO_VISITA_CORRETOR:
                Xrm.Page.getAttribute("bso_agencia").setRequiredLevel("required");
                GEM.Crm.Common.Methods.showFields(["bso_adicionarlembrete"]);
                Xrm.Page.getAttribute("bso_visitaexterna").setValue(1);
                GEM.Crm.Common.Methods.hideFields(["bso_acompanhamentoprevidencia", "bso_alinhamentogerentegeral", "bso_reunioesprodutosgerentes", "bso_acompremotoprevidencia", "bso_acompanhamentodefasagensresultados"]);
                GEM.Crm.Common.Methods.cleanAttributes(["bso_acompanhamentoprevidencia", "bso_alinhamentogerentegeral", "bso_reunioesprodutosgerentes", "bso_acompremotoprevidencia", "bso_acompanhamentodefasagensresultados"]);
                break;
            default:
                Xrm.Page.getAttribute("bso_agencia").setRequiredLevel("none");
                GEM.Crm.Common.Methods.hideSection("agendaonline", "section_DetalhamentoAtividade");
                GEM.Crm.Common.Methods.cleanAttributes(["bso_acompanhamentoprevidencia", "bso_alinhamentogerentegeral", "bso_reunioesprodutosgerentes", "bso_visitaexterna", "bso_acompremotoprevidencia", "bso_acompanhamentodefasagensresultados"]);
                break;
        }
    },


    /*MERCADO*/
    ConfiguracaoDeEventos: function () {
        Xrm.Page.getAttribute("regardingobjectid").addOnChange(Compromisso.OnChange_ReferenteA);
    },

    OnChange_ReferenteA: function () {
        Compromisso.OcultarSucCpd();
        Compromisso.PreSearchContact();
    },

    OcultarSucCpd: function () {
        var Entidade = Xrm.Page.getAttribute("regardingobjectid").getValue();

        if (Entidade) {
            var ID = Entidade[0].id.substr(1, 36);
            var query = "bso_corretoras?$select=bso_name,bso_succpd&$filter=bso_corretoraid eq " + ID;
            var consulta = Helpers.Buscar(query);
            Compromisso.OcultarSucCpdCallBack(consulta);
        }
    },

    OcultarSucCpdCallBack: function (data) {
        if (data.length > 0) {
            Xrm.Page.ui.controls.get("bso_succpd").setVisible(true);
            if (data[0]["bso_succpd"]) {
                var SucCpd = data[0]["bso_succpd"];
                Xrm.Page.getAttribute('bso_succpd').setValue(SucCpd);
            }
        }
        else {
            Xrm.Page.getAttribute('bso_succpd').setValue(null);
            Xrm.Page.ui.controls.get("bso_succpd").setVisible(false);
        }
    },

    RecuperarEstruturaComercial: function () {
        var EntidadeID = Xrm.Page.getAttribute("ownerid").getValue()[0].id.substr(1, 36);
        var query = "systemusers(" + EntidadeID + ")/camp_systemuser_camp_estruturadistribuicao?$select=camp_surcursal,camp_supexregional,_camp_usuariosup_value&$orderby=createdon desc &$filter=camp_surcursal ne null and camp_supexregional ne null &$top=1"
        var consulta = Helpers.Buscar(query);
        Compromisso.RecuperarEstruturaComercialCallBack(consulta);

    },

    RecuperarEstruturaComercialCallBack: function (data) {

        if (data.length > 0) {
            if (data[0]["camp_surcursal"])
                Xrm.Page.getAttribute('bso_sucursal').setValue(data[0]["camp_surcursal"]);
            if (data[0]["camp_supexregional"])
                Xrm.Page.getAttribute('bso_supexregional').setValue(data[0]["camp_supexregional"]);

            if (data[0]["_camp_usuariosup_value"]) {
                var query = "systemusers?$select=fullname&$filter=systemuserid eq " + data[0]["_camp_usuariosup_value"];
                var consulta = Helpers.Buscar(query);
                Compromisso.RecuperarEstruturaComercialCallBack2(consulta);
            }
        }
    },

    RecuperarEstruturaComercialCallBack2: function (data) {
        if (data.length > 0) {
            if (data[0]["fullname"])
                Xrm.Page.getAttribute('bso_superintendente').setValue(data[0]["fullname"]);
        }
    },

    PreSearchContact: function () {

    },

    MarcarComoCancelada: function () {
        var compromisso = {};
        compromisso.statecode = 2;
        compromisso.statuscode = 4;
        var id = Xrm.Page.data.entity.getId().substr(1, 36);
        var query = "appointments(" + id + ")";
        var retorno = Helpers.Atualizar(query, compromisso)
        if (retorno == null)
            Xrm.Page.ui.close();
        else
            alert("Não foi possível cancelar esse compromisso. Verifique com o administrador do sistema.");

    },

    MarcarComoConcluida: function () {
        var compromisso = {};
        compromisso.statecode = 1;
        compromisso.statuscode = 3;
        var id = Xrm.Page.data.entity.getId().substr(1, 36);
        var query = "appointments(" + id + ")";
        var retorno = Helpers.Atualizar(query, compromisso)
        if (retorno == null)
            Xrm.Page.data.refresh();
        else
            alert("Não foi possível concluir esse compromisso. Verifique com o administrador do sistema.");
    },

    ObterCalendarioDeFeriadosId: function ()
    {
        var query = "organizations?$select=businessclosurecalendarid";
        var consulta = Helpers.Buscar(query);
        if (consulta.length == 0 || consulta[0]["businessclosurecalendarid"] == null)
        {
            return null;
        }
        else
        {
            return consulta[0]["businessclosurecalendarid"];
        }
    },

    VerificaFeriado: function ()
    {
        var dataDeInicio = Xrm.Page.getAttribute('scheduledstart').getValue();
        var dataFim = Xrm.Page.getAttribute('scheduledend').getValue();

        var calendarioId = Compromisso.ObterCalendarioDeFeriadosId();
        if (calendarioId) {
            var query = "calendars(" + calendarioId + ")/calendar_calendar_rules?$select=starttime,name";
            var consulta = Helpers.Buscar(query);
            if (consulta.length > 0) {
                for (var i = 0; i < consulta.length; i++) {
                    var date = new Date(consulta[i]["starttime"])
                    var userTimezoneOffset = date.getTimezoneOffset() * 60000;	//Ignorar timezone				
                    var feriado = new Date(date.getTime() + userTimezoneOffset);
                    if (dataDeInicio) {
                        if (Helpers.DatasIguais(dataDeInicio, feriado)) {
                            alert(" Não é possível criar este Compromisso. \n A Data de 'Início' do Compromisso é FERIADO. \n Favor mudar. ");
                            Xrm.Page.getAttribute('scheduledstart').setValue(null);
                            return true;
                        }
                    }
                    if (dataFim) {
                        if (Helpers.DatasIguais(dataFim, feriado)) {
                            alert(" Não é possível criar este Compromisso. \n A Data de 'Fim' do Compromisso é FERIADO. \n Favor mudar. ");
                            Xrm.Page.getAttribute('scheduledend').setValue(null);
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    },

    VerificaFinalDeSemana: function ()
    {
        var dataDeInicio = Xrm.Page.getAttribute('scheduledstart').getValue();
        var dataFim = Xrm.Page.getAttribute('scheduledend').getValue();
        if (dataDeInicio)
        {
            if (dataDeInicio.getDay() == 0 || dataDeInicio.getDay() == 6) {
                alert(" Não é possível criar este Compromisso. \n A Data de 'Início' do Compromisso é Final de Semana. \n Favor mudar. ");
                Xrm.Page.getAttribute('scheduledstart').setValue(null);
                return true;
            }
        }
        if (dataFim) {
            if (dataFim.getDay() == 0 || dataFim.getDay() == 6) {
                alert(" Não é possível criar este Compromisso. \n A Data 'Fim' do Compromisso é Final de Semana. \n Favor mudar. ");
                Xrm.Page.getAttribute('scheduledend').setValue(null);
                return true;
            }
        }
        return false;
    }
}