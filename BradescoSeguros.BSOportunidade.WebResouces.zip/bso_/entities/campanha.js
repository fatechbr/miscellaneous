/// <reference path="\Base\helpers.js" />

var Campanha = {
    OnLoad: function () {

        var TipoCampanha = Xrm.Page.getAttribute("typecode").getValue();

        //SE Pesquisa de Mercado - executa regras de pesquisa de Mercado
        if (TipoCampanha == 100000000) {
            Campanha.OnLoadPesquisaMercado();
        }
        else {
            //Continua executando regras existentes anteriormente
            Xrm.Page.getAttribute("bso_datadeenviodapesquisa").addOnChange(Campanha.OnChange_bso_datadeenviodapesquisa);            
        }
    },

    OnLoadPesquisaMercado: function () {
        Campanha.ExibeConfigCalcAmostral();
        Campanha.ExibeGridsAtividades();
        Campanha.ExibeCampos();
        Campanha.DeCampo();

        //Controle de Templates quando canal = a CallCenter
        if (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000000) {
            //Exibe Templates
            Campanha.ExibeTemplates(true);
            Xrm.Page.getControl("bso_filaid").setVisible(true);
            Xrm.Page.getAttribute("bso_filaid").setRequiredLevel("required");
        }
        else {
            Campanha.ExibeTemplates(false);
            Xrm.Page.getControl("bso_filaid").setVisible(false);
            Xrm.Page.getAttribute("bso_filaid").setRequiredLevel("none");
        }

        //Bloqueia campos quando o status da Pesquisa for igual a Pesquisa Enviada
        if (Xrm.Page.getAttribute('statuscode').getValue() == 861500001) {
            Xrm.Page.getControl("bso_tipo_avaliacao").setDisabled(true);
            Xrm.Page.getControl("bso_canais_entrada").setDisabled(true);
            Xrm.Page.getControl("statuscode").setDisabled(true);
            Xrm.Page.getControl("bso_feedbackid").setDisabled(true);
            Xrm.Page.getControl("bso_modelodepesquisaid").setDisabled(true);
            Xrm.Page.getControl("typecode").setDisabled(true);
            Xrm.Page.getControl("bso_filaid").setDisabled(true);
            Xrm.Page.getControl("bso_datadeenviodapesquisa").setDisabled(true);
        }

        if (Xrm.Page.getAttribute('statuscode').getValue() == 861500001 && (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000001 || Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000003)) {
            Xrm.Page.getControl("bso_link").setVisible(true);
        }
    },

    //Regra existente antes do projeto de Pesquisa de Mercado
    OnChange_bso_datadeenviodapesquisa: function () {
        Campanha.AtualizarDataDeVencimento();
    },

    //Regra para o Projeto Pesquisa de Mercado: exibir grids e campos (Typecode = Pesquisa - Mercado)
    OnChange_bso_typecode: function () {
        var TipoCampanha = Xrm.Page.getAttribute("typecode").getValue();
        //SE Pesquisa de Mercado - executa regras de pesquisa de Mercado
        if (TipoCampanha == 100000000) {
            Campanha.ExibeGridsAtividades();
            Campanha.ExibeCampos();
        }
        else {
            Campanha.OcultaCampos();
        }
    },

    //Regra para o Projeto Pesquisa de Mercado: exibir templates (canal CallCenter)
    OnChange_bso_canais_entrada: function () {
        Campanha.DeCampo();
        //Controle de Templates quando canal = a CallCenter
        if (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000000) {
            //Exibe Templates
            Campanha.ExibeTemplates(true);
            //Exibe campo Fila e o deixa obrigatório
            Xrm.Page.getControl("bso_filaid").setVisible(true);
            Xrm.Page.getAttribute("bso_filaid").setRequiredLevel("required");
            Xrm.Page.getAttribute("bso_template_inicio_ligacao").setRequiredLevel("required");
            Xrm.Page.getAttribute("bso_template_saudacao").setRequiredLevel("required");
        }
        else {
            Campanha.ExibeTemplates(false);
            //Oculta campo Fila e não o deixa obrigatório
            Xrm.Page.getControl("bso_filaid").setVisible(false);
            Xrm.Page.getAttribute("bso_filaid").setRequiredLevel("none");
            Xrm.Page.getAttribute("bso_template_inicio_ligacao").setRequiredLevel("none");
            Xrm.Page.getAttribute("bso_template_saudacao").setRequiredLevel("none");
        }        
    },

    DeCampo: function () {
        //Se Canal de Entrada = a De Campo
        if (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000001) {
            // Exibe e obriga o campo 'Entrevistador'
            Xrm.Page.getControl("bso_entrevistador").setVisible(true);
            Xrm.Page.getAttribute("bso_entrevistador").setRequiredLevel("required");
        }
        else {
            Xrm.Page.getControl("bso_entrevistador").setVisible(false);
            Xrm.Page.getAttribute("bso_entrevistador").setRequiredLevel("none");
        }
    },

    //Regra para o Projeto Pesquisa de Mercado: exibir guia do cálculo amostral (Tipo de Avaliação = Amostral)
    OnChange_bso_tipo_avaliacao: function () {
        Campanha.ExibeConfigCalcAmostral();
    },

    OnChange_bso_feedback_bso_typecode: function () {
        var feedback = Xrm.Page.getAttribute("bso_feedbackid").getValue();
        var tipoCampanha = Xrm.Page.getAttribute("bso_canais_entrada").getValue();
        var itens = false;
        if (feedback != null && tipoCampanha != null) {
            var feedbackid = feedback[0].id;
            //Consultar se existe itens de feedback vinculados ao feedback            
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/bso_itemdofeedbackSet?$select=bso_name&$filter=bso_FeedbackId/Id eq (guid'" + feedbackid + "')&$top=1", false);
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    this.onreadystatechange = null;
                    if (this.status === 200) {
                        var returned = JSON.parse(this.responseText).d;
                        var results = returned.results;
                        if (results.length > 0) {
                            itens = true;
                        }
                    }
                }
            };
            req.send();

            if ((tipoCampanha == 100000001 || tipoCampanha == 100000003) && itens == true) {
                alert("Existem Itens de Feedback vinculados ao Feedback. \n Para utilizar o tipo de campanha' " + Xrm.Page.getAttribute("bso_canais_entrada").getText() + "', é necessário que o Feedback esteja vazio.");
                Xrm.Page.getAttribute("bso_feedbackid").setValue(null); //apagar valor do campo Feedback
                Xrm.Page.getAttribute("bso_canais_entrada").setValue(null); //apagar valor do campo Canal de Entrada
            }

            else if ((tipoCampanha != 100000001 && tipoCampanha != 100000003) && itens == false) {
                alert("O Feedback selecionado não contém registros de Item de Feedback. \n Para utilizar o tipo de campanha' " + Xrm.Page.getAttribute("bso_canais_entrada").getText() + "', é necessário que o Feedback contenha registros de entrevistados.");
                Xrm.Page.getAttribute("bso_feedbackid").setValue(null); //apagar valor do campo Feedback
                Xrm.Page.getAttribute("bso_canais_entrada").setValue(null); //apagar valor do campo Canal de Entrada
            }
        }
    },

    //Regra existente antes do projeto de Pesquisa de Mercado - alerado para não executar quando for Pesquisa - Mercado
    OnSave: function (econtext) {
        var TipoCampanha = Xrm.Page.getAttribute("typecode").getValue();
        if (TipoCampanha != 100000000) {
            var eventArgs = econtext.getEventArgs();
            if (!Campanha.DataDeEnvioDaPesquisaValido()) {
                eventArgs.preventDefault();
            }
        }
    },

    //Ação para exibir os principais campos de uso da Pesquisa de Mercado
    ExibeCampos: function () {
        //Os 2 campos devem ser obrigatórios quando a campanha for do tipo Pesquisa de Mercado
        Xrm.Page.getControl("bso_feedbackid").setVisible(true);
        Xrm.Page.getAttribute("bso_feedbackid").setRequiredLevel("required");
        Xrm.Page.getControl("bso_modelodepesquisaid").setVisible(true);
        Xrm.Page.getAttribute("bso_modelodepesquisaid").setRequiredLevel("required");
        Xrm.Page.getAttribute("bso_datadeenviodapesquisa").setRequiredLevel("required");

        //Os 3 campos devem apenas ficaren visiveis
        Xrm.Page.getControl("bso_objetivos").setVisible(true);
        Xrm.Page.getControl("bso_motivos").setVisible(true);
        Xrm.Page.getControl("bso_tipo_avaliacao").setVisible(true);

    },

    //Ação para ocultar os principais campos de uso da Pesquisa de Mercado
    OcultaCampos: function () {
        //Os 2 campos não devem ser obrigatórios quando a campanha for do tipo diferente de Pesquisa de Mercado
        Xrm.Page.getControl("bso_feedbackid").setVisible(false);
        Xrm.Page.getAttribute("bso_feedbackid").setRequiredLevel("none");
        Xrm.Page.getControl("bso_modelodepesquisaid").setVisible(false);
        Xrm.Page.getAttribute("bso_modelodepesquisaid").setRequiredLevel("none");
        Xrm.Page.getAttribute("bso_datadeenviodapesquisa").setRequiredLevel("none");

        //Os 3 campos devem apenas ficarem ocultos
        Xrm.Page.getControl("bso_objetivos").setVisible(false);
        Xrm.Page.getControl("bso_motivos").setVisible(false);
        Xrm.Page.getControl("bso_tipo_avaliacao").setVisible(false);

    },

    //Ação para exibir ou não  os campos de controle
    ExibeTemplates: function (exibe) {
        Xrm.Page.ui.tabs.get("templates").setVisible(exibe);
    },

    //Regra para o Projeto Pesquisa de Mercado e demais: validação de preenchimento dos campos antes de ativar a campanha e exibição de alertas
    EnviarPesquisa: function () {
        var tipoPesquisa = Xrm.Page.getAttribute("typecode").getValue();
        if (tipoPesquisa == 100000000) {
            //Campanhas iguais a Pesquisa de Mercado
            var MensagemErro = "As seguintes informações devem ser preenchidas antes de ativar a pesquisa: \n";
            var controle = false;
            if (Xrm.Page.getAttribute("bso_tipo_avaliacao").getText() == "Amostral" && Xrm.Page.getAttribute("bso_config_calculo_amostral").getValue() == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Antes de enviar a Campanha é necessário cadastrar uma nova configuração de cálculo Amostral! \n";
                Xrm.Page.getControl("bso_config_calculo_amostral").setFocus(true);
            }
            if (Xrm.Page.getAttribute("bso_motivos").getValue() == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Motivo \n";
            }

            if (Xrm.Page.getAttribute("bso_objetivos").getValue() == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Objetivos \n";
            }

            if (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Canal de Entrada \n ";
            }

            if (Xrm.Page.getAttribute("bso_tipo_avaliacao").getValue() == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Tipo de Avaliação \n";
            }

            if (controle) {
                alert(MensagemErro);
            }
            else {

                //Define link se a campanha for do tipo "De Campo" ou "Mídia Social
                if (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000001 || Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000003) {
                    var URLOrganizacao = Xrm.Page.context.getClientUrl();
                    var Organizacao = "http://wscrm.bradseg.com.br";
                    var id = Xrm.Page.data.entity.getId();
                    Xrm.Page.getAttribute("bso_link").setValue(Organizacao + ":5555/PesquisaMercado/Cliente/Create?id=" + id);
                    Xrm.Page.getControl("bso_link").setVisible(true);
                }
                Xrm.Page.data.entity.save();
                //Bloqueia os campos para edição
                Xrm.Page.getControl("bso_tipo_avaliacao").setDisabled(true);
                Xrm.Page.getControl("bso_canais_entrada").setDisabled(true);
                Xrm.Page.getControl("statuscode").setDisabled(true);
                Xrm.Page.getControl("bso_feedbackid").setDisabled(true);
                Xrm.Page.getControl("bso_modelodepesquisaid").setDisabled(true);
                Xrm.Page.getControl("typecode").setDisabled(true);
                Xrm.Page.getControl("bso_filaid").setDisabled(true);
                Xrm.Page.getControl("bso_datadeenviodapesquisa").setDisabled(true);
                if (Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000001 || Xrm.Page.getAttribute("bso_canais_entrada").getValue() == 100000003) {
                    Xrm.Page.getControl("bso_link").setVisible(true);
                }
            }
        }
            //Campanhas diferentes de Pesquisa de Mercado - Antigo método CriarPesquisa: function
            var button = confirm("Deseja criar as pesquisas? Se sim, por favor confirme e aguarde.")
            if (button == true) {
                var resultado = Helpers.ExecutarWorkflowSobDemanda("Criar Pesquisas", "campaign", Xrm.Page.data.entity.getId(), false);
                if (resultado == "" || resultado == undefined) {
                    alert("Pesquisas criadas com sucesso.")
                //Altera a razão de status para Pesquisa Enviada e salva o registro
                Xrm.Page.getAttribute('statuscode').setValue(861500001)
                Xrm.Page.data.entity.save();
                    Xrm.Page.data.refresh();
                } else {
                    alert(resultado);
                }
            }
    },

    //Regra para o Projeto Pesquisa de Mercado: para uso do botão na home da entidade.
    EnviarPesquisaHome: function (selectedEntityRefs) {
        debugger;

        var selectedEntityRefsId = selectedEntityRefs[0].Id;
        var amostral = false;
        var controle = false;
        var MensagemErro = "As seguintes informações devem ser preenchidas antes de ativar a pesquisa: \n";

        var resultado;
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/CampaignSet(guid'" + selectedEntityRefsId + "')?$select=bso_canais_entrada,bso_motivos,bso_objetivos,bso_tipo_avaliacao,StatusCode,TypeCode", false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                this.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.responseText).d;
                    var bso_canais_entrada = result.bso_canais_entrada;
                    var bso_motivos = result.bso_motivos;
                    var bso_objetivos = result.bso_objetivos;
                    var bso_tipo_avaliacao = result.bso_tipo_avaliacao;
                    var statusCode = result.StatusCode;
                    var typeCode = result.TypeCode;
                    resultado = result;
                }
            }
        };
        req.send();

        if (resultado.TypeCode.Value == 100000000 && resultado.StatusCode.Value == 0) {

            if (resultado.bso_motivos == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Motivo \n";
            }

            if (resultado.bso_objetivos == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Objetivos \n";
            }

            if (resultado.bso_canais_entrada == null) {
                controle = true;
                MensagemErro = MensagemErro + "- Canal de Entrada \n ";
            }

            if (resultado.bso_tipo_avaliacao.Value == null) {
                controle = true;
                amostral = true;
                MensagemErro = MensagemErro + "- Tipo de Avaliação \n";
            }

            if (controle) {
                alert(MensagemErro);
            }
            else {
                if (amostral) {
                    alert("Esta campanha contém cálculo amostral! \n Necessário conferir as configurações do cálculo antes de ativa-la.");
                }
                else {
                    AtualizaCampanha(selectedEntityRefsId);
                }
            }
        }
        else {
            alert("Ação não permitida! \n Realize as devidas ações dentro do formulário.");
        }
    },

    AcaoBotaoEncerrar: function () {
        if (confirm("A ação atualizará a Campanha com a data atual e a mesma será desativada. \n As pesquisas vinculadas nesta Campanha serão Canceladas e NÃO PODERÃO SER REATIVADAS. \n Se deseja encerrar esta Campanha clique em 'OK', caso contrário, clique em 'CANCELAR' \n \n Uma vez encerrada, a Campanha NÃO PODERÁ SER REATIVADA.")) {
            Xrm.Page.getAttribute("bso_datadevencimentodapesquisa").setValue(new Date);
            Xrm.Page.data.entity.save();
            alert("Em breve esta Campanha será desativada e as Pesquisas com o status 'Ativa' vinculadas a mesma serão Canceladas.");
        }
        else {
            return;
        }
    },

    //Ação existente antes do projeto de Pesquisa de Mercado
    //AtualizarDataDeVencimento: function () {
    //    if (Xrm.Page.getAttribute("typecode").getValue() == 861500000 || Xrm.Page.getAttribute("typecode").getValue() == 861500001) {
    //        var dataDeEnvio = Xrm.Page.getAttribute("bso_datadeenviodapesquisa").getValue();
    //        var dataDeVencimento = new Date(dataDeEnvio);
    //        dataDeVencimento.setDate(dataDeEnvio.getDate() + 3)
    //        dataDeVencimento.setHours(23)
    //        dataDeVencimento.setMinutes(59)
    //        dataDeVencimento.setUTCSeconds(59)
    //        Xrm.Page.getAttribute("bso_datadevencimentodapesquisa").setValue(dataDeVencimento)
    //    }
    //},

    //Ação existente antes do projeto de Pesquisa de Mercado
    DataDeEnvioDaPesquisaValido: function () {

        if (Xrm.Page.getAttribute("typecode").getValue() == 861500000 || Xrm.Page.getAttribute("typecode").getValue() == 861500001) {
            var dataAtual = new Date();

            var dataEnvio = Xrm.Page.getAttribute("bso_datadeenviodapesquisa").getValue();

            if (dataEnvio < dataAtual) {
                alert("Data de envio deve ser maior que data atual");
                return false;
            }
            else {
                return true;
            }
        }
        return true
    },

    //Ação para exibir grid de Configuração do Cálculo Amostral
    ExibeConfigCalcAmostral: function () {

        if (Xrm.Page.getAttribute("bso_tipo_avaliacao").getValue() == 100000000) {
            Xrm.Page.getControl("bso_config_calculo_amostral").setVisible(true);
            //Xrm.Page.getAttribute("bso_config_calculo_amostral").setRequiredLevel("required");
        }
        else {
            Xrm.Page.getControl("bso_config_calculo_amostral").setVisible(false);
            //Xrm.Page.getAttribute("bso_config_calculo_amostral").setRequiredLevel("none");
        }

    },

    //Ação para exibir grids de Atividades
    ExibeGridsAtividades: function () {
        if (Xrm.Page.getAttribute("typecode").getValue() == 100000000) {
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_1").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_5").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_6").setVisible(true);
            Xrm.Page.getControl("statuscode").setDisabled(true);
            Campanha.ExibeTemplates(true);
        }
        else {
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_1").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_5").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_6").setVisible(false);
            Xrm.Page.getControl("statuscode").setDisabled(false);
            Campanha.ExibeTemplates(false);
        }
    }
};

function AtualizaCampanha(selectedEntityRefsId) {
    var entity = {};
    entity.StatusCode = { Value: 861500001 };

    var req = new XMLHttpRequest();
    req.open("POST", Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/CampaignSet(guid'" + selectedEntityRefsId+"')", false);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("X-HTTP-Method", "MERGE");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            this.onreadystatechange = null;
            if (this.status === 204 || this.status === 1223) {
                //Success - No Return Data - Do Something
            }
            else {
                //alert(this.statusText);
            }
        }
    };
    req.send(JSON.stringify(entity));
}