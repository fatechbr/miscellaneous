var PessoaFisica = {
    
    OnLoad: function(){
		if(Xrm.Page.ui.process!=null){
		Xrm.Page.ui.process.setVisible(false);
		}
	},  

    OnSave: function () {
        PessoaFisica.FormartarCampoCPF();
    },

    LimparCaracteresEspeciais: function (texto) {
        var t = texto.replace(/[|&;$%@"<>()+,.-\s]/g, "");
        return t;
    },

    FormartarCampoCPF: function () {
        if (Xrm.Page.getAttribute("bso_cpf").getValue() != null) {
            var cpf = PessoaFisica.LimparCaracteresEspeciais(Xrm.Page.getAttribute("bso_cpf").getValue());
            Xrm.Page.getAttribute("bso_cpf").setValue(cpf);
        }
    }
}