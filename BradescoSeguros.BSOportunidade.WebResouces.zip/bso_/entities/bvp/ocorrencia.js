var Ocorrencia = {
    OnLoad: function () {
        Xrm.Page.getAttribute('bso_assunto').addOnChange(Ocorrencia.OnChangeAssunto);
        Xrm.Page.getAttribute('bso_motivo').addOnChange(Ocorrencia.OnChangeMotivo);
        Xrm.Page.getAttribute('bvp_tipodesolicitao').addOnChange(Ocorrencia.OnChangeTipoSolicitacao);

        Ocorrencia.OnChangeTipoSolicitacao();
    },

    OnChangeTipoSolicitacao: function(){
        Ocorrencia.VisibiidadeSecao()
    },

    OnChangeAssunto: function () {
        if (Xrm.Page.getAttribute('bso_assunto').getValue() == 861500000) {
            Ocorrencia.FiltrarCampoAcao(Ocorrencia.informacao)

        } else if (Xrm.Page.getAttribute('bso_assunto').getValue() == 861500001) {
            Ocorrencia.FiltrarCampoAcao(Ocorrencia.solicitacao)

        } else if (Xrm.Page.getAttribute('bso_assunto').getValue() == 861500002) {
            Ocorrencia.FiltrarCampoAcao(Ocorrencia.reclamacao)
        }
    },

    OnChangeMotivo: function () {
        if (Xrm.Page.getAttribute('bso_motivo').getValue() == 861500000) {
            Ocorrencia.FiltarCampoMotivo(Ocorrencia.relacionamentoComoBanco)

        } else if (Xrm.Page.getAttribute('bso_motivo').getValue() == 861500001) {
            Ocorrencia.FiltarCampoMotivo(Ocorrencia.problemasComoBanco)

        } else if (Xrm.Page.getAttribute('bso_motivo').getValue() == 861500002) {
            Ocorrencia.FiltarCampoMotivo(Ocorrencia.relacionamentoComaSeguradora)

        } else if (Xrm.Page.getAttribute('bso_motivo').getValue() == 861500003) {
            Ocorrencia.FiltarCampoMotivo(Ocorrencia.problemasComaSeguradora)

        } else if (Xrm.Page.getAttribute('bso_motivo').getValue() == 861500004) {
            Ocorrencia.FiltarCampoMotivo(Ocorrencia.melhoresCondicoesOferecidas)
        }
    },

    informacao: [861500000, 861500001, 861500002, 861500003, 861500004, 861500005],
    reclamacao: [861500001, 861500006, 861500009, 861500016],
    solicitacao: [861500001, 861500006, 861500007, 861500008, 861500009, 861500010, 861500011, 861500012, 861500013, 861500014, 861500015, 861500017],
    opcoes: Xrm.Page.getAttribute("bso_acao").getOptions(),

    RetornarOptionPeloValue: function (listaDeOptions, value) {
        return listaDeOptions.filter(function (item) {
            if (item.value == value)
                return item
        })[0]
    },

    FiltrarCampoAcao: function (listaDeValues) {
        Xrm.Page.getControl("bso_acao").clearOptions()
        for (i = 0; i <= listaDeValues.length - 1; i++) {
            Xrm.Page.getControl("bso_acao").addOption(Ocorrencia.RetornarOptionPeloValue(Ocorrencia.opcoes, listaDeValues[i]), 0)
        }
    },

    relacionamentoComoBanco: [861500000, 861500001, 861500002, 861500003, 861500004],
    problemasComoBanco: [861500005, 861500006],
    relacionamentoComaSeguradora: [861500007, 861500008, 861500009],
    problemasComaSeguradora: [861500010, 861500011, 861500012, 861500013],
    melhoresCondicoesOferecidas: [861500014, 861500015, 861500016],
    opcoesSubMotivo: Xrm.Page.getAttribute('bso_submotivo').getOptions(),

    RetornoOptions: function (listaOptions, value) {
        return listaOptions.filter(function (item) {
            if (item.value == value) {
                return item
            }
        })[0]
    },

    FiltarCampoMotivo: function (listaDeMotivos) {
        Xrm.Page.getControl('bso_submotivo').clearOptions()
        for (i = 0; i <= listaDeMotivos.length - 1; i++) {
            Xrm.Page.getControl('bso_submotivo').addOption(Ocorrencia.RetornoOptions(Ocorrencia.opcoesSubMotivo, listaDeMotivos[i]), 0)
        }
    },
    ResolverOcorrencia: function () {
        if (Xrm.Page.getAttribute("bvp_tipodesolicitao").getValue() == 916380001) {
            if (Xrm.Page.getAttribute("bso_motivo").getValue() && Xrm.Page.getAttribute("statecode").getValue() == 0) {
                Mscrm.CommandBarActions.resolve();
                return
            } else if (!Xrm.Page.getAttribute("bso_motivo").getValue() && Xrm.Page.getAttribute("statecode").getValue() == 0) {
                alert("Para resolver a ocorrência, o campo Motivo deve estar preenchido.");
                return;
            }
        }
        Mscrm.CommandBarActions.resolve();
    },

    VisibiidadeSecao: function() {

        var opcao = Xrm.Page.getAttribute("bvp_tipodesolicitao").getValue();
        
        if (opcao == 916380001) {
            Xrm.Page.ui.tabs.get("general").sections.get("general_section_9").setVisible(true);
        } else {
            Xrm.Page.ui.tabs.get("general").sections.get("general_section_9").setVisible(false);
        }
    }
}

