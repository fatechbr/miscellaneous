/// <reference path="bso_scripts_common.js" />

var ModeloPesquisa = {

    OnLoad: function () {
        var razaoStatus = Xrm.Page.getAttribute("statuscode").getValue();
        ModeloPesquisa.OnChangeCanalAtendimento();
        Xrm.Page.getAttribute("bso_canal").addOnChange(ModeloPesquisa.OnChangeCanalAtendimento);        

        //SE Modelo de Pesquisa está "Em Aprovação: bloqueia edição dos campos
        if (razaoStatus == 100000000) {
            Xrm.Page.getControl("bso_name").setDisabled(true);
            Xrm.Page.getControl("bso_tipodeinteracao").setDisabled(true);
            Xrm.Page.getControl("bso_nps").setDisabled(true);
            Xrm.Page.getControl("bso_canal").setDisabled(true);
        }
        else {
            Xrm.Page.getControl("bso_name").setDisabled(false);
            Xrm.Page.getControl("bso_tipodeinteracao").setDisabled(false);
            Xrm.Page.getControl("bso_nps").setDisabled(false);
            Xrm.Page.getControl("bso_canal").setDisabled(false);
        }
    },

    OnChangeCanalAtendimento: function () {
        var optCanalAtendimento = Xrm.Page.getAttribute('bso_canal');
        var isNPS = Xrm.Page.getControl('bso_nps');
        if (isNPS && optCanalAtendimento) {
            var optCanalAtendimentoValue = optCanalAtendimento.getValue();
            if (optCanalAtendimentoValue == 861500001) { //REDE
                isNPS.setVisible(true);
            } else {
                isNPS.setVisible(false);
            }
        }
    }
}