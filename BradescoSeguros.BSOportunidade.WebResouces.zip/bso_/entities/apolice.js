/// <reference path="bs_alert/js/alert.js" />
/// <reference path="helpers.js" />
/// <reference path="C:\CRM\DEV\BradescoSeguros.CRM.Feedback\BradescoSeguros.CRM.Feedback.WebResource\OLD/bso_XRMServiceToolKit.js" />

Apolice = function () {
    var formType = {
        Undefined: 0,
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        QuickCreate: 5,//Deprecated
        BulkEdit: 6,
        ReadOptimized: 11	//Deprecated
    };

    var formSaveMode = {
        Save: 1, //All
        SaveAndClose: 2, //All
        Deactivate: 5, //All
        Reactivate: 6, //All
        Send: 7, //Email
        Disqualify: 15, //Lead
        Qualify: 16, //Lead
        Assign: 47, //User or Team owned entities
        SaveAsCompleted: 58, //Activities
        SaveAndNew: 59, //All
        AutoSave: 70 //All
    };

    var submitMode = {
        Always: "always",
        Never: "never",
        Dirty: "dirty"
    };

    var statusDesignacao = {
        AguardandoDesignacao: 1,
        AguardandoAprovacao: 2,
        AprovacaoConfirmada: 3,
        AprovacaoRecusada: 4,
        DesignacaoCancelada: 5
    };

    //control of all fields
    var controlAllAttribute = function (attributesException) {

        if (attributesException != null && !Array.isArray(attributesException)) throw new Error("The 'attributesException' object is invalid.");

        Xrm.Page.data.entity.attributes.forEach(function (attribute, index) {

            var control = Xrm.Page.getControl(attribute.getName());

            if (control) {

                if (!control.getDisabled()) { control.setDisabled(true); }
                if (attribute.getSubmitMode() !== "never") { attribute.setSubmitMode("never"); }

                if (attributesException != null && attributesException.length > 0) {

                    for (var i in attributesException) {

                        var attributeException = attributesException[i];

                        if ((attributeException == null) || (attributeException != null && (attributeException.Name == null || attributeException.Name === ""))) {
                            if (window.console) console.log("The object 'attributeException' is with attribute 'Name' invalid or invalid.");
                            control.setDisabled(true);
                            attribute.setSubmitMode("never");
                            continue;
                        }

                        if (attributeException.Name.toLowerCase() === attribute.getName().toLowerCase()) {

                            if (attributeException.Disabled != null && (typeof (attributeException.Disabled) === "boolean")) {
                                if (attributeException.Disabled != control.getDisabled()) {
                                    control.setDisabled(attributeException.Disabled);
                                }
                            }

                            if (attributeException.SubmitMode != null && (typeof (attributeException.SubmitMode) === "string")) {
                                switch (attributeException.SubmitMode) {
                                    case "always":
                                    case "never":
                                    case "dirty":
                                        if (attributeException.SubmitMode.toLowerCase() !== attribute.getSubmitMode().toLowerCase()) {
                                            attribute.setSubmitMode(attributeException.SubmitMode);
                                        }
                                        break;
                                    default:
                                        attribute.setSubmitMode("never");
                                        if (window.console) console.log("The object 'attributeException' is with attribute 'SubmitMode (" + attributeException.SubmitMode + ")' invalid or invalid.");
                                }
                            }

                            continue;
                        }
                    }
                } else {
                    control.setDisabled(true);
                    attribute.setSubmitMode("never");
                }
            }
        });
    };

    var designarGerenteRelacionamento = function (eventArgs) {
        debugger;

        var apoliceId = Apolice.Utility.ReplaceBracket(Xrm.Page.data.entity.getId());

        var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_designacao"];
        var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", apoliceId, colsApolice);

        if (retrievedApolice != null) {

            var bsoNumeroApolice = Xrm.Page.getAttribute("bso_numero_apolice").getValue();
            var bsoStatusDesignacao = retrievedApolice.attributes["bso_status_designacao"];

            if (bsoStatusDesignacao != null && (bsoStatusDesignacao.value == statusDesignacao.AguardandoDesignacao || bsoStatusDesignacao.value == statusDesignacao.AprovacaoRecusada)) {

                var bsoGerenteRelacionamentoId = Xrm.Page.getAttribute("bso_gerente_relacionamento").getValue();
                if (bsoGerenteRelacionamentoId != null) {

                    Xrm.Page.data.entity.save();
                    eventArgs.preventDefault();

                    Xrm.Utility.confirmDialog("Deseja designar esta ap\u00f3lice \"" + bsoNumeroApolice + "\" para o gerente de relacionamento \"" + bsoGerenteRelacionamentoId[0].name + "\" selecionado?", function () {
                        try {
                            debugger;

                            if (Xrm.Page.getAttribute("bso_superintendente").getValue() == null) {
                                throw new Error("O preenchimento do campo superintendente \u00e9 obrigat\u00f3rio.");
                            }

                            var bsoSuperintendenteId = Xrm.Page.getAttribute("bso_superintendente").getValue();
                            var ownerId = Xrm.Page.getAttribute("ownerid").getValue();
                            var bsoMatriculaGerente = Xrm.Page.getAttribute("bso_matricula_gerente").getValue();
                            var bsoCelula = Xrm.Page.getAttribute("bso_celula").getSelectedOption();

                            var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", apoliceId);

                            updateEntity.attributes["bso_gerente_relacionamento"] = { id: Apolice.Utility.ReplaceBracket(bsoGerenteRelacionamentoId[0].id), logicalName: 'systemuser', type: 'EntityReference' };
                            updateEntity.attributes["bso_superintendente"] = { id: Apolice.Utility.ReplaceBracket(bsoSuperintendenteId[0].id), logicalName: 'systemuser', type: 'EntityReference' };

                            if (ownerId[0].type === "8") {
                                updateEntity.attributes["bso_proprietario_usuario_temporario"] = { id: Apolice.Utility.ReplaceBracket(ownerId[0].id), logicalName: 'systemuser', type: 'EntityReference' };
                            } else {
                                updateEntity.attributes["bso_proprietario_equipe_temporaria"] = { id: Apolice.Utility.ReplaceBracket(ownerId[0].id), logicalName: 'team', type: 'EntityReference' };
                            }

                            updateEntity.attributes["bso_status_designacao"] = { value: statusDesignacao.AguardandoAprovacao, type: 'OptionSetValue' };
                            updateEntity.attributes["bso_matricula_gerente"] = bsoMatriculaGerente;
                            updateEntity.attributes["bso_celula"] = { value: bsoCelula.value, type: 'OptionSetValue' };
                            updateEntity.attributes["bso_data_envio_designacao"] = new Date();
                            updateEntity.attributes["bso_data_recusa_designacao"] = null;
                            updateEntity.attributes["bso_data_confirma_designacao"] = null;

                            if (Xrm.Page.getAttribute("bso_grupo_empresa") != null && Xrm.Page.getAttribute("bso_grupo_empresa").getValue() != null) {
                                var bsoGrupoEmpresaId = Xrm.Page.getAttribute("bso_grupo_empresa").getValue();
                                updateEntity.attributes["bso_grupo_empresa"] = { id: Apolice.Utility.ReplaceBracket(bsoGrupoEmpresaId[0].id), logicalName: 'bso_grupo_empresa', type: 'EntityReference' };
                            }

                            if (Xrm.Page.getAttribute("bso_sucursal_implantacao") != null && Xrm.Page.getAttribute("bso_sucursal_implantacao").getValue() != null) {
                                var bsoSucursalImplantacaoId = Xrm.Page.getAttribute("bso_sucursal_implantacao").getValue();
                                updateEntity.attributes["bso_sucursal_implantacao"] = { id: Apolice.Utility.ReplaceBracket(bsoSucursalImplantacaoId[0].id), logicalName: 'businessunit', type: 'EntityReference' };
                            }

                            if (Xrm.Page.getAttribute("bso_supex_implantacao") != null && Xrm.Page.getAttribute("bso_supex_implantacao").getValue() != null) {
                                var bsoSupexImplantacaoId = Xrm.Page.getAttribute("bso_supex_implantacao").getValue();
                                updateEntity.attributes["bso_supex_implantacao"] = bsoSupexImplantacaoId;
                            }

                            if (Xrm.Page.getAttribute("bso_gerente_comercial_implantacao") != null && Xrm.Page.getAttribute("bso_gerente_comercial_implantacao").getValue() != null) {
                                var bsoGerenteComercialImplantacaoId = Xrm.Page.getAttribute("bso_gerente_comercial_implantacao").getValue();
                                updateEntity.attributes["bso_gerente_comercial_implantacao"] = { id: Apolice.Utility.ReplaceBracket(bsoGerenteComercialImplantacaoId[0].id), logicalName: 'systemuser', type: 'EntityReference' };
                            }

                            if (Xrm.Page.getAttribute("bso_liminar") != null && Xrm.Page.getAttribute("bso_liminar").getValue() != null) {
                                var bsoLiminar = Xrm.Page.getAttribute("bso_liminar").getValue();
                                updateEntity.attributes["bso_liminar"] = bsoLiminar;
                            }

                            if (Xrm.Page.getAttribute("bso_excecao") != null && Xrm.Page.getAttribute("bso_excecao").getSelectedOption() != null) {
                                var bsoExcecao = Xrm.Page.getAttribute("bso_excecao").getSelectedOption();
                                updateEntity.attributes["bso_excecao"] = { value: bsoExcecao.value, type: 'OptionSetValue' };
                            }

                            if (Xrm.Page.getAttribute("bso_classificacao_gerente_relacionamento") != null && Xrm.Page.getAttribute("bso_classificacao_gerente_relacionamento").getSelectedOption() != null) {
                                var bsoClassificacaoGerenteRelacionamento = Xrm.Page.getAttribute("bso_classificacao_gerente_relacionamento").getSelectedOption();
                                updateEntity.attributes["bso_classificacao_gerente_relacionamento"] = { value: bsoClassificacaoGerenteRelacionamento.value, type: 'OptionSetValue' };
                            }

                            if (Xrm.Page.getAttribute("bso_poder_decisorio") != null && Xrm.Page.getAttribute("bso_poder_decisorio").getValue() != null) {
                                var bsoPoderDecisorio = Xrm.Page.getAttribute("bso_poder_decisorio").getValue();
                                updateEntity.attributes["bso_poder_decisorio"] = bsoPoderDecisorio;
                            }

                            var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                            if (updateResponse != null) {
                                var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", apoliceId, "systemuser", Apolice.Utility.ReplaceBracket(bsoSuperintendenteId[0].id));

                                Xrm.Utility.alertDialog("Ap\u00f3lice \"" + bsoNumeroApolice + "\" foi enviada para aprova\u00e7\u00e3o do superintendente \"" + bsoSuperintendenteId[0].name + "\" com sucesso.");

                                Xrm.Page.data.entity.save();
                                if (eventArgs.getSaveMode() == formSaveMode.SaveAndClose) {
                                    Xrm.Page.data.entity.save("saveandclose");
                                } else if (eventArgs.getSaveMode() == formSaveMode.SaveAndNew) {
                                    Xrm.Page.data.entity.save("saveandnew");
                                } else {
                                    Xrm.Page.data.refresh(false);
                                }
                            }
                        } catch (e) {
                            Xrm.Utility.alertDialog("Ocorreu erro no processo de designa\u00e7\u00e3o da(s) ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message, function () { return false; });
                            Xrm.Page.data.refresh(false);
                        }
                    }, function () {
                        debugger;
                        Xrm.Page.getAttribute("bso_matricula_gerente").setValue(null);
                        Xrm.Page.getAttribute("bso_gerente_relacionamento").setValue(null);
                        Xrm.Page.getAttribute("bso_superintendente").setValue(null);
                        Xrm.Page.getAttribute("bso_celula").setValue(null);

                        Xrm.Page.data.entity.save();
                        if (eventArgs.getSaveMode() == formSaveMode.SaveAndClose) {
                            Xrm.Page.data.entity.save("saveandclose");
                        } else if (eventArgs.getSaveMode() == formSaveMode.SaveAndNew) {
                            Xrm.Page.data.entity.save("saveandnew");
                        } else {
                            Xrm.Page.data.refresh(false);
                        }
                    });
                }
            }
        }
    };

    var isUserProfile = function (profiles, contains) {

        var result = false;

        try {
            if (!Array.isArray(profiles)) throw new Error("O objeto 'profiles' é inválido.");

            if (profiles != null && profiles.length > 0) {

                var currentUserRoles = Xrm.Page.context.getUserRoles();

                for (var i1 in currentUserRoles) {
                    var consulta = Helpers.Buscar("roles(" + currentUserRoles[i1] + ")?$select=name");
                    if (consulta != null) {
                        for (var i2 in profiles) {
                            if (consulta.name != null && consulta.name.toLowerCase() == profiles[i2].toLowerCase()) {
                                result = true;
                                break;
                            } else {
                                if ((contains != null && contains == true) && (consulta.name != null && consulta.name.toLowerCase().indexOf(profiles[i2].toLowerCase()) > -1)) {
                                    result = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

        } catch (ex) {
            if (window.console) console.error("Erro na checagem se usu\u00e1rio \u00e9 membro do perfil Feedback CORPORATE. Detalhe: " + ex.message);
        }
        return result;
    };

    return {
        OnLoad: function () {

            //return;

            if (Xrm.Page.ui.getFormType() == formType.Create) {
                Xrm.Utility.alertDialog("N\u00e3o \u00e9 permitido criar ap\u00f3lice pelo o CRM.", function () {
                    //Xrm.Page.ui.close();
                });
            }

            //Atualizar faixa de botões
            Xrm.Page.ui.refreshRibbon()

            var perfis = ["Gerente CER - Corporativo"];
            var bsoStatusDesignacaoOption = Xrm.Page.getAttribute("bso_status_designacao").getSelectedOption();

            //Status da designação: Aguardando designação ou Aprovação Recusada
            if (isUserProfile(perfis, true) || (bsoStatusDesignacaoOption != null && (bsoStatusDesignacaoOption.value == statusDesignacao.AguardandoDesignacao || bsoStatusDesignacaoOption.value == statusDesignacao.AprovacaoRecusada))) {

                var attributesException = [
                    { Name: "bso_grupo_empresa", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_matricula_gerente", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_gerente_relacionamento", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_superintendente", Disabled: true, SubmitMode: "dirty" },
                    { Name: "bso_celula", Disabled: true, SubmitMode: "dirty" },
                    { Name: "bso_sucursal_implantacao", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_liminar", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_excecao", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_supex_implantacao", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_gerente_comercial_implantacao", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_classificacao_gerente_relacionamento", Disabled: false, SubmitMode: "dirty" },
                    { Name: "bso_poder_decisorio", Disabled: false, SubmitMode: "dirty" },
                ];

                controlAllAttribute(attributesException);

            } else {
                controlAllAttribute();
            }

        },

        OnSave: function (econtext) {

            var eventArgs = econtext.getEventArgs();

            if (Xrm.Page.ui.getFormType() == formType.Create) {

                eventArgs.preventDefault();

                Xrm.Utility.alertDialog("N\u00e3o \u00e9 permitido criar ap\u00f3lice pelo o CRM.", function () {
                    Xrm.Page.ui.close();
                });
            }

            designarGerenteRelacionamento(eventArgs);
        },

        OnChangeNumeroApolice: function () {


            var bsoNumeroApolice = Xrm.Page.getAttribute("bso_numero_apolice");
            var bsoPessoaJuridica = Xrm.Page.getAttribute("bso_pessoa_juridica");

            if ((bsoNumeroApolice != null && bsoNumeroApolice.getValue() != null) && (bsoPessoaJuridica != null && bsoPessoaJuridica.getValue() != null)) {
                Xrm.Page.getAttribute("bso_name").setValue(bsoNumeroApolice.getValue() + " - " + bsoPessoaJuridica.getValue()[0].name);
            } else if (bsoNumeroApolice != null && bsoNumeroApolice.getValue() != null) {
                Xrm.Page.getAttribute("bso_name").setValue(bsoNumeroApolice.getValue());
            }
        },

        OnChangePessoaJuridica: function () {
            debugger;

            var bsoNumeroApolice = Xrm.Page.getAttribute("bso_numero_apolice");
            var bsoPessoaJuridica = Xrm.Page.getAttribute("bso_pessoa_juridica");

            if ((bsoNumeroApolice != null && bsoNumeroApolice.getValue() != null) && (bsoPessoaJuridica != null && bsoPessoaJuridica.getValue() != null)) {
                Xrm.Page.getAttribute("bso_name").setValue(bsoNumeroApolice.getValue() + " - " + bsoPessoaJuridica.getValue()[0].name);
            }
        },

        OnChangeMatriculaGerenteRelacionamento: function () {
            debugger;

            Xrm.Page.getAttribute("bso_celula").setValue(null);
            Xrm.Page.getAttribute("bso_gerente_relacionamento").setValue(null);
            Xrm.Page.getAttribute("bso_superintendente").setValue(null);

            var bsoMatriculaGerente = Xrm.Page.getAttribute("bso_matricula_gerente");
            if (bsoMatriculaGerente != null && bsoMatriculaGerente.getValue() != null) {

                var query = "systemusers?$select=systemuserid,fullname,bso_celula,_bso_gerentedeatendimentoid_value,bso_matricula,_bso_superintendenteid_value,_bso_supexid_value&$filter=bso_matricula eq '" + bsoMatriculaGerente.getValue() + "'&$count=true";
                var consulta = Helpers.Buscar(query);

                if (consulta != null && consulta.length > 0) {

                    //TODO: Alterar o campo Celula de texto para lookup
                    if (consulta[0].bso_celula != null) Xrm.Page.getAttribute("bso_celula").setValue(consulta[0].bso_celula);

                    if (consulta[0].systemuserid != null) {
                        var gerenteRelacionamento = Helpers.CreateLookup(
                            consulta[0].systemuserid,
                            consulta[0].fullname,
                            "systemuser"
                        );
                        Xrm.Page.getAttribute("bso_gerente_relacionamento").setValue(gerenteRelacionamento);
                    }

                    if (consulta[0]._bso_superintendenteid_value != null) {
                        var superintendente = Helpers.CreateLookup(
                            consulta[0]._bso_superintendenteid_value,
                            consulta[0]["_bso_superintendenteid_value@OData.Community.Display.V1.FormattedValue"],
                            consulta[0]["_bso_superintendenteid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                        );
                        Xrm.Page.getAttribute("bso_superintendente").setValue(superintendente);
                    }

                } else {
                    Xrm.Utility.alertDialog("N\u00e3o foi encontrado o gerente de relacionamento da matr\u00edcula informada(" + bsoMatriculaGerente.getValue() + ")!", function () {
                        Xrm.Page.getControl("bso_matricula_gerente").setFocus();
                    });
                }
            }
        },

        OnChangeGerenteRelacionamento: function () {
            debugger;

            Xrm.Page.getAttribute("bso_celula").setValue(null);
            Xrm.Page.getAttribute("bso_matricula_gerente").setValue(null);
            Xrm.Page.getAttribute("bso_superintendente").setValue(null);

            var bsoGerenteRelacionamento = Xrm.Page.getAttribute("bso_gerente_relacionamento");
            if (bsoGerenteRelacionamento != null && bsoGerenteRelacionamento.getValue() != null) {

                var bsoGerenteRelacionamentoId = Apolice.Utility.ReplaceBracket(bsoGerenteRelacionamento.getValue()[0].id);

                if (bsoGerenteRelacionamentoId != null) {

                    var query = "systemusers(" + bsoGerenteRelacionamentoId + ")?$select=systemuserid,fullname,bso_celula,_bso_gerentedeatendimentoid_value,bso_matricula,_bso_superintendenteid_value,_bso_supexid_value";
                    var consulta = Helpers.Buscar(query);

                    if (consulta != null) {

                        //TODO: Alterar o campo Celula de texto para lookup
                        if (consulta.bso_celula != null) Xrm.Page.getAttribute("bso_celula").setValue(consulta.bso_celula);

                        if (consulta.bso_matricula != null) Xrm.Page.getAttribute("bso_matricula_gerente").setValue(consulta.bso_matricula);

                        if (consulta._bso_superintendenteid_value != null) {
                            var superintendente = Helpers.CreateLookup(
                                consulta._bso_superintendenteid_value,
                                consulta["_bso_superintendenteid_value@OData.Community.Display.V1.FormattedValue"],
                                consulta["_bso_superintendenteid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                            );
                            Xrm.Page.getAttribute("bso_superintendente").setValue(superintendente);
                        }

                    }
                }
            }
        },
    };
}();

Apolice.Ribbon = (function () {

    var message = {
        Error: function (content) {
            return [
                "<table border='0' cellpadding='0' cellspacing='4'>",
                "    <tr>",
                "        <td valign='middle'>",
                "            <img tabindex='0' alt='ERRO' title='ERRO' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAA3NCSVQICAjb4U/gAAAAP1BMVEX////YAwPYAwPYAwPYAwPYAwPYAwPYAwPYAwPYAwPYAwP////97+/64OD40ND1wMDzsLDwoaHfMjLaExPYAwNUa838AAAAFXRSTlMAETNEVWaqu8zd7v////////////8fXFKAAAAACXBIWXMAAA50AAAOdAFrJLPWAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M0BrLToAAAAHxJREFUGJVVT9sWwyAIw3VFqx1rhf//1gV0XZcHIDnhRgSsxQBeaeAR1JFT8GoXNleK3ZDRj9TfivDqKJcwHE207+3wyeRGlSY7RJQ1BFcGNxsC/H8CuMi3hedQdJ0x1NfqqTNgLeX7YYxL0/bjJZ5Jl4fT/PfJeLDy4vUHm0IONagzvdgAAAAASUVORK5CYII='>",
                "        </td>",
                "        <td>&ensp;</td>",
                "        <td>" + content + "</td>",
                "    </tr>",
                "</table>"
            ].join("");
        },
        Sucess: function (content) {
            return [
                    "<table border='0' cellpadding='0' cellspacing='4'>",
                    "    <tr>",
                    "        <td valign='middle'>",
                    "            <img tabindex='0' width='12' alt='SUCESSO' title='SUCESSO' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAAA3NCSVQICAjb4U/gAAAAGFBMVEX///+m2pCa1IJ+1F9pvEtjs0aJmIRVpjhBifVGAAAACHRSTlMA/////////9XKVDIAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAYdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3Jrc0+zH04AAAA6SURBVAiZY2DAARKgNJsZlJEcDhFiMy2DSIMF2NSgAilGCRAVbM5iYAEGhlRDmJbQMqgh6XBjcVgLAP10CsSrybWaAAAAAElFTkSuQmCC'>",
                    "        </td>",
                    "        <td>&ensp;</td>",
                    "        <td>" + content + "</td>",
                    "    </tr>",
                    "</table>"
            ].join("");
        }
    };

    var statusDesignacao = {
        AguardandoDesignacao: 1,
        AguardandoAprovacao: 2,
        AprovacaoConfirmada: 3,
        AprovacaoRecusada: 4,
        DesignacaoCancelada: 5
    };

    var statusNegociacao = {
        Negociacao: 1,
        Renovacao: 2,
        Cancelamento: 3,
        AguardandoConfirmacaoRenovacao: 4,
        AguardandoConfirmacaoCancelamento: 5
    };

    var designarGerenteRelacionamento = function (selectedControl, selectedControlSelectedItemIds) {


        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.showWebResource("bso_apolice_designar_gerente_relacionamento.html", 600, 500, "Designa\u00e7\u00e3o de Gerente de Relacionamento", [
                 new Alert.Button("CONFIRMAR", function () {
                     try {
                         debugger;

                         var iFrameWindow = Alert.getIFrameWindow();

                         if ((iFrameWindow == null) || (iFrameWindow != null && iFrameWindow.SelectedEntityReferenceIds == null) || (iFrameWindow != null && iFrameWindow.SelectedEntityReferenceIds != null && iFrameWindow.SelectedEntityReferenceIds.length == 0)) {
                             Xrm.Utility.alertDialog("O usu\u00e1rio gerente de relacionamento \u00e9 obrigat\u00f3rio.", function () { });
                             return false;
                         }

                         var selectedEntityReferenceIds = iFrameWindow.SelectedEntityReferenceIds;

                         Alert.showLoading();

                         var result = new Array();

                         for (var i in window.SelectedControlSelectedItemIds) {

                             try {

                                 var colsSystemuser = ["fullname", "bso_matricula", "parentsystemuserid", "bso_superintendenteid"];
                                 var retrievedSystemuser = XrmServiceToolkit.Soap.Retrieve("systemuser", selectedEntityReferenceIds[0].id, colsSystemuser);

                                 if (retrievedSystemuser != null) {

                                     var bsoSuperintendenteId = retrievedSystemuser.attributes["bso_superintendenteid"];

                                     if ((bsoSuperintendenteId == null) || (bsoSuperintendenteId != null && (bsoSuperintendenteId.id == null || bsoSuperintendenteId.id === "00000000-0000-0000-0000-000000000000"))) {
                                         throw new Error("O superintendente do usu\u00e1rio \u00e9 obrigat\u00f3rio.");
                                     }

                                     var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_designacao"];
                                     var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                     var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                     if (bsoNumeroApolice == null) {
                                         throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                     }

                                     var bsoStatusDesignacao = retrievedApolice.attributes["bso_status_designacao"];

                                     if ((bsoStatusDesignacao == null) || (bsoStatusDesignacao != null && !(bsoStatusDesignacao.value == statusDesignacao.AguardandoDesignacao || bsoStatusDesignacao.value == statusDesignacao.AprovacaoRecusada))) {
                                         throw new Error("Para fazer a designa\u00e7\u00e3o da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 \"Aguardando Designa\u00e7\u00e3o\" ou \"Aprova\u00e7\u00e3o Recusada\".");
                                     }

                                     var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                     if (retrievedApolice.attributes["ownerid"].name === "systemuser") {
                                         updateEntity.attributes["bso_proprietario_usuario_temporario"] = { id: retrievedApolice.attributes["ownerid"].id, logicalName: 'systemuser', type: 'EntityReference' };
                                     } else {
                                         updateEntity.attributes["bso_proprietario_equipe_temporaria"] = { id: retrievedApolice.attributes["ownerid"].id, logicalName: 'team', type: 'EntityReference' };
                                     }

                                     updateEntity.attributes["bso_gerente_relacionamento"] = { id: retrievedSystemuser.id, logicalName: 'systemuser', type: 'EntityReference' };
                                     updateEntity.attributes["bso_superintendente"] = { id: bsoSuperintendenteId.id, logicalName: 'systemuser', type: 'EntityReference' };
                                     updateEntity.attributes["bso_status_designacao"] = { value: statusDesignacao.AguardandoAprovacao, type: 'OptionSetValue' };
                                     updateEntity.attributes["bso_data_envio_designacao"] = new Date();
                                     updateEntity.attributes["bso_data_recusa_designacao"] = null;
                                     updateEntity.attributes["bso_data_confirma_designacao"] = null;
                                     if (retrievedSystemuser.attributes["bso_superintendenteid"] != null) {
                                         updateEntity.attributes["bso_matricula_gerente"] = retrievedSystemuser.attributes["bso_matricula"].value;
                                     }

                                     var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                     if (updateResponse != null) {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", bsoSuperintendenteId.id);
                                     }

                                     result.push(message.Sucess("Ap\u00f3lice \"" + bsoNumeroApolice.value + "\" foi atribu\u00edda para \"" + bsoSuperintendenteId.formattedValue + "\" com sucesso."));
                                 }

                             } catch (e) {
                                 result.push(message.Error("Ocorreu erro no processo de designa\u00e7\u00e3o da(s) ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message));
                             }
                         }

                         Alert.show("Designa\u00e7\u00e3o de ap\u00f3lice(s)!", result.join(""),
                            [
                                new Alert.Button("OK",
                                    function () {

                                        debugger;

                                        if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                            window.SelectedControl.refresh();
                                        else
                                            if (Xrm != null && Xrm.Page != null && Xrm.Page.data != null && Xrm.Page.data.refresh != null)
                                                Xrm.Page.data.refresh(true);

                                        Alert.hide();
                                    }, true, true)
                            ], "INFO", 600, 200
                        );
                     } catch (e) {
                         Alert.show("Designa\u00e7\u00e3o de Gerente de Relacionamento", "Ocorreu erro no processo de designa\u00e7\u00e3o de ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message, null, "ERROR", 600, 200);
                     }
                 }, true, true),
        new Alert.Button("CANCELAR")
            ], null, true, 20);
        }
    };

    var confirmarDesignacaoGerenteRelacionamento = function (selectedControl, selectedControlSelectedItemIds) {

        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.show("Confirma\u00e7\u00e3o de Gerente de Relacionamento", "Deseja fazer a confirma\u00e7\u00e3o de gerente de relacionamento para a(s) ap\u00f3lice(s) selecionada(s)?",
                [
                    new Alert.Button("CONFIRMAR",
                        function () {
                            try {

                                Alert.showLoading();

                                var result = new Array();

                                for (var i in window.SelectedControlSelectedItemIds) {

                                    try {

                                        var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_designacao"];
                                        var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                        var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                        if (bsoNumeroApolice == null) {
                                            throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                        }

                                        var bsoStatusDesignacao = retrievedApolice.attributes["bso_status_designacao"];

                                        if ((bsoStatusDesignacao == null) || (bsoStatusDesignacao != null && bsoStatusDesignacao.value != statusDesignacao.AguardandoAprovacao)) {
                                            throw new Error("Para fazer a confirma\u00e7\u00e3o da designa\u00e7\u00e3o da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 \"Aguardando Aprova\u00e7\u00e3o.\"");
                                        }

                                        var proprietarioTemporarioId = retrievedApolice.attributes["bso_gerente_relacionamento"];

                                        if ((proprietarioTemporarioId == null) || (proprietarioTemporarioId != null && (proprietarioTemporarioId.id == null || proprietarioTemporarioId.id === "00000000-0000-0000-0000-000000000000"))) {
                                            throw new Error("O propriet\u00e1rio tempor\u00e1rio \u00e9 obrigat\u00f3rio.");
                                        }

                                        var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                        updateEntity.attributes["bso_proprietario_usuario_temporario"] = null;
                                        updateEntity.attributes["bso_proprietario_equipe_temporaria"] = null;
                                        updateEntity.attributes["bso_status_designacao"] = { value: statusDesignacao.AprovacaoConfirmada, type: 'OptionSetValue' };
                                        updateEntity.attributes["bso_data_confirma_designacao"] = new Date();
                                        updateEntity.attributes["bso_data_recusa_designacao"] = null;

                                        var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                        if (updateResponse != null) {
                                            if (proprietarioTemporarioId.name === "systemuser") {
                                                var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", proprietarioTemporarioId.id);
                                            } else {
                                                var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "team", proprietarioTemporarioId.id);
                                            }
                                        }

                                        result.push(message.Sucess("Gerente de Relacionamento \"" + proprietarioTemporarioId.formattedValue + "\" confirmado com sucesso!"));

                                    } catch (e) {
                                        result.push(message.Error("Ocorreu erro no processo de confirma\u00e7\u00e3o de gerente de relacionamentoda para ap\u00f3lice. Detalhe: " + e.message));
                                    }
                                }

                                Alert.show("Confirma\u00e7\u00e3o de Gerente de Relacionamentoda!", result.join(""),
                                   [
                                       new Alert.Button("OK",
                                           function () {
                                               if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                                   window.SelectedControl.refresh()
                                               Alert.hide();
                                           }, true, true)
                                   ], "INFO", 600, 200
                               );
                            } catch (e) {
                                Alert.show("Confirma\u00e7\u00e3o de Gerente de Relacionamentoda!", "Ocorreu erro no processo de designa\u00e7\u00e3o da(s) ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message, null, "ERROR", 600, 200);
                            }
                        }, true, true),
                    new Alert.Button("CANCELAR")
                ], "QUESTION", 600, 200
            );
        }
    };

    var recusarDesignacaoGerenteRelacionamento = function (selectedControl, selectedControlSelectedItemIds) {
        debugger;

        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.showWebResource("bso_apolice_recusar_designacao_gerente_relacionamento.html", 600, 500, "Recusa de Gerente de Relacionamentoda!", [
                 new Alert.Button("CONFIRMAR", function () {
                     try {
                         debugger;

                         var iFrameWindow = Alert.getIFrameWindow();

                         var txaMotivoRecusa = iFrameWindow.document.getElementById("txaMotivoRecusa");

                         if ((txaMotivoRecusa == null) || (txaMotivoRecusa != null && (txaMotivoRecusa.value == null || txaMotivoRecusa.value === ""))) {
                             Xrm.Utility.alertDialog("A descri\u00e7\u00e3o do motivo da recusa \u00e9 obrigat\u00f3rio.", function () {
                                 iFrameWindow.document.getElementById("txaMotivoRecusa").focus();
                             });
                             return false;
                         }

                         Alert.showLoading();

                         var result = new Array();

                         for (var i in window.SelectedControlSelectedItemIds) {

                             try {

                                 var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_designacao"];
                                 var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                 var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                 if (bsoNumeroApolice == null) {
                                     throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                 }

                                 var bsoStatusDesignacao = retrievedApolice.attributes["bso_status_designacao"];

                                 if ((bsoStatusDesignacao == null) || (bsoStatusDesignacao != null && bsoStatusDesignacao.value != statusDesignacao.AguardandoAprovacao)) {
                                     throw new Error("Para fazer a  rejei\u00e7\u00e3o da designa\u00e7\u00e3o da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 \"Aguardando Aprova\u00e7\u00e3o.\"");
                                 }

                                 var proprietarioTemporarioId = retrievedApolice.attributes["bso_proprietario_usuario_temporario"];
                                 if (proprietarioTemporarioId == null) {
                                     proprietarioTemporarioId = retrievedApolice.attributes["bso_proprietario_equipe_temporaria"];
                                 }

                                 if ((proprietarioTemporarioId == null) || (proprietarioTemporarioId != null && (proprietarioTemporarioId.id == null || proprietarioTemporarioId.id === "00000000-0000-0000-0000-000000000000"))) {
                                     throw new Error("O propriet\u00e1rio tempor\u00e1rio \u00e9 obrigat\u00f3rio.");
                                 }

                                 var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                 updateEntity.attributes["bso_proprietario_usuario_temporario"] = null;
                                 updateEntity.attributes["bso_proprietario_equipe_temporaria"] = null;
                                 updateEntity.attributes["bso_gerente_relacionamento"] = null;
                                 updateEntity.attributes["bso_superintendente"] = null;
                                 updateEntity.attributes["bso_status_designacao"] = { value: statusDesignacao.AprovacaoRecusada, type: 'OptionSetValue' };
                                 updateEntity.attributes["bso_data_recusa_designacao"] = new Date();
                                 updateEntity.attributes["bso_data_confirma_designacao"] = null;
                                 updateEntity.attributes["bso_motivo_recusa"] = txaMotivoRecusa.value;

                                 var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                 if (updateResponse != null) {
                                     if (proprietarioTemporarioId.name === "systemuser") {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", proprietarioTemporarioId.id);
                                     } else {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "team", proprietarioTemporarioId.id);
                                     }
                                 }

                                 result.push(message.Sucess("Gerente de Relacionamento \"" + proprietarioTemporarioId.formattedValue + "\" recusado com sucesso!"));

                             } catch (e) {
                                 result.push(message.Error("Ocorreu erro no processo de rejei\u00e7\u00e3o de gerente de relacionamentoda para ap\u00f3lice. Detalhe: " + e.message));
                             }
                         }

                         Alert.show("Rejei\u00e7\u00e3o de gerente de relacionamentoda para ap\u00f3lice(s)!", result.join(""),
                            [
                                new Alert.Button("OK",
                                    function () {
                                        if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                            window.SelectedControl.refresh()
                                        Alert.hide();
                                    }, true, true)
                            ], "INFO", 600, 200
                        );
                     } catch (e) {
                         Alert.show("Rejei\u00e7\u00e3o de gerente de relacionamentoda para ap\u00f3lice(s)", "Ocorreu erro no processo de rejei\u00e7\u00e3o da(s) ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message, null, "ERROR", 600, 200);
                     }
                 }, true, true),
                 new Alert.Button("CANCELAR")
            ], null, true, 20);
        }
    };

    var renovarApolice = function (selectedControl, selectedControlSelectedItemIds) {


        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.show("Renova\u00e7\u00e3o de Ap\u00f3lice", "Deseja renovar a(s) ap\u00f3lice(s) selecionada(s)?",
                [
                    new Alert.Button("RENOVAR",
                        function () {
                            try {


                                Alert.showLoading();

                                var result = new Array();

                                for (var i in window.SelectedControlSelectedItemIds) {

                                    try {

                                        var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_negociacao"];
                                        var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                        var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                        if (bsoNumeroApolice == null) {
                                            throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                        }

                                        var bsoStatusNegociacao = retrievedApolice.attributes["bso_status_negociacao"];

                                        if ((bsoStatusNegociacao == null) || (bsoStatusNegociacao != null && bsoStatusNegociacao.value != statusNegociacao.Negociacao)) {
                                            throw new Error("Para fazer a negocia\u00e7\u00e3o da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 em \"Negocia\u00e7\u00e3o\".");
                                        }

                                        var superintendenteId = retrievedApolice.attributes["bso_superintendente"];

                                        if ((superintendenteId == null) || (superintendenteId != null && (superintendenteId.id == null || superintendenteId.id === "00000000-0000-0000-0000-000000000000"))) {
                                            throw new Error("O superintendente \u00e9 obrigat\u00f3rio.");
                                        }

                                        var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                        if (retrievedApolice.attributes["ownerid"].name === "systemuser") {
                                            updateEntity.attributes["bso_proprietario_usuario_temporario"] = { id: retrievedApolice.attributes["ownerid"].id, logicalName: 'systemuser', type: 'EntityReference' };
                                        } else {
                                            updateEntity.attributes["bso_proprietario_equipe_temporaria"] = { id: retrievedApolice.attributes["ownerid"].id, logicalName: 'team', type: 'EntityReference' };
                                        }
                                        updateEntity.attributes["bso_status_negociacao"] = { value: statusNegociacao.AguardandoConfirmacaoRenovacao, type: 'OptionSetValue' };
                                        updateEntity.attributes["bso_data_negociacao"] = new Date();

                                        var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                        if (updateResponse != null) {
                                            var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", superintendenteId.id);
                                        }

                                        result.push(message.Sucess("Solicita\u00e7\u00e3o de renova\u00e7\u00e3o de ap\u00f3lice enviada com sucesso!"));

                                    } catch (e) {
                                        result.push(message.Error("Ocorreu erro no processo de renova\u00e7\u00e3o de ap\u00f3lice. Detalhe: " + e.message));
                                    }
                                }

                                Alert.show("Renova\u00e7\u00e3o de ap\u00f3lice(s)!", result.join(""),
                                   [
                                       new Alert.Button("OK",
                                           function () {
                                               if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                                   window.SelectedControl.refresh()
                                               Alert.hide();
                                           }, true, true)
                                   ], "INFO", 600, 200
                               );
                            } catch (e) {
                                Alert.show("Confirma\u00e7\u00e3o de gerente de relacionamentoda para ap\u00f3lice(s)", "Ocorreu erro no processo de designa\u00e7\u00e3o da(s) ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message, null, "ERROR", 600, 200);
                            }
                        }, true, true),
                    new Alert.Button("CANCELAR")
                ], "QUESTION", 600, 200
            );
        }
    };

    var cancelarApolice = function (selectedControl, selectedControlSelectedItemIds) {


        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.show("Cancelamento de Ap\u00f3lice", "Deseja cancelar a(s) ap\u00f3lice(s) selecionada(s)?",
                [
                    new Alert.Button("CANCELAR AP\u00d3LICE",
                        function () {
                            try {


                                Alert.showLoading();

                                var result = new Array();

                                for (var i in window.SelectedControlSelectedItemIds) {

                                    try {

                                        var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_negociacao"];
                                        var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                        var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                        if (bsoNumeroApolice == null) {
                                            throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                        }

                                        var bsoStatusNegociacao = retrievedApolice.attributes["bso_status_negociacao"];

                                        if ((bsoStatusNegociacao == null) || (bsoStatusNegociacao != null && bsoStatusNegociacao.value != statusNegociacao.Negociacao)) {
                                            throw new Error("Para fazer a negocia\u00e7\u00e3o da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 em \"Negocia\u00e7\u00e3o\".");
                                        }

                                        var superintendenteId = retrievedApolice.attributes["bso_superintendente"];

                                        if ((superintendenteId == null) || (superintendenteId != null && (superintendenteId.id == null || superintendenteId.id === "00000000-0000-0000-0000-000000000000"))) {
                                            throw new Error("O superintendente \u00e9 obrigat\u00f3rio.");
                                        }

                                        var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                        if (retrievedApolice.attributes["ownerid"].name === "systemuser") {
                                            updateEntity.attributes["bso_proprietario_usuario_temporario"] = { id: retrievedApolice.attributes["ownerid"].id, logicalName: 'systemuser', type: 'EntityReference' };
                                        } else {
                                            updateEntity.attributes["bso_proprietario_equipe_temporaria"] = { id: retrievedApolice.attributes["ownerid"].id, logicalName: 'team', type: 'EntityReference' };
                                        }
                                        updateEntity.attributes["bso_status_negociacao"] = { value: statusNegociacao.AguardandoConfirmacaoCancelamento, type: 'OptionSetValue' };

                                        var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                        if (updateResponse != null) {
                                            var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", superintendenteId.id);
                                        }

                                        result.push(message.Sucess("Solicita\u00e7\u00e3o de cancelamento de ap\u00f3lice enviada com sucesso!"));

                                    } catch (e) {
                                        result.push(message.Error("Ocorreu erro no processo de cancelamento de ap\u00f3lice. Detalhe: " + e.message));
                                    }
                                }

                                Alert.show("Cancelamento de ap\u00f3lice(s)!", result.join(""),
                                   [
                                       new Alert.Button("OK",
                                           function () {
                                               if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                                   window.SelectedControl.refresh()
                                               Alert.hide();
                                           }, true, true)
                                   ], "INFO", 600, 200
                               );
                            } catch (e) {
                                Alert.show("Confirma\u00e7\u00e3o de gerente de relacionamentoda para ap\u00f3lice(s)", "Ocorreu erro no processo de designa\u00e7\u00e3o da(s) ap\u00f3lice(s) para o gerente de relacionamento selecionado. Detalhe: " + e.message, null, "ERROR", 600, 200);
                            }
                        }, true, true),
                    new Alert.Button("CANCELAR")
                ], "QUESTION", 600, 200
            );
        }
    };

    var confirmarRenovacaoApolice = function (selectedControl, selectedControlSelectedItemIds) {


        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.showWebResource("bso_apolice_confirmar_renovacao.html", 600, 500, "Confirma\u00e7\u00e3o de Renova\u00e7\u00e3o de Ap\u00f3lice", [
                 new Alert.Button("CONFIRMAR", function () {
                     try {


                         var motivoRenovacao = "";

                         var iFrameWindow = Alert.getIFrameWindow();

                         var chkPorcentagemApurado = iFrameWindow.document.getElementById("chkPorcentagemApurado");
                         var txtPorcentagemApurado = iFrameWindow.document.getElementById("txtPorcentagemApurado");

                         var chkPorcentagemAplicado = iFrameWindow.document.getElementById("chkPorcentagemAplicado");
                         var txtPorcentagemAplicado = iFrameWindow.document.getElementById("txtPorcentagemAplicado");

                         var chkValorAporte = iFrameWindow.document.getElementById("chkValorAporte");
                         var txtValorAporte = iFrameWindow.document.getElementById("txtValorAporte");

                         var txaMotivoRenovacao = iFrameWindow.document.getElementById("txaMotivoRenovacao");

                         if (chkPorcentagemApurado != null && chkPorcentagemApurado.checked == true) {
                             if ((txtPorcentagemApurado == null) || (txtPorcentagemApurado != null && (txtPorcentagemApurado.value == null || txtPorcentagemApurado.value === ""))) {
                                 Xrm.Utility.alertDialog("Ao selecionar a op\u00e7\u00e3o \"% Apurado\", o valor da porcentagem apurado \u00e9 obrigat\u00f3rio.", function () {
                                     iFrameWindow.document.getElementById("txtPorcentagemApurado").focus();
                                 });
                                 return false;
                             } else {
                                 motivoRenovacao += " % Apurado: " + txtPorcentagemApurado.value;
                             }
                         }

                         if (chkPorcentagemAplicado != null && chkPorcentagemAplicado.checked == true) {
                             if ((txtPorcentagemAplicado == null) || (txtPorcentagemAplicado != null && (txtPorcentagemAplicado.value == null || txtPorcentagemAplicado.value === ""))) {
                                 Xrm.Utility.alertDialog("Ao selecionar a op\u00e7\u00e3o \"% Aplicado\", o valor da porcentagem aplicado  \u00e9 obrigat\u00f3rio.", function () {
                                     iFrameWindow.document.getElementById("txtPorcentagemAplicado").focus();
                                 });
                                 return false;
                             } else {
                                 motivoRenovacao += " % Aplicado: " + txtPorcentagemAplicado.value;
                             }
                         }

                         if (chkValorAporte != null && chkValorAporte.checked == true) {
                             if ((txtValorAporte == null) || (txtValorAporte != null && (txtValorAporte.value == null || txtValorAporte.value === ""))) {
                                 Xrm.Utility.alertDialog("Ao selecionar a op\u00e7\u00e3o \"Aporte\", o valor aportado \u00e9 obrigat\u00f3rio.", function () {
                                     iFrameWindow.document.getElementById("txtValorAporte").focus();
                                 });
                                 return false;
                             } else {
                                 motivoRenovacao += " Aporte: " + txtValorAporte.value;
                             }
                         }

                         if ((txaMotivoRenovacao == null) || (txaMotivoRenovacao != null && (txaMotivoRenovacao.value == null || txaMotivoRenovacao.value === ""))) {
                             Xrm.Utility.alertDialog("A descri\u00e7\u00e3o do motivo da renova\u00e7\u00e3o \u00e9 obrigat\u00f3rio.", function () {
                                 iFrameWindow.document.getElementById("txaMotivoRenovacao").focus();
                             });
                             return false;
                         } else {
                             motivoRenovacao += " Observa\u00e7\u00e3o: " + txaMotivoRenovacao.value;
                         }

                         Alert.showLoading();

                         var result = new Array();

                         for (var i in window.SelectedControlSelectedItemIds) {

                             try {

                                 var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_negociacao"];
                                 var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                 var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                 if (bsoNumeroApolice == null) {
                                     throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                 }

                                 var bsoStatusNegociacao = retrievedApolice.attributes["bso_status_negociacao"];

                                 if ((bsoStatusNegociacao == null) || (bsoStatusNegociacao != null && bsoStatusNegociacao.value != statusNegociacao.AguardandoConfirmacaoRenovacao)) {
                                     throw new Error("Para fazer a confirma\u00e7\u00e3o da renova\u00e7\u00e3o da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 em \"Aguardando Confirma\u00e7\u00e3o de Renova\u00e7\u00e3o\".");
                                 }

                                 var proprietarioTemporarioId = retrievedApolice.attributes["bso_proprietario_usuario_temporario"];
                                 if (proprietarioTemporarioId == null) {
                                     proprietarioTemporarioId = retrievedApolice.attributes["bso_proprietario_equipe_temporaria"];
                                 }

                                 if ((proprietarioTemporarioId == null) || (proprietarioTemporarioId != null && (proprietarioTemporarioId.id == null || proprietarioTemporarioId.id === "00000000-0000-0000-0000-000000000000"))) {
                                     throw new Error("O propriet\u00e1rio tempor\u00e1rio \u00e9 obrigat\u00f3rio.");
                                 }

                                 var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                 updateEntity.attributes["bso_proprietario_usuario_temporario"] = null;
                                 updateEntity.attributes["bso_proprietario_equipe_temporaria"] = null;
                                 updateEntity.attributes["bso_status_negociacao"] = { value: statusNegociacao.Renovacao, type: 'OptionSetValue' };
                                 updateEntity.attributes["bso_data_negociacao"] = new Date();
                                 updateEntity.attributes["bso_motivo_renovacao"] = motivoRenovacao;

                                 var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                 if (updateResponse != null) {
                                     if (proprietarioTemporarioId.name === "systemuser") {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", proprietarioTemporarioId.id);
                                     } else {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "team", proprietarioTemporarioId.id);
                                     }
                                 }

                                 result.push(message.Sucess("Renova\u00e7\u00e3o realizada com sucesso!"));

                             } catch (e) {
                                 result.push(message.Error("Ocorreu erro no processo de renova\u00e7\u00e3o da ap\u00f3lice. Detalhe: " + e.message));
                             }
                         }

                         Alert.show("Negocia\u00e7\u00e3o de ap\u00f3lice(s)!", result.join(""),
                            [
                                new Alert.Button("OK",
                                    function () {
                                        if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                            window.SelectedControl.refresh()
                                        Alert.hide();
                                    }, true, true)
                            ], "INFO", 600, 200
                        );
                     } catch (e) {
                         Alert.show("Negocia\u00e7\u00e3o de ap\u00f3lice(s)!", "Ocorreu erro no processo de renova\u00e7\u00e3o da ap\u00f3lice. Detalhe: " + e.message, null, "ERROR", 600, 200);
                     }
                 }, true, true),
                 new Alert.Button("CANCELAR")
            ], null, true, 20);
        }
    };

    var confirmarCancelamentoApolice = function (selectedControl, selectedControlSelectedItemIds) {


        window.SelectedControl = new Object();
        window.SelectedControlSelectedItemIds = new Array();

        if (selectedControl != null) window.SelectedControl = selectedControl;

        if (selectedControlSelectedItemIds != null && selectedControlSelectedItemIds.length > 0) {

            window.SelectedControlSelectedItemIds = selectedControlSelectedItemIds;

            Alert.showWebResource("bso_apolice_confirmar_cancelamento.html", 600, 500, "Confirma\u00e7\u00e3o de Cancelamento de Ap\u00f3lice", [
                 new Alert.Button("CONFIRMAR", function () {
                     try {


                         var motivoCancelamento = "", isCusto = false, isRedeReferenciada = false, isDissolucaoEmpresa = false, isVendaCompraOutroGrupo = false, isOutros = false;

                         var iFrameWindow = Alert.getIFrameWindow();

                         var chkCusto = iFrameWindow.document.getElementById("chkCusto");
                         var chkRedeReferenciada = iFrameWindow.document.getElementById("chkRedeReferenciada");
                         var chkDissolucaoEmpresa = iFrameWindow.document.getElementById("chkDissolucaoEmpresa");
                         var chkVendaCompraOutroGrupo = iFrameWindow.document.getElementById("chkVendaCompraOutroGrupo");
                         var chkOutros = iFrameWindow.document.getElementById("chkOutros");
                         var txaOutros = iFrameWindow.document.getElementById("txaOutros");

                         if (chkCusto != null && chkCusto.checked == true) {
                             isCusto = true;
                             motivoCancelamento += " Custo;";
                         }

                         if (chkRedeReferenciada != null && chkRedeReferenciada.checked == true) {
                             isRedeReferenciada = true;
                             motivoCancelamento += " Rede Referenciada;";
                         }

                         if (chkDissolucaoEmpresa != null && chkDissolucaoEmpresa.checked == true) {
                             isDissolucaoEmpresa = true;
                             motivoCancelamento += " Dissolu\u00e7\u00e3o da empresa;";
                         }

                         if (chkVendaCompraOutroGrupo != null && chkVendaCompraOutroGrupo.checked == true) {
                             isVendaCompraOutroGrupo = true;
                             motivoCancelamento += " Venda/Compra outro grupo;";
                         }

                         if (chkOutros != null && chkOutros.checked == true) {
                             if ((txaOutros == null) || (txaOutros != null && (txaOutros.value == null || txaOutros.value === ""))) {
                                 Xrm.Utility.alertDialog("Ao selecionar a op\u00e7\u00e3o \"Outros\", a descri\u00e7\u00e3o do motivo de cancelamento \u00e9 obrigat\u00f3rio.", function () {
                                     iFrameWindow.document.getElementById("txaOutros").focus();
                                 });
                                 return false;
                             } else {
                                 isOutros = true;
                                 motivoCancelamento += " Outros:";
                                 motivoCancelamento += " " + txaOutros.value;
                             }
                         }

                         if ((isCusto == false && isRedeReferenciada == false && isDissolucaoEmpresa == false && isVendaCompraOutroGrupo == false && isOutros == false)) {
                             Xrm.Utility.alertDialog("Ao menos, uma op\u00e7\u00e3o de motivo de cancelamento \u00e9 campo obrigat\u00f3rio.", function () {
                                 iFrameWindow.document.getElementById("txaOutros").focus();
                             });
                             return false;
                         }

                         Alert.showLoading();

                         var result = new Array();

                         for (var i in window.SelectedControlSelectedItemIds) {

                             try {

                                 var colsApolice = ["bso_name", "bso_numero_apolice", "ownerid", "bso_proprietario_usuario_temporario", "bso_proprietario_equipe_temporaria", "bso_gerente_relacionamento", "bso_superintendente", "bso_status_negociacao"];
                                 var retrievedApolice = XrmServiceToolkit.Soap.Retrieve("bso_apolice", window.SelectedControlSelectedItemIds[i], colsApolice);

                                 var bsoNumeroApolice = retrievedApolice.attributes["bso_numero_apolice"];

                                 if (bsoNumeroApolice == null) {
                                     throw new Error("O n\u00famero da ap\u00f3lice \u00e9 obrigat\u00f3rio.");
                                 }

                                 var bsoStatusNegociacao = retrievedApolice.attributes["bso_status_negociacao"];

                                 if ((bsoStatusNegociacao == null) || (bsoStatusNegociacao != null && bsoStatusNegociacao.value != statusNegociacao.AguardandoConfirmacaoCancelamento)) {
                                     throw new Error("Para fazer a confirma\u00e7\u00e3o do cancelamento da ap\u00f3lice \"" + bsoNumeroApolice.value + "\" o status precisa est\u00e1 em \"Aguardando Confirma\u00e7\u00e3o de Cancelamento\".");
                                 }

                                 var proprietarioTemporarioId = retrievedApolice.attributes["bso_proprietario_usuario_temporario"];
                                 if (proprietarioTemporarioId == null) {
                                     proprietarioTemporarioId = retrievedApolice.attributes["bso_proprietario_equipe_temporaria"];
                                 }

                                 if ((proprietarioTemporarioId == null) || (proprietarioTemporarioId != null && (proprietarioTemporarioId.id == null || proprietarioTemporarioId.id === "00000000-0000-0000-0000-000000000000"))) {
                                     throw new Error("O propriet\u00e1rio tempor\u00e1rio \u00e9 obrigat\u00f3rio.");
                                 }

                                 var updateEntity = new XrmServiceToolkit.Soap.BusinessEntity("bso_apolice", retrievedApolice.id);

                                 updateEntity.attributes["bso_proprietario_usuario_temporario"] = null;
                                 updateEntity.attributes["bso_proprietario_equipe_temporaria"] = null;
                                 updateEntity.attributes["bso_status_negociacao"] = { value: statusNegociacao.Cancelamento, type: 'OptionSetValue' };
                                 updateEntity.attributes["bso_data_negociacao"] = new Date();
                                 updateEntity.attributes["bso_motivo_renovacao"] = motivoCancelamento;

                                 var updateResponse = XrmServiceToolkit.Soap.Update(updateEntity);

                                 if (updateResponse != null) {
                                     if (proprietarioTemporarioId.name === "systemuser") {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "systemuser", proprietarioTemporarioId.id);
                                     } else {
                                         var assignResponse = XrmServiceToolkit.Soap.Assign("bso_apolice", retrievedApolice.id, "team", proprietarioTemporarioId.id);
                                     }
                                 }

                                 result.push(message.Sucess("Cancelamento realizada com sucesso!"));

                             } catch (e) {
                                 result.push(message.Error("Ocorreu erro no processo de cancelamento da ap\u00f3lice. Detalhe: " + e.message));
                             }
                         }

                         Alert.show("Negocia\u00e7\u00e3o de ap\u00f3lice(s)!", result.join(""),
                            [
                                new Alert.Button("OK",
                                    function () {
                                        if (window.SelectedControl != null && window.SelectedControl.refresh != null)
                                            window.SelectedControl.refresh()
                                        Alert.hide();
                                    }, true, true)
                            ], "INFO", 600, 200
                        );
                     } catch (e) {
                         Alert.show("Negocia\u00e7\u00e3o de ap\u00f3lice(s)!", "Ocorreu erro no processo de cancelamento da ap\u00f3lice. Detalhe: " + e.message, null, "ERROR", 600, 200);
                     }
                 }, true, true),
                 new Alert.Button("CANCELAR")
            ], null, true, 20);
        }
    };

    return {
        HomepageGrid: {
            OnDesignarGerenteRelacionamento: designarGerenteRelacionamento,
            OnConfirmarDesignacaoGerenteRelacionamento: confirmarDesignacaoGerenteRelacionamento,
            OnRecusarDesignacaoGerenteRelacionamento: recusarDesignacaoGerenteRelacionamento,
            OnRenovarApolice: renovarApolice,
            OnCancelarApolice: cancelarApolice,
            OnConfirmarRenovacaoApolice: confirmarRenovacaoApolice,
            OnConfirmarCancelamentoApolice: confirmarCancelamentoApolice
        },

        SubGrid: {
            OnDesignarGerenteRelacionamento: designarGerenteRelacionamento,
            OnConfirmarDesignacaoGerenteRelacionamento: confirmarDesignacaoGerenteRelacionamento,
            OnRecusarDesignacaoGerenteRelacionamento: recusarDesignacaoGerenteRelacionamento,
            OnRenovarApolice: renovarApolice,
            OnCancelarApolice: cancelarApolice,
            OnConfirmarRenovacaoApolice: confirmarRenovacaoApolice,
            OnConfirmarCancelamentoApolice: confirmarCancelamentoApolice
        },

        Form: {
            OnDesignarGerenteRelacionamento: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                designarGerenteRelacionamento(primaryControl, selectedControlSelectedItemIds);
            },
            OnConfirmarDesignacaoGerenteRelacionamento: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                confirmarDesignacaoGerenteRelacionamento(primaryControl, selectedControlSelectedItemIds);
            },
            OnRecusarDesignacaoGerenteRelacionamento: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                recusarDesignacaoGerenteRelacionamento(primaryControl, selectedControlSelectedItemIds);
            },
            OnRenovarApolice: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                renovarApolice(primaryControl, selectedControlSelectedItemIds);
            },
            OnCancelarApolice: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                cancelarApolice(primaryControl, selectedControlSelectedItemIds);
            },
            OnConfirmarRenovacaoApolice: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                confirmarRenovacaoApolice(primaryControl, selectedControlSelectedItemIds);
            },
            OnConfirmarCancelamentoApolice: function (primaryControl, firstPrimaryItemId) {

                var selectedControlSelectedItemIds = new Array();
                selectedControlSelectedItemIds.push(firstPrimaryItemId);

                confirmarCancelamentoApolice(primaryControl, selectedControlSelectedItemIds);
            }
        }
    };
})();

Apolice.Ribbon.EnableRule = function () {

    /// <summary>
    /// Checar Se Usuário é Membro do Perfil
    /// </summary>
    /// <param name="profiles" type="array">
    /// Lista de perfis para ser checado
    /// </param>
    /// <returns type="boolean" />
    var isUserProfile = function (profiles, contains) {

        var result = false;

        try {
            if (!Array.isArray(profiles)) throw new Error("O objeto 'profiles' é inválido.");

            if (profiles != null && profiles.length > 0) {

                var currentUserRoles = Xrm.Page.context.getUserRoles();

                for (var i1 in currentUserRoles) {
                    var consulta = Helpers.Buscar("roles(" + currentUserRoles[i1] + ")?$select=name");
                    if (consulta != null) {
                        for (var i2 in profiles) {
                            if (consulta.name != null && consulta.name.toLowerCase() == profiles[i2].toLowerCase()) {
                                result = true;
                                break;
                            } else {
                                if ((contains != null && contains == true) && (consulta.name != null && consulta.name.toLowerCase().indexOf(profiles[i2].toLowerCase()) > -1)) {
                                    result = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

        } catch (ex) {
            if (window.console) console.error("Erro na checagem se usu\u00e1rio \u00e9 membro do perfil Feedback CORPORATE. Detalhe: " + ex.message);
        }
        return result;
    };

    return {

        IsEnableRuleMatriz: function () {

            //var perfis = ["Administrador do Sistema", "Personalizador de Sistema", "Gerente CER - Corporativo"];
            var perfis = ["Gerente CER - Corporativo"];

            if (isUserProfile(perfis, true))
                return true;
            else
                return false;
        },

        IsEnableRuleSuperintendente: function () {

            //var perfis = ["Administrador do Sistema", "Personalizador de Sistema", "Superintendente Relacionamento - Corporativo"];
            var perfis = ["Superintendente Relacionamento - Corporativo"];

            if (isUserProfile(perfis, true))
                return true;
            else
                return false;
        },

        IsEnableRuleRelacionamento: function () {

            //var perfis = ["Administrador do Sistema", "Personalizador de Sistema", "Gerente Relacionamento - Corporativo"];
            var perfis = ["Gerente Relacionamento - Corporativo"];

            if (isUserProfile(perfis, true))
                return true;
            else
                return false;
        },

    };
}();

Apolice.Utility = function () {

    var message = {
        Error: function (content) {
            return [
                "<table border='0' cellpadding='0' cellspacing='4'>",
                "    <tr>",
                "        <td valign='middle'>",
                "            <img tabindex='0' alt='ERRO' title='ERRO' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAA3NCSVQICAjb4U/gAAAAP1BMVEX////YAwPYAwPYAwPYAwPYAwPYAwPYAwPYAwPYAwPYAwP////97+/64OD40ND1wMDzsLDwoaHfMjLaExPYAwNUa838AAAAFXRSTlMAETNEVWaqu8zd7v////////////8fXFKAAAAACXBIWXMAAA50AAAOdAFrJLPWAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M0BrLToAAAAHxJREFUGJVVT9sWwyAIw3VFqx1rhf//1gV0XZcHIDnhRgSsxQBeaeAR1JFT8GoXNleK3ZDRj9TfivDqKJcwHE207+3wyeRGlSY7RJQ1BFcGNxsC/H8CuMi3hedQdJ0x1NfqqTNgLeX7YYxL0/bjJZ5Jl4fT/PfJeLDy4vUHm0IONagzvdgAAAAASUVORK5CYII='>",
                "        </td>",
                "        <td>&ensp;</td>",
                "        <td>" + content + "</td>",
                "    </tr>",
                "</table>"
            ].join("");
        },
        Sucess: function (content) {
            return [
                    "<table border='0' cellpadding='0' cellspacing='4'>",
                    "    <tr>",
                    "        <td valign='middle'>",
                    "            <img tabindex='0' width='12' alt='SUCESSO' title='SUCESSO' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAAA3NCSVQICAjb4U/gAAAAGFBMVEX///+m2pCa1IJ+1F9pvEtjs0aJmIRVpjhBifVGAAAACHRSTlMA/////////9XKVDIAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAYdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3Jrc0+zH04AAAA6SURBVAiZY2DAARKgNJsZlJEcDhFiMy2DSIMF2NSgAilGCRAVbM5iYAEGhlRDmJbQMqgh6XBjcVgLAP10CsSrybWaAAAAAElFTkSuQmCC'>",
                    "        </td>",
                    "        <td>&ensp;</td>",
                    "        <td>" + content + "</td>",
                    "    </tr>",
                    "</table>"
            ].join("");
        }
    };

    return {
        ReplaceBracket: function (id) {
            if (id != null) {
                var currentId = id.replace("{", "").replace("}", "").toUpperCase();
                return (currentId != null && currentId.length == 36) ? currentId : null;
            }
            return null;
        },

        FormattedMessage: message
    }
}();
