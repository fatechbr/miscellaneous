/// <reference path="\Base\helpers.js" />

var PessoaFisica = {
    OnLoad: function () {
        if (Xrm.Page.context.client.getClient() == "Mobile") return;
        Xrm.Page.getAttribute("telephone1").addOnChange(PessoaFisica.OnChangeTelephone1);
        Xrm.Page.getAttribute("mobilephone").addOnChange(PessoaFisica.OnChangeMobilephone);
        Xrm.Page.getAttribute("address1_postalcode").addOnChange(PessoaFisica.OnChangeCEP);
    },

    OnChangeTelephone1: function () {
        Helpers.Mascara("telephone1", "telefone");
    },
    OnChangeMobilephone: function () {
        Helpers.Mascara("mobilephone", "telefone");
    },
    OnChangeCEP: function () {
        Helpers.PreencheEnderecoPorCEP("address1_postalcode", "address1_line1", "bso_numero", "address1_line3", "address1_city", "address1_stateorprovince", "address1_country");
    }
}