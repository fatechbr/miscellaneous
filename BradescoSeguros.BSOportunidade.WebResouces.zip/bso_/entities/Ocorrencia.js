/// <reference path="\Base\helpers.js" />

var Ocorrencia = {
    UsuarioPossuiPermissao: false,

    OnLoad: function () {
        Xrm.Page.getAttribute("bso_sla_prazo_estipulado").setSubmitMode("never");

        if (Xrm.Page.ui.getFormType() != 4 && Xrm.Page.ui.getFormType() != 3) {
            SDK.DependentOptionSet.init(parameters);
            Ocorrencia.VerificaUsuarioGerenteDeAtendimentoOuSuperintendente();
            Ocorrencia.ValidaBloqueioDeCampos();
            Ocorrencia.BloqueiaCamposTipoGeralEspecifico();
            Ocorrencia.BloqueiaCamposSemPermissao();
            Ocorrencia.ConfiguracaoDeEventos();
        }

        // if (Xrm.Page.getAttribute("casetypecode").getValue() == null) {
        // Ocorrencia.ObterEmpresaECorretoraDoContato();
        // }

    },

    ConfiguracaoDeEventos: function () {
        Xrm.Page.getAttribute("statuscode").addOnChange(Ocorrencia.OnChangeRazaoDoStatus);
        Xrm.Page.getAttribute("bso_produtoramoid").addOnChange(Ocorrencia.OnChangeProdutoRamo);
        Xrm.Page.getAttribute("bso_tipoatendimentogeralid").addOnChange(Ocorrencia.OnChangeTipoGeral);
        Xrm.Page.getAttribute("bso_prazoforadosla").addOnChange(Ocorrencia.ValidaBloqueioDeCampos);
        Xrm.Page.getAttribute("bso_prazoforadosla").addOnChange(Ocorrencia.PreencherPrazoEstipulado);
        Xrm.Page.getAttribute("bso_novoprazosla").addOnChange(Ocorrencia.PreencherPrazoEstipulado);
        // Xrm.Page.getAttribute("customerid").addOnChange(Ocorrencia.ObterEmpresaECorretoraDoContato);
        Xrm.Page.getAttribute("firstresponsebykpiid").addOnChange(Ocorrencia.ValidaKpiPreenchido);


        Xrm.Page.data.entity.addOnSave(Ocorrencia.PreencheCampoResponsavelUltimoStatus);
        Xrm.Page.data.entity.addOnSave(Ocorrencia.PreencherPrazoEstipulado);
        Xrm.Page.data.entity.addOnSave(Ocorrencia.BloqueiaCamposSemPermissao);
        Xrm.Page.data.entity.addOnSave(Ocorrencia.ExibirAlertaDescricao);
    },

    ExibirAlertaDescricao: function () {
        var descricao = Xrm.Page.getAttribute("bso_descricao").getValue();

        if (descricao == null || descricao == undefined || descricao == "") {
            var message = "Você está salvando uma ocorrência com a descrição em branco.";
            var type = "WARNING"; //INFO, WARNING, ERROR
            var id = "alerta_descricao"; // Id da notificacao

            Xrm.Page.ui.setFormNotification(message, type, id);
        }
        else {
            Xrm.Page.ui.clearFormNotification("alerta_descricao");
            return;
        }
    },

    OnChangeRazaoDoStatus: function () {
        SDK.DependentOptionSet.filterDependentField("statuscode", "bso_detalhamentodostatus");
    },

    PreencherPrazoEstipulado: function () {

        if (Xrm.Page.getAttribute("bso_novoprazosla").getValue() != null && Xrm.Page.getControl("bso_novoprazosla").getVisible()) {
            var novoPrazoSla = Helpers.ObterDataComHorarioFinal(Xrm.Page.getAttribute("bso_novoprazosla").getValue());

            if (!Helpers.DatasIguais(Xrm.Page.getAttribute("bso_novoprazosla").getValue(), Xrm.Page.getAttribute("bso_prazoestipulado").getValue()))
                Xrm.Page.getAttribute("bso_prazoestipulado").setValue(novoPrazoSla);
        }
        else {

            var respostaPorKpi = Ocorrencia.ObterRespostaPorKpi();
            if (respostaPorKpi != null) {
                respostaPorKpi = Helpers.ObterDataComHorarioFinal(respostaPorKpi);
                if (!Helpers.DatasIguais(respostaPorKpi, Xrm.Page.getAttribute("bso_prazoestipulado").getValue()))
                    Xrm.Page.getAttribute("bso_prazoestipulado").setValue(respostaPorKpi);
                Xrm.Page.data.entity.save();
            }
        }
    },

    ObterRespostaPorKpi: function () {//Mesmo valor do campo prazo estipulado calculado
        if (Xrm.Page.getAttribute("firstresponsebykpiid") == null || Xrm.Page.getAttribute("firstresponsebykpiid").getValue() == null) {
            return null;
        }
        var instanciaKpiId = Helpers.RemoverChaves(Xrm.Page.getAttribute("firstresponsebykpiid").getValue()[0].id);

        var consulta = Helpers.Buscar("slakpiinstances?$select=failuretime&$filter=slakpiinstanceid eq " + instanciaKpiId);
        if (consulta.length > 0) {
            return new Date(consulta[0]["failuretime"]);
        }
    },

    VerificaUsuarioGerenteDeAtendimentoOuSuperintendente: function () {
        var usuarioDoContextoOcorrencia = Xrm.Page.context.getUserId();
        var usuarioOcorrencia = Helpers.RemoverChaves(usuarioDoContextoOcorrencia);

        var cargoDoUsuario = "";

        var consulta = Helpers.Buscar("systemusers?$select=bso_cargousurio&$filter=systemuserid eq " + usuarioOcorrencia);

        if (consulta[0]["bso_cargousurio@OData.Community.Display.V1.FormattedValue"] != null) {
            cargoDoUsuario = consulta[0]["bso_cargousurio@OData.Community.Display.V1.FormattedValue"].toUpperCase();
        }

        if (cargoDoUsuario != "SUPERINTENDENTE" && cargoDoUsuario != "GERENTE ATENDIMENTO" && cargoDoUsuario != "SUPEX") {
            Ocorrencia.UsuarioPossuiPermissao = false;
        }
        else {
            Ocorrencia.UsuarioPossuiPermissao = true;
        }
    },

    BloqueiaCamposSemPermissao: function () {
        if (Xrm.Page.getAttribute("bso_tipoatendimentogeralid").getValue() &&
            Xrm.Page.getAttribute("bso_tipoatendimentoespecificoid").getValue() &&
            Xrm.Page.getAttribute("bso_produtoramoid").getValue()) {
            if (Ocorrencia.UsuarioPossuiPermissao) {
                Xrm.Page.getControl("bso_tipoatendimentogeralid").setDisabled(false);
                Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(false);
                Xrm.Page.getControl("bso_produtoramoid").setDisabled(false);
                Xrm.Page.getControl("bso_tipodeatendimentooutro").setDisabled(false);
            }
            else {
                Xrm.Page.getControl("bso_tipoatendimentogeralid").setDisabled(true);
                Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(true);
                Xrm.Page.getControl("bso_produtoramoid").setDisabled(true);
                Xrm.Page.getControl("bso_tipodeatendimentooutro").setDisabled(true);
            }
        }
    },

    ValidaKpiPreenchido: function () {
        if (Xrm.Page.getAttribute("firstresponsebykpiid") != null || Xrm.Page.getAttribute("firstresponsebykpiid").getValue() != null && Xrm.Page.getAttribute("bso_prazoestipulado").getValue() == null) {
            Ocorrencia.PreencherPrazoEstipulado();
        }
    },

    ValidaBloqueioDeCampos: function () {

        if ((Xrm.Page.getAttribute("bso_prazoforadosla").getValue() == true) && (!Ocorrencia.UsuarioPossuiPermissao)) {
            Xrm.Page.getControl("bso_prazoforadosla").setDisabled(true);
        }
        if ((Xrm.Page.getAttribute("bso_prazoforadosla").getValue() == true)) {
            if (Ocorrencia.UsuarioPossuiPermissao) {
                Xrm.Page.getControl("bso_novoprazosla").setDisabled(false);
            }
            else {
                Xrm.Page.getControl("bso_novoprazosla").setDisabled(true);
            }
        }
    },

    PreencheCampoResponsavelUltimoStatus: function () {
        var usuarioDoContextoOcorrencia = Xrm.Page.context.getUserName();

        if (Xrm.Page.getAttribute("statuscode").getIsDirty()) {
            Xrm.Page.getAttribute("bso_responsavelultimostatus").setValue(usuarioDoContextoOcorrencia);
            Xrm.Page.getAttribute("bso_dataultimostatus").setValue(Date.now());
        }
    },

    OnChangeProdutoRamo: function () {
        Xrm.Page.getControl("bso_tipoatendimentogeralid").setDisabled(true);
        Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(true);

        Xrm.Page.getAttribute("bso_tipoatendimentogeralid").setValue(null);
        Xrm.Page.getAttribute("bso_tipoatendimentoespecificoid").setValue(null);

        if (Xrm.Page.getAttribute("bso_produtoramoid").getValue() != null) {
            Xrm.Page.getControl("bso_tipoatendimentogeralid").setDisabled(false);
        }
    },

    OnChangeTipoGeral: function () {
        Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(true);
        Xrm.Page.getAttribute("bso_tipoatendimentoespecificoid").setValue(null);
        if (Xrm.Page.getAttribute("bso_tipoatendimentogeralid").getValue() != null) {
            Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(false);
        }
    },

    BloqueiaCamposTipoGeralEspecifico: function () {
        Xrm.Page.getControl("bso_tipoatendimentogeralid").setDisabled(true);
        Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(true);

        if (Xrm.Page.getAttribute("bso_produtoramoid").getValue() != null) {
            Xrm.Page.getControl("bso_tipoatendimentogeralid").setDisabled(false);
        }
        if (Xrm.Page.getAttribute("bso_tipoatendimentogeralid").getValue() != null) {
            Xrm.Page.getControl("bso_tipoatendimentoespecificoid").setDisabled(false);
        }
    },

    ObterEmpresaECorretoraDoContato: function () {
        var empresa = null;
        var corretora = null;

        if (Xrm.Page.getAttribute("customerid").getValue() != null) {
            if (Xrm.Page.getAttribute("customerid").getValue()[0].entityType == "contact") {
                var contato = Xrm.Page.getAttribute("customerid").getValue()[0].id;
                var contatoId = Helpers.RemoverChaves(contato);

                var consultaContato = Helpers.Buscar("contacts?$select=_parentcustomerid_value,_bso_corretoraid_value&$filter=contactid eq " + contatoId);

                if (consultaContato[0]["_parentcustomerid_value"] && consultaContato[0]["_parentcustomerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"] == "account") {
                    empresa = Helpers.CreateLookup(
                        consultaContato[0]["_parentcustomerid_value"],
                        consultaContato[0]["_parentcustomerid_value@OData.Community.Display.V1.FormattedValue"],
                        consultaContato[0]["_parentcustomerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                    );
                }

                if (consultaContato[0]["_bso_corretoraid_value"]) {
                    corretora = Helpers.CreateLookup(
                        consultaContato[0]["_bso_corretoraid_value"],
                        consultaContato[0]["_bso_corretoraid_value@OData.Community.Display.V1.FormattedValue"],
                        consultaContato[0]["_bso_corretoraid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                    );
                }
                else if (empresa != null) {
                    var consultaConta = Helpers.Buscar("accounts?$select=_bso_corretoraid_value&$filter=accountid eq " + Helpers.RemoverChaves(empresa[0].id));
                    if (consultaConta[0]["_bso_corretoraid_value"]) {
                        corretora = Helpers.CreateLookup(
                            consultaConta[0]["_bso_corretoraid_value"],
                            consultaConta[0]["_bso_corretoraid_value@OData.Community.Display.V1.FormattedValue"],
                            consultaConta[0]["_bso_corretoraid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                        );
                    }
                }
                Xrm.Page.getAttribute("bso_empresaid").setValue(empresa);
                Xrm.Page.getAttribute("bso_corretoraid").setValue(corretora);
                Xrm.Page.data.entity.save();
            }
        }
    },

    ResolverOcorrencia: function () {
		debugger;
		var currentUserRoles = Xrm.Page.context.getUserRoles();
		var proceed = true;
		
		for (var i = 0; i < currentUserRoles.length; i++)
		{
			var userRole = currentUserRoles[i];

			if (userRole == '0C2DC77D-6ED1-E411-BD5B-005056B1027B' || userRole == '0c2dc77d-6ed1-e411-bd5b-005056b1027b')
			{
				proceed = false;
			}
		}
		
		if (proceed){
			var StatusSLAAtual = Xrm.Page.getAttribute("bso_status_sla").getValue();
			Xrm.Page.getAttribute("bso_dataconclusao").setValue(new Date());

			if (StatusSLAAtual != 3)
				Xrm.Page.getAttribute("bso_status_sla").setValue(4);

			Xrm.Page.data.entity.save();
			var ocorrenciaid = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "")
			var ocorrencia =
			{
				"Status": 5, // Status Reason Value.
				"IncidentResolution": {
					"subject": "Close Opportunity",
					"incidentid@odata.bind": "/incidents(" + ocorrenciaid + ")" //Case GUID to be closed
				}
			};

			var request = new XMLHttpRequest();
			request.open("POST", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/CloseIncident", true);
			request.setRequestHeader("Accept", "application/json");
			request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
			request.setRequestHeader("OData-MaxVersion", "4.0");
			request.setRequestHeader("OData-Version", "4.0");
			request.onreadystatechange = function () {
				if (this.readyState === 4) {
					request.onreadystatechange = null;
					if (this.status === 204) {
						Xrm.Page.data.refresh();
						window.alert("Ocorrência resolvida com sucesso")
					}
				}
			};
			request.send(JSON.stringify(ocorrencia));
		}
		else{
			window.alert("Você não tem permissão para resolver ocorrências.");
		}
    },

    CancelarSemPreencher: function () {
        //Valida a opção:
        var promptMessage = "Deseja realmente cancelar esta ocorrência?";
        var okMessage = okMessage || "Ocorrência será cancelada.";
        var cancelMessage = cancelMessage || "Requisição não efetuada";
        if (confirm(promptMessage)) {

            var OcorrenciaId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "")

            Xrm.Page.data.entity.attributes.get("bso_canaldeatendimento").setRequiredLevel("none");
            Xrm.Page.data.entity.attributes.get("customerid").setRequiredLevel("none");
            Xrm.Page.data.entity.attributes.get("bso_empresaid").setRequiredLevel("none");
            Xrm.Page.data.entity.attributes.get("bso_corretoraid").setRequiredLevel("none");
            Xrm.Page.data.entity.attributes.get("bso_produtoramoid").setRequiredLevel("none");
            Xrm.Page.data.entity.attributes.get("bso_tipoatendimentogeralid").setRequiredLevel("none");
            Xrm.Page.data.entity.attributes.get("bso_tipoatendimentoespecificoid").setRequiredLevel("none");
            
            var entity = {};
            entity.statecode = 2;
            entity.statuscode = 6;
            entity.servicestage = 2;

            var req = new XMLHttpRequest();
            req.open("PATCH", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/incidents(" + OcorrenciaId + ")", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 204) {
                        Xrm.Page.data.refresh();
                        window.alert("Ocorrência cancelada com sucesso")
                    } else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send(JSON.stringify(entity));
        }
        else {
            alert(cancelMessage);
        }
    }
};

var parameters =
    [
        {
            "parent": "statuscode",
            "child": "bso_detalhamentodostatus",
            "options": {
                "3": [
                    "1",
                    "2",
                    "3",
                    "4",
                    "5",
                    "6",
                    "7"
                ],
                "2": [
                    "8",
                    "9",
                    "10",
                    "11",
                    "12",
                    "13",
                    "14",
                    "15",
                    "16",
                    "17",
                    "18",
                    "19",
                    "20",
                    "21",
                    "22",
                    "23"
                ]
            }
        }
    ];