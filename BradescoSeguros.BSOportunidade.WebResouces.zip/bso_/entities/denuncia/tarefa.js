var Tarefa = {
    EnviarParaCompliance: function () {
        if (Xrm.Page.getAttribute("statuscode").getValue() != 861500000 && Xrm.Page.getAttribute("statuscode").getValue() != 861500002) {
            alert("Não é permitido enviar a resposta neste momento (Razão do status).");
            return;
        }
        if (Tarefa.VerificaEnvioParaCompliance()) {
            //Xrm.Page.getAttribute("statuscode").setValue(861500001); //Em Analise
            //Xrm.Page.data.save().then(Tarefa.ExecutarChamadaDoWorkflow("Enviado para a fila do Compliance."), null);
            Xrm.Page.data.save();
            Tarefa.ExecutarChamadaDoWorkflow("Enviado para a fila do Compliance.");
            Xrm.Page.ui.close();
        }
    },

    EnviarParaArea: function () {
        if (Xrm.Page.getAttribute("statuscode").getValue() != 861500001) {
            alert("Não é permitido rejeitar a resposta neste momento (Razão do status).");
            return;
        }
        if (Tarefa.VerificaEnvioParaArea()) {
            //Xrm.Page.getAttribute("statuscode").setValue(861500002); //Em Analise
            //Xrm.Page.data.save().then(Tarefa.ExecutarChamadaDoWorkflow("Enviado para a fila da Área Envolvida."), null);
            Xrm.Page.data.save();
            Tarefa.ExecutarChamadaDoWorkflow("Enviado para a fila da Área Envolvida.")
            Xrm.Page.ui.close();
        }
    },

    ExecutarChamadaDoWorkflow: function (mensagemSucesso) {

        var resultado = Helpers.ExecutarWorkflowSobDemanda("ProcessoApuracao", "task", Xrm.Page.data.entity.getId(), false);

        if (resultado == "" || resultado == undefined) {
            alert(mensagemSucesso);
            Xrm.Page.data.refresh();
        }
        else {
            alert(resultado);
        }
    },

    VerificaEnvioParaCompliance: function () {
        if (!Tarefa.VerificaSeUsuarioPertenceAAreaDaTarefa()) {
            alert('Somente responsáveis pela área podem executar essa ação.');
            return false;
        }
        else if (!Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - ÁREA GESTOR")) {
            alert('Somente responsáveis pela área podem executar essa ação.');
            return false;
        }
        else if (!Tarefa.TarefaComAnotacaoDaArea()) {
            alert('Necessário preencher uma anotação da área antes de enviar.');
            return false;
        }

        return true;
    },

    VerificaEnvioParaArea: function () {
        if (!Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - COMPLIANCE")) {
            alert('Somente usuários Compliance podem executar essa ação.');
            return false;
        }

        return true;
    },

    OnLoad: function () {

    },

    OnSave: function () {

    },


    ObterFilaDaAreaDaTarefa: function () {
        var areaId = Helpers.RemoverChaves(Xrm.Page.getAttribute("bso_areaid").getValue()[0].id);
        var areas = Helpers.Buscar("bso_areas(" + areaId + ")?$select=_bso_filaid_value");
        if (areas) {
            if (!areas["_bso_filaid_value"])
                alert('Não foi possível encontrar fila da Área.');
            else
                return areas["_bso_filaid_value"];
        }
        else {
            alert("Não foi possível encontrar a Área.");
        }
        return null;
    },

    VerificaSeUsuarioPertenceAAreaDaTarefa: function () {
        var filaId = Tarefa.ObterFilaDaAreaDaTarefa();
        if (filaId) {
            var usuarioDoContexto = Xrm.Page.context.getUserId();
            var usuarioId = Helpers.RemoverChaves(usuarioDoContexto);
            var query = "systemusers(" + usuarioId + ")/Microsoft.Dynamics.CRM.RetrieveUserQueues(IncludePublic=true)"
            var consulta = Helpers.Buscar(query);
            if (consulta && consulta.length > 0) {
                for (var i = 0; i < consulta.length; i++) {
                    if (filaId == consulta[i]["queueid"])
                        return true;
                }
            }
        }
        return false;
    },

    TarefaComAnotacaoDaArea: function () {
        var tarefaId = Helpers.RemoverChaves(Xrm.Page.data.entity.getId());

        var anotacoes = Helpers.Buscar("annotations?$select=_createdby_value,createdon&$top=1&$orderby=createdon desc&$filter=_objectid_value eq " + tarefaId);

        if (anotacoes && anotacoes.length > 0) {
            return Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - ÁREA", anotacoes[0]["_createdby_value"]);
        }
        return false;
    }
}