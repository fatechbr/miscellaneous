/// <reference path="\Base\helpers.js" />

var Ocorrencia = {
    usuarioCompliance: false,
    usuarioOuvidoria: false,
    cargoDoUsuario: "",

    OnLoad: function ()
    {
        Xrm.Page.getAttribute("bso_areaid").addOnChange(Ocorrencia.OnChange_bso_areaid);
        Xrm.Page.getAttribute("bso_denunciante").addOnChange(Ocorrencia.OnChange_bso_denunciante);

        Ocorrencia.VerificaUsuario();
        Ocorrencia.DefinirAcessibilidadePorEmpresaECargo();
        Ocorrencia.SetLoadDados();
        Ocorrencia.listaTipoProdutoOnchange();
        Ocorrencia.VerificaFormulario();
    },

    OnSave: function ()
    {

    },
    OnChange_bso_areaid: function ()
    {
        Ocorrencia.DefinirAcessibilidadePorEmpresaECargo();
        Ocorrencia.listaTipoProdutoOnchange();
    },

    OnChange_bso_respostadadenuncia: function ()
    {
        Ocorrencia.LimparRespostaSatisfatoria();
    },

    OnChange_bso_denunciante: function () {
        Ocorrencia.VerificarDenunciante();
    },


    VerificaFormulario: function () {
        var resultado = Helpers.Buscar("bso_parametros?$select=bso_valor&$filter=bso_name eq 'CONTATO_PADRAO'");

        if (resultado != null) {
            var estado = Xrm.Page.ui.getFormType();

            if (estado == 1) {

                var lookupValue = new Array();
                lookupValue[0] = new Object();
                lookupValue[0].id = resultado[0].bso_valor;
                lookupValue[0].name = "Contato Padrao";
                lookupValue[0].entityType = "contact";

                Xrm.Page.getAttribute("customerid").setValue(lookupValue);
            }
        } else {
            alert("Parâmetro Contato_Padrão está nulo");
        }
    },

    VerificarDenunciante: function () {
        var resultado = Helpers.Buscar("bso_parametros?$select=bso_valor&$filter=bso_name eq 'CONTATO_PADRAO'");

        if (resultado != null) {
            var denunciante = Xrm.Page.getAttribute("bso_denunciante").getValue();
            if (denunciante == null) {
                Xrm.Page.getAttribute("customerid").setValue(denunciante);
            } else {
                var lookupValue = new Array();
                lookupValue[0] = new Object();
                lookupValue[0].id = denunciante[0].id;
                lookupValue[0].name = denunciante[0].name;
                lookupValue[0].entityType = "contact";

                if (lookupValue[0].id != null) {
                    Xrm.Page.getAttribute("customerid").setValue(lookupValue);
                }
            }
        } else {
            alert("Parâmetro Contato_Padrão está nulo");
        }
       

    },

    VerificaUsuario: function ()
    {
        Ocorrencia.usuarioCompliance = Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - COMPLIANCE");
        Ocorrencia.usuarioOuvidoria = Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - OUVIDORIA");

        //adicionando
        Xrm.Page.getControl("bso_denunciante").setVisible(false); //Denunciante
        Xrm.Page.getControl("bso_juridico").setVisible(false); //Juridico
        Xrm.Page.getControl("bso_igl").setVisible(false); //IGL
        Xrm.Page.getControl("bso_providencias_adotadas").setVisible(false); //Providencias Adotadas
        Xrm.Page.ui.tabs.get("general").sections.get("general_section_8").setVisible(false); //seção Detalhes do Denunciante

   
        if (Ocorrencia.usuarioOuvidoria) {
            Xrm.Page.ui.tabs.get("general").sections.get("tab_10_section_1").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_9").setVisible(false);

            //adicionando
            Xrm.Page.getControl("bso_denunciante").setVisible(true); //Denunciante
            Xrm.Page.getAttribute("caseorigincode").setValue(1); //opção Disque Fraude
            Xrm.Page.getControl("caseorigincode").setDisabled(true); //Origem
        }

        //adicionando
        if (Ocorrencia.usuarioCompliance) {
            Xrm.Page.getControl("bso_denunciante").setVisible(true); //Denunciante
            Xrm.Page.getControl("bso_juridico").setVisible(true); //Juridico
            Xrm.Page.getControl("bso_igl").setVisible(true); //IGL
            Xrm.Page.getControl("bso_providencias_adotadas").setVisible(true); //Providencias Adotadas
            Xrm.Page.ui.tabs.get("general").sections.get("general_section_8").setVisible(true); //seção Detalhes do Denunciante
        }
    },

    DefinirAcessibilidadePorEmpresaECargo: function ()
    {
        var empresa = Xrm.Page.getAttribute("bso_areaid").getValue();
        var empresaNome = "";
        if (empresa)
            empresaNome = empresa[0].name.toLowerCase();

        if (Ocorrencia.usuarioOuvidoria)
        {
            var resultado = Helpers.Buscar("bso_parametros?$select=bso_valor&$filter=bso_name eq 'SCRIPT_ATENDIMENTO'");
            Xrm.Page.getAttribute("bso_script_atendimento").setValue(resultado[0]["bso_valor"]);
            Xrm.Page.ui.tabs.get("tab_Script").setVisible(true);
        }
        else
        {
            Xrm.Page.ui.tabs.get("tab_Script").setVisible(false);
        }

        if (empresaNome == "banco bradesco - ética" || empresaNome == "banco bradesco - evidência" || Ocorrencia.usuarioCompliance)
        {
            //Xrm.Page.getControl("bso_rascunho").setDisabled(false);
        }
        else
        {
            //Xrm.Page.getControl("bso_rascunho").setDisabled(true);
        }
    },

    FiltrarCampoResponsavel: function ()
    {
        //debugger;
        Xrm.Page.getControl("bso_responsavel_apuracaoid").addPreSearch(Ocorrencia.FiltroDoCampoResponsavel);
    },
    RemoverFiltroDoCampoResponsavel: function ()
    {
        Xrm.Page.getControl("bso_responsavel_apuracaoid").removePreSearch(Ocorrencia.FiltroDoCampoResponsavel);
    },

    FiltroDoCampoResponsavel: function ()
    {
        var ocorrenciaId = Helpers.RemoverChaves(Xrm.Page.data.entity.getId());
        var resultado = Helpers.Buscar("bso_areas?$select=_bso_areaid_value&$filter=_bso_ocorrenciaid_value eq " + ocorrenciaId);
        var filter = "<filter type='and'><condition attribute= 'systemuserid' operator= 'in'>";

        debugger;
        for (var i = 0; i < resultado.length; i++)
        {
            var resultado2 = Helpers.Buscar("systemusers?$select=systemuserid&$filter=_bso_areaid_value eq " + resultado[i]["_bso_areaid_value"]);

            for (var j = 0; j < resultado2.length; j++)
            {
                filter += "<value>{" + resultado2[j]["systemuserid"] + "}</value>";
            }
        }
        filter += "</condition></filter>";

        Xrm.Page.getControl("bso_responsavel_apuracaoid").addCustomFilter(filter, "systemuser");
    },

    SetLoadDados: function ()
    {
        var currentDateTime = new Date();

        if (Xrm.Page.getAttribute("bso_datadadenuncia").getValue() == null)
        {
            Xrm.Page.getAttribute("bso_datadadenuncia").setValue(currentDateTime);
        }
    },

    listaTipoProdutoOnchange: function ()
    {
        var empresa = Xrm.Page.getAttribute("bso_areaid").getValue();
        var empresaNome = "";
        if (empresa)
            empresaNome = empresa[0].name.toLowerCase();

        //var _tipoProduto = Xrm.Page.getAttribute("bso_tipo_produto").getValue();
        if (empresaNome.indexOf("auto/re") != -1) //Bradesco Auto/RE
        {

            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500000, text: "Auto" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500001, text: "Ramos Elementares" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500000, text: "Auto" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500001, text: "Ramos Elementares" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });


        } else if (empresaNome.indexOf("saúde/mediservice") != -1) //Bradesco Saude/Mediservice
        {

            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500004, text: "Saúde" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500004, text: "Saúde" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        } else if (empresaNome.indexOf("vida e previdência") != -1) //Bradesco Vida e Previdência
        {
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500002, text: "Vida" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500003, text: "Previdência" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500002, text: "Vida" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500003, text: "Previdência" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        } else if (empresaNome.indexOf("seguros") != -1) //Bradesco Seguros
        {
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros


            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        } else if (empresaNome.indexOf("dental") != -1) //Bradesco Dental
        {
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500005, text: "Odonto" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500005, text: "Odonto" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        } else if (empresaNome.indexOf("capitalização") != -1) //Bradesco Capitalização
        {
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização       
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500006, text: "Capitalização" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500006, text: "Capitalização" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        } else if (empresaNome.indexOf("emp. imobiliários") != -1) //Bradesco Emp. Imobiliários
        {
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        } else if (empresaNome.indexOf("outros") != -1)
        { //Outros
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500000); //Auto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500001); //RE
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500002); //Vida
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500003); //Previdência        
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500004); //Saúde
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500005); //Odonto
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500006); //Capitalização
            //Xrm.Page.getControl("header_process_bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
            //Xrm.Page.getControl("header_process_bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });

        }
        else
        {
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500000); //Auto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500001); //RE
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500002); //Vida
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500003); //Previdência
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500004); //Saúde
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500005); //Odonto
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500006); //Capitalização
            Xrm.Page.getControl("bso_tipo_produto").removeOption(861500007); //Outros

            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500000, text: "Auto" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500001, text: "Ramos Elementares" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500002, text: "Vida" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500003, text: "Previdência" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500004, text: "Saúde" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500005, text: "Odonto" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500006, text: "Capitalização" });
            Xrm.Page.getControl("bso_tipo_produto").addOption({ value: 861500007, text: "Outros" });
        }
    },

    GerarProtocolo: function ()
    {
        var Processo = Xrm.Page.getAttribute("ticketnumber").getValue();
        var Protocolo = Xrm.Page.getAttribute("title").getValue();

        if (Processo != null)
        {
            if (Protocolo != Processo)
            {
                Xrm.Page.getAttribute("title").setValue(Processo);
                Xrm.Page.data.entity.save();
            }
        }
    },

    VerificarUsualogado: function ()
    {
        var IdUsuarioLogado = Xrm.Page.context.getUserId();
        var IdProprietario = Xrm.Page.data.entity.attributes.get("ownerid").getValue()[0].id;

        if (IdUsuarioLogado == IdProprietario)
        {
            return true;
        }
        else
        {
            return false;
        }
    },

    SetHabiltarRespostaDenuncia: function (cargo)
    {
        if (cargo != "")
        {

            if (cargo == "ATENDENTE")
            {

                if (Xrm.Page.ui.getFormType() == 1)
                {

                    //Xrm.Page.getControl("header_process_bso_datadadenuncia").setDisabled(true);

                    if (Xrm.Page.getAttribute("caseorigincode").getValue() == null)
                    {
                        //No formulario - Remove o item 2 e 3    
                        Xrm.Page.getControl("caseorigincode").removeOption(2);
                        Xrm.Page.getControl("caseorigincode").removeOption(3);
                        //No processo flow
                        //Xrm.Page.getControl("header_process_caseorigincode").removeOption(2);
                        //Xrm.Page.getControl("header_process_caseorigincode").removeOption(3);
                    }
                } else
                {
                    var idProcesso = "85cff089-3be4-42ca-978b-24ee6e406f7d";
                    Xrm.Page.data.process.setActiveProcess(idProcesso, switchProcessEnd);
                }

            }

            if (cargo == "COMPLIANCE")
            {

                if (Xrm.Page.ui.getFormType() == 1)
                {

                    if (Xrm.Page.getAttribute("caseorigincode").getValue() == null)
                    {
                        //No formulario - Remove o item 1    
                        Xrm.Page.getControl("caseorigincode").removeOption(1);
                        //No processo flow 
                        //Xrm.Page.getControl("header_process_caseorigincode").removeOption(1);
                    }
                }
                if (Xrm.Page.ui.getFormType() == 2)
                {

                    var idProcesso = "519b1935-103d-4645-be4a-cfc515a553d2";
                    Xrm.Page.data.process.setActiveProcess(idProcesso, switchProcessEnd);

                    Xrm.Page.getControl("bso_denunciante").setVisible(false);
                    //Xrm.Page.getControl("header_process_bso_denunciante").setVisible(false);
                    Xrm.Page.ui.tabs.get("general").sections.get("general_section_8").setVisible(false);
                }

                Xrm.Page.ui.tabs.get("tab_8").setVisible(true);

                //Habilita a Guia de Resposta da Denuncia
                Xrm.Page.ui.tabs.get("tab_8").setVisible(true);
                //Xrm.Page.getControl("bso_respostasatisfatoria").setVisible(true);
                //Xrm.Page.getControl("bso_descriodarespostasatisfatoria").setVisible(true);

            }

            if (cargo == "RESPONSÁVEL")
            {
                //Habilita a Guia de Resposta da Denuncia
                Xrm.Page.ui.tabs.get("tab_8").setVisible(true);
                //Xrm.Page.getControl("bso_respostasatisfatoria").setVisible(false);
                //Xrm.Page.getControl("bso_descriodarespostasatisfatoria").setVisible(false);
            }
        }
    },

    switchProcessEnd: function (result)
    {
        if (result == "success")
        {

            // alert("Yes");

        }

        if (result == "invalid")
        {

            //alert("Not done");

        }
    },
    //MudarStatus: function (cargo)
    //{
    //    if (cargo != "")
    //    {

    //        var UsuarioIgual = VerificarUsualogado();
    //        var Status = Xrm.Page.getAttribute("statuscode").getValue();

    //        //caso seja o mesmo usuário logado e proprietário
    //        if (UsuarioIgual)
    //        {

    //            if (cargo == "COMPLIANCE")
    //            {

    //                //Habilita a Guia de Resposta da Denuncia
    //                Xrm.Page.ui.tabs.get("tab_8").setVisible(true);


    //                //verifica se status está em "Processo Aberto" e Modifica para "Processo Em Analise" 
    //                if (Status == "861500000" || Status == "861500007")
    //                {
    //                    //Xrm.Page.getAttribute("statuscode").setValue("861500002");
    //                    Xrm.Page.data.entity.save();
    //                }
    //            }

    //            if (cargo == "RESPONSÁVEL")
    //            {

    //                //HAbilita a Guia de Resposta da Denuncia
    //                Xrm.Page.ui.tabs.get("tab_8").setVisible(true);

    //                //Verifica se o status está em "Encaminhado para Apuração" e modifica para "Apuração em Análise"
    //                if (Status == "861500003")
    //                {

    //                    Xrm.Page.getAttribute("statuscode").setValue("861500004");
    //                    Xrm.Page.data.entity.save();
    //                }
    //            }
    //        }
    //    }
    //},

    LimparRespostaSatisfatoria: function ()
    {
        Xrm.Page.getAttribute("bso_respostasatisfatoria").setValue();
        Xrm.Page.getAttribute("bso_descriodarespostasatisfatoria").setValue();
    },

    EnviarParaAreas: function ()
    {
        Xrm.Page.data.entity.save();
        if (!Ocorrencia.usuarioCompliance)
        {
            alert("Somente Compliance pode executar essa ação.");
            return;
        }
        var resultado = Helpers.ExecutarWorkflowSobDemanda("ProcessoDenuncia", "incident", Xrm.Page.data.entity.getId(), false)
        if (resultado == "" || resultado == undefined) {
            alert("Envio realizado com sucesso.")
            Xrm.Page.data.refresh();
        }
        else {
            alert(resultado)
        }
    },

    RibbonCRUDEnviarAreas: function() {
        if (Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - COMPLIANCE") /*|| Helpers.UsuarioPossuiDireitoDeAcesso("ADMINISTRADOR DO SISTEMA")*/) {
            return true;
        } else {
            return false;
        }
    },
    RibbonReativarOcorrencia: function () {
        if (Helpers.UsuarioPossuiDireitoDeAcesso("BSDENUNCIA - COMPLIANCE GESTOR") /*|| Helpers.UsuarioPossuiDireitoDeAcesso("ADMINISTRADOR DO SISTEMA")*/) {
            return true;
        } else {
            return false;
        }
    }
}