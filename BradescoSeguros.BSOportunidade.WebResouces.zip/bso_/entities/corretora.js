var Corretora = {

    AlteraDataManterMapeamento: function () {
        Xrm.Page.getAttribute('bso_data_manter_mapeamento').setValue(new Date());
        Xrm.Page.data.entity.save();
    }
}