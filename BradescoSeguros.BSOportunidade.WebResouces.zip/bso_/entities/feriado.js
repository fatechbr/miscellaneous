﻿Feriado = function () {
    
    var feriadoTipo = {
        Municipal: 100000000,
        Estadual: 100000001,
        Nacional: 100000002
    };

    var onChangeTipo = function () {
        var bsoTipo = Xrm.Page.getAttribute("bso_tipo");
        if (bsoTipo != null && bsoTipo.getValue() != null) {
            var bsoTipoOption = bsoTipo.getSelectedOption();
            if (bsoTipoOption != null) {
                switch (bsoTipoOption.value) {
                    case feriadoTipo.Municipal:
                        Xrm.Page.getControl("bso_estado").setDisabled(false);
                        Xrm.Page.getControl("bso_cidade").setDisabled(false);
                        Xrm.Page.getAttribute("bso_estado").setRequiredLevel("required");
                        Xrm.Page.getAttribute("bso_cidade").setRequiredLevel("required");
                        break;
                    case feriadoTipo.Estadual:
                        Xrm.Page.getControl("bso_estado").setDisabled(false);
                        Xrm.Page.getControl("bso_cidade").setDisabled(true);
                        Xrm.Page.getAttribute("bso_estado").setRequiredLevel("required");
                        Xrm.Page.getAttribute("bso_cidade").setRequiredLevel("none");
                        Xrm.Page.getAttribute("bso_cidade").setValue(null);
                        break;
                    case feriadoTipo.Nacional:
                        Xrm.Page.getControl("bso_estado").setDisabled(true);
                        Xrm.Page.getControl("bso_cidade").setDisabled(true);
                        Xrm.Page.getAttribute("bso_estado").setRequiredLevel("none");
                        Xrm.Page.getAttribute("bso_cidade").setRequiredLevel("none");
                        Xrm.Page.getAttribute("bso_estado").setValue(null);
                        Xrm.Page.getAttribute("bso_cidade").setValue(null);
                        break;
                }
            }
        }
    };

    return {
        OnLoad: function () {
            onChangeTipo();
        },

        OnSave: function (econtext) {

        },

        OnChangeTipo: onChangeTipo,
    };
}();