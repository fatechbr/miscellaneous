﻿PeriodoDescontoDia = function () {
    var formType = {
        Undefined: 0,
        Create: 1,
        Update: 2,
        ReadOnly: 3,
        Disabled: 4,
        QuickCreate: 5,//Deprecated
        BulkEdit: 6,
        ReadOptimized: 11	//Deprecated
    };

    var onChangeGerenteRelacionamento = function () {

        Xrm.Page.getAttribute("bso_matricula").setValue(null);
        Xrm.Page.getAttribute("bso_superintendente").setValue(null);

        var bsoGerenteRelacionamento = Xrm.Page.getAttribute("bso_gerente_relacionamento");
        if (bsoGerenteRelacionamento != null && bsoGerenteRelacionamento.getValue() != null) {

            var bsoGerenteRelacionamentoId = PeriodoDescontoDia.Utility.ReplaceBracket(bsoGerenteRelacionamento.getValue()[0].id);

            if (bsoGerenteRelacionamentoId != null) {

                var query = "systemusers(" + bsoGerenteRelacionamentoId + ")?$select=systemuserid,fullname,_businessunitid_value,bso_matricula,_bso_superintendenteid_value";
                var consulta = Helpers.Buscar(query);

                if (consulta != null) {
                    if (consulta.bso_matricula != null) Xrm.Page.getAttribute("bso_matricula").setValue(consulta.bso_matricula);
                 
                    if (consulta._bso_superintendenteid_value != null) {
                        var superintendente = Helpers.CreateLookup(
                            consulta._bso_superintendenteid_value,
                            consulta["_bso_superintendenteid_value@OData.Community.Display.V1.FormattedValue"],
                            consulta["_bso_superintendenteid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                        );
                        Xrm.Page.getAttribute("bso_superintendente").setValue(superintendente);
                    }

                    if (consulta._businessunitid_value != null) {
                        var superintendente = Helpers.CreateLookup(
                            consulta._businessunitid_value,
                            consulta["_businessunitid_value@OData.Community.Display.V1.FormattedValue"],
                            consulta["_businessunitid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                        );
                        Xrm.Page.getAttribute("bso_sucursal").setValue(superintendente);
                    }
                }
            }
        }
    };

    return {
        OnLoad: function () {

            var control = Xrm.Page.getControl("bso_gerente_relacionamento");

            if (Xrm.Page.ui.getFormType() == formType.Create) {
                if (control == null) throw new Error("O campo 'Gerente Relacionamento' é obrigatório.");

                control.setDisabled(false);
                control.getAttribute().setRequiredLevel("required");
                control.getAttribute().setSubmitMode("dirty");
                control.getAttribute().setValue([{ id: Xrm.Page.context.getUserId(), entityType: 'systemuser', name: Xrm.Page.context.getUserName() }]);

                onChangeGerenteRelacionamento();
            } else {
                if (control != null && control.getAttribute() != null && control.getAttribute().getValue() == null) {
                    control.setDisabled(false);
                    control.getAttribute().setRequiredLevel("required");
                    control.getAttribute().setSubmitMode("dirty");
                }
            }
        },

        OnSave: function (econtext) {

        },

        OnChangeGerenteRelacionamento: onChangeGerenteRelacionamento,

        OnChangeDataInicio: function () {

            var bsoDataInicio = Xrm.Page.getAttribute("bso_data_inicio");
            var bsoDataTermino = Xrm.Page.getAttribute("bso_data_termino");

            if ((bsoDataInicio != null && bsoDataInicio.getValue() != null) && (bsoDataTermino != null && bsoDataTermino.getValue() != null)) {

                if (bsoDataInicio.getValue() > bsoDataTermino.getValue()) {
                    Xrm.Utility.alertDialog("A 'Data Início' é inválida! \n\nA data de início não pode ser maior do que a data de término do Período de Desconto de Dias.", function () {
                        bsoDataInicio.setValue(null);
                    })
                }
            }
        },

        OnChangeDataTermino: function () {

            var bsoDataInicio = Xrm.Page.getAttribute("bso_data_inicio");
            var bsoDataTermino = Xrm.Page.getAttribute("bso_data_termino");

            if ((bsoDataInicio != null && bsoDataInicio.getValue() != null) && (bsoDataTermino != null && bsoDataTermino.getValue() != null)) {

                if (bsoDataTermino.getValue() < bsoDataInicio.getValue()) {
                    Xrm.Utility.alertDialog("A 'Data Término' é inválida! \n\nA data de término não pode ser menor do que a data de início do Período de Desconto de Dias.", function () {
                        bsoDataTermino.setValue(null);
                    })
                }
            }
        },
    };
}();

PeriodoDescontoDia.Utility = function () {

    return {
        ReplaceBracket: function (id) {
            if (id != null) {
                var currentId = id.replace("{", "").replace("}", "").toUpperCase();
                return (currentId != null && currentId.length == 36) ? currentId : null;
            }
            return null;
        },
    }
}();
