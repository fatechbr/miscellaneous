var Xrm = window.parent.Xrm;
var CRMURL = Xrm.Page.context.getClientUrl();
var URLWebAPI = CRMURL + "/api/data/v8.2/";

var Util = {
    Inserir: function (query, data) {
        var resultado;
        $.support.cors = true;
        $.ajax({
            type: "POST",
            async: false,
            url: URLWebAPI + query,
            crossDomain: true,
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            dataType: "json",

            beforeSend: function(XMLHttpRequest) {
            },

            success: function(data, status, jqXHR) {
                resultado = true;
            },
            error: function(XmlHttpRequest, jqXHR, status) {
                if (XmlHttpRequest.responseText) {
                    var parse = JSON.parse(XmlHttpRequest.responseText);
                    result = parse.error.message;
                    alert("ATENÇÃO!!! \n Erro no processo de criação das respostas. \n Não será possível finalizar a pesquisa, acione o suporte e informe o erro imediatamente. \n \n" + "ERRO: \n" + result);
                    resultado = false;
                    //throw new Error("Erro na criação dos itens da pesquisa. " + result);
                   
                }
                else {
                    alert("ATENÇÃO!!! \n Erro no processo de criação das respostas. \n Não será possível finalizar a pesquisa, acione o suporte e informe o erro imediatamente. \n \n" + "ERRO: \n" + status);
                    resultado = false;
                    //throw new Error(status);
                }
            }
        });
        return resultado;
    },

    Consultar: function(urlWebAPI, query) {
        var resultado;
        $.ajax({
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: urlWebAPI + query,
            beforeSend: function(XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=*");
            },
            success: function(data, textStatus, XmlHttpRequest) {
                if (data) {
                    if (data.value) {
                        resultado = data.value;
                    }
                }
            },
            error: function(XmlHttpRequest, textStatus, errorThrown) {
                resultado = null;
            }
        });
        return resultado;
    },

    ObterIdDoCampoLookup: function(nomeLogicoDoCampoLookup) {
        return window.parent.Xrm.Page.getAttribute(nomeLogicoDoCampoLookup).getValue()[0].id.toString().substring(1, 37);
    },
}

var Business = {
    QueryPergunta: "bso_modelodeperguntas?$select=bso_hierarquiadapergunta, bso_id, bso_name, bso_tipoderesposta, bso_multiresposta, bso_ultimapergunta" + "&$filter=_bso_modelodepesquisaid_value eq " + Util.Consultar(URLWebAPI, "campaigns?$select=_bso_modelodepesquisaid_value&$filter=campaignid eq " + Util.ObterIdDoCampoLookup("bso_campanhaid"))[0]._bso_modelodepesquisaid_value,
    QueryResposta: "bso_modeloderespostas?$select=bso_name, bso_id&$filter=_bso_modelodeperguntaid_value eq ",

    ObterPerguntasComTiposDeRespostas: function() {
        //obtem as perguntas relacionadas a pesquisa
        var listaDasPerguntas = Util.Consultar(URLWebAPI, Business.QueryPergunta);
        var listafinal = [];

        for (i = 0; i < listaDasPerguntas.length; i++) {
            //se as perguntas tiverem o tipo de resposta conjunto de opções ou múltipla escolha
            if (listaDasPerguntas[i]["bso_tipoderesposta@OData.Community.Display.V1.FormattedValue"] === "Opções") {
                // cria objeto com pergunta, tipo da resposta e resposta
                var objeto = { pergunta: listaDasPerguntas[i], ultimapergunta: listaDasPerguntas[i]["bso_ultimapergunta"], tipoDaResposta: listaDasPerguntas[i]["bso_tipoderesposta@OData.Community.Display.V1.FormattedValue"], resposta: Util.Consultar(URLWebAPI, Business.QueryResposta + listaDasPerguntas[i]["bso_modelodeperguntaid"]) };
                listafinal.push(objeto);
            }
            // caso contrario cria um objeto com a pergunta e o tipo sa sua resposta
            else {
                var objeto = { pergunta: listaDasPerguntas[i], ultimapergunta: listaDasPerguntas[i]["bso_ultimapergunta"], tipoDaResposta: listaDasPerguntas[i]["bso_tipoderesposta@OData.Community.Display.V1.FormattedValue"] };
                listafinal.push(objeto);
            }
        }
        return listafinal;
    },

    CriarObjetoSimplificado: function(lista) {
        var pesquisa = new Object();
        pesquisa.titulo = 'pesquisa';
        pesquisa.perguntas = new Array();
        for (var i = 0; i < lista.length; i++) {
            var pergunta = new Object();
            pergunta.id = lista[i].pergunta.bso_id;
            pergunta.tipoDaResposta = lista[i].pergunta.bso_tipoderesposta;
            pergunta.titulo = lista[i].pergunta.bso_name;
            pergunta.respostas = new Array();
            pergunta.respostaFinal = "";
            pergunta.idanterior = null;
            pergunta.multiresposta = lista[i].pergunta.bso_multiresposta ? lista[i].pergunta.bso_multiresposta : "";
            pergunta.ultimapergunta = lista[i].ultimapergunta;
            if (!pergunta.ultimapergunta)
                pergunta.idproxima = lista[i].pergunta.bso_hierarquiadapergunta.split(";");//array
            if (lista[i].resposta) {
                for (var j = 0; j < lista[i].resposta.length; j++) {
                    var resposta = new Object();
                    resposta.titulo = lista[i].resposta[j].bso_name;
                    resposta.id = lista[i].resposta[j].bso_id ? lista[i].resposta[j].bso_id : "vazio";
                    pergunta.respostas.push(resposta);
                }

            } else {
                var resposta = new Object();
                resposta.titulo = 'resposta' + i;
                pergunta.respostas.push(resposta);
            }
            pesquisa.perguntas.push(pergunta);
        }
        return pesquisa;
    },


    ResultadoDaPesquisa: function(pesquisa) {
        var resultadoDaPesquisa = [];
        for (i = 0; i < pesquisa.perguntas.length; i++) {
            if (pesquisa.perguntas[i].multiresposta == true) {
                var quantidadeDeRespostas = pesquisa.perguntas[i].respostaFinal.split(";");
                for (j = 0; j < quantidadeDeRespostas.length; j++) {
                    var questao = [];
                    questao.pergunta = pesquisa.perguntas[i].titulo;
                    questao.resposta = quantidadeDeRespostas[j];
                    questao.iddapergunta = pesquisa.perguntas[i].id;
                    resultadoDaPesquisa.push(questao);
                }
            } else {
                var questao = [];
                questao.pergunta = pesquisa.perguntas[i].titulo;
                questao.resposta = pesquisa.perguntas[i].respostaFinal;
                questao.iddapergunta = pesquisa.perguntas[i].id;
                resultadoDaPesquisa.push(questao);
            }
        }
        return resultadoDaPesquisa;
    },

    CriarItemdaPesquisa: function(pergunta, idDaPergunta, resposta, pesquisaId) {
        var itemDaPesquisa = {};
        var texto = pergunta + " | " + resposta;
        itemDaPesquisa.bso_name = texto.length > 250 ? texto.substr(0, 248) : pergunta + " | " + resposta;
        itemDaPesquisa.bso_pergunta = pergunta.length > 400 ? pergunta.substr(0, 398) : pergunta;
        itemDaPesquisa.bso_resposta = resposta.lenght > 2000 ? resposta.substr(0, 1998) : resposta;
        itemDaPesquisa.bso_iddapergunta = idDaPergunta;
        itemDaPesquisa["bso_PesquisaId@odata.bind"] = "/bso_pesquisas(" + pesquisaId + ")";

        return Util.Inserir("bso_itemdapesquisas", itemDaPesquisa);
    },

    CriarItensDaPesquisa: function(pesquisa) {
        var itensDaPesquisaCriados = 0;
        //try
        //{
        pesquisaId = window.parent.Xrm.Page.data.entity.getId().toString().substring(1, 37);
        for (i = 0; i < pesquisa.length; i++) {

            if (!Business.CriarItemdaPesquisa(pesquisa[i].pergunta, pesquisa[i].iddapergunta, pesquisa[i].resposta, pesquisaId))
                return false;
            itensDaPesquisaCriados++;
        }
        return true;
        //}
        //catch (err)
        //{
        //    alert("Erro na criação dos itens da pesquisa. " + err.message + ". Foram criados " + itensDaPesquisaCriados + " de " + pesquisa.length + ".");
        //    return false;
        //}
    },

    PesquisaVencida: function() {
        var statecode = Xrm.Page.getAttribute("statecode").getValue();
        if (statecode != 0) {
            return true;
        } else {
            return false;
        }
    },

    SetarCampo: function(campo, booleana) {
        window.parent.Xrm.Page.getAttribute(campo).setValue(booleana);
    },

    SalvarAlteracoesNoCrm: function() {
        window.parent.Xrm.Page.data.entity.save();
    },
    RetornarValorDoCampo: function(nomeDocampo) {
        return window.parent.Xrm.Page.getAttribute(nomeDocampo).getValue();
    }
}

var View = {
    Pesquisa: Business.CriarObjetoSimplificado(Business.ObterPerguntasComTiposDeRespostas()),

    //_______________________________________________
    VariaveisGlobais: {
        utilizada: false,
        naoAcessada: 100000000,
        naoRespondida: 100000001,
        parcialmente: 100000002,
        concluida: 100000003,
        campo: "bso_acesso_pesquisa",
        usuario: Xrm.Page.context.getUserName(),
        ownerid: Xrm.Page.getAttribute("ownerid").getValue()[0].name
    },

    PesquisaIniciada: function (perguntaid) {
        if (this.VariaveisGlobais.utilizada == false && this.VariaveisGlobais.usuario == this.VariaveisGlobais.ownerid ) {
            Xrm.Page.getAttribute(this.VariaveisGlobais.campo).setValue(this.VariaveisGlobais.parcialmente);
            this.VariaveisGlobais.utilizada = true;
        }
    },

    PesquisaFinalizada: function () {
        if (this.VariaveisGlobais.usuario == this.VariaveisGlobais.ownerid) {
            Xrm.Page.getAttribute(this.VariaveisGlobais.campo).setValue(this.VariaveisGlobais.concluida); 
        }
        
    },
    //_________________________________________________________

    CriarPergunta: function(lista, append) {
        var tamanhoDaLista = lista.perguntas.length;
        lista.perguntas.sort(function(a, b) { return a.id - b.id });
        var i = 0;
        while (i < tamanhoDaLista) {
            switch (lista.perguntas[i].tipoDaResposta) {
                case 861500000:
                    if (lista.perguntas[i].multiresposta) {
                        View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.MultiplaEscolha(lista.perguntas[i].respostas, "inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima  : ""), append, lista.perguntas[i].id);
                    } else {
                        View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.OpcaoUnica(lista.perguntas[i].respostas, "inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima : ""), append, lista.perguntas[i].id);
                    }
                    break;

                case 861500001:
                    View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.Texto("inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima[0] : ""), append, lista.perguntas[i].id);
                    break;

                case 861500002:
                    View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.Data("inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima[0] : ""), append, lista.perguntas[i].id);
                    break;

                case 861500003:
                    View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.DataComHora("inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima[0] : ""), append, lista.perguntas[i].id);
                    break;

                case 861500004:
                    View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.Inteiro("inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima[0] : ""), append, lista.perguntas[i].id);
                    break;

                case 861500005:
                    View.CriarCampoDaPergunta.Pergunta(lista.perguntas[i].titulo, View.CriarCampoDaResposta.Decimal("inputName" + lista.perguntas[i].id, lista.perguntas[i].hasOwnProperty('idproxima') ? lista.perguntas[i].idproxima[0] : ""), append, lista.perguntas[i].id);
                    break;
            }
            i++;
        }
    },

    ChecarRespostaValida: function() {
        var respostaValida = false;
        $('.visivel').find("div").each(function() {
            switch ($(this)[0].className) {
                case "radio":
                    if ($(this).find('input:radio:checked').length == 0) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                case "checkbox":
                    if ($(this).find('input:checkbox:checked').length == 0) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                case "text":
                    if ($(this).find('input:text').val().length == 0) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                case "data":
                    if ($(this).find('input:text').val().length != 10) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                case "dataComHora":
                    if ($(this).find('input:text').val().length != 16) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                case "inteiro":
                    if ($(this).find('input:text').val().length == 0) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                case "decimal":
                    if ($(this).find('input:text').val().length == 0) {
                        respostaValida = false;
                        View.ScrollParaPerguntaMalPreenchida($(this));
                        return respostaValida;
                    } else {
                        respostaValida = true;
                    }
                    break;
                default:
                    break;
            }
        });
        return respostaValida;
    },

    TornarVisivel: function(identificador) {
        $(identificador).removeClass('invisivel').addClass('visivel');
    },

    TornarInvisivel: function(identificador) {
        $(identificador).removeClass('visivel').addClass('invisivel');
    },

    RetornarRespostaDaPergunta: function(identificador) {
        var resposta = "";
        var pergunta = $(identificador);
        if (pergunta.find("input").length > 1) {
            for (i = 0; i < pergunta.find("input:checked").length; i++) {
                resposta += pergunta.find("input:checked")[i].value + function() { return (pergunta.find("input:checked").length - i) > 1 ? " ;" : ""; }();
            }
        } else {
            resposta = pergunta.find("input").val();
        }
        return resposta;
    },

    CriarCampoDaResposta: {
        MultiplaEscolha: function(listaDeOpcoes, inputName, proximaPergunta) {
            var div = $("<div class='checkbox'></div>");
            listaDeOpcoes.sort(function(a, b) { return a.id - b.id });
            for (i = 0; i < listaDeOpcoes.length; i++) {
                var opcao = View.CriarCampoDaResposta.CriarInputCheckbox(inputName, listaDeOpcoes[i].titulo, listaDeOpcoes[i].id, proximaPergunta.length == 1 ? proximaPergunta[0]: proximaPergunta[i]);
                div.append(opcao);
            }
            return div;
        },

        OpcaoUnica: function (listaDeOpcoes, inputName, proximaPergunta) {
            var div = $("<div class='radio'></div>");
            listaDeOpcoes.sort(function(a, b) { return a.id - b.id });
            for (i = 0; i < listaDeOpcoes.length; i++) {
                var opcao = View.CriarCampoDaResposta.CriarInputRadio(inputName, listaDeOpcoes[i].titulo, listaDeOpcoes[i].id, proximaPergunta.length == 1 ? proximaPergunta[0] : proximaPergunta[i]);
                div.append(opcao);
            }
            return div;
        },

        Texto: function(inputName, proximaPergunta) {
            var div = $("<div class='text'></div>");
            var campoTexto = $("<div><input type='text' name=" + inputName + " placeholder='Digite seu texto aqui' size='100%' onchange='View.DeixarApenasPerguntaUmVisivel($(this));' data-proximaPergunta='" + proximaPergunta + "'  ></div>");
            return div.append(campoTexto);
        },

        DataComHora: function(inputName, proximaPergunta) {
            var div = $("<div class='dataComHora'></div>");
            var campoTexto = $("<input type='text' name=" + inputName + " placeholder='00/00/0000 00:00' onchange='View.DeixarApenasPerguntaUmVisivel($(this))' data-proximaPergunta='" + proximaPergunta + "'  >").mask("00/00/0000 00:00");
            var d = $("<div></div>");
            d.append(campoTexto);
            return div.append(d);
        },

        Data: function(inputName, proximaPergunta) {
            var div = $("<div class='data'></div>");
            var campoTexto = $("<input type='text' name=" + inputName + " placeholder='00/00/0000' onchange='View.DeixarApenasPerguntaUmVisivel($(this))' data-proximaPergunta='" + proximaPergunta + "'  >").mask("00/00/0000");
            var d = $("<div></div>");
            d.append(campoTexto);
            return div.append(d);
        },

        Inteiro: function(inputName, proximaPergunta) {
            var div = $("<div class='inteiro'></div>");
            var campoTexto = $("<input type='text' name=" + inputName + " placeholder='Somente números inteiros' onchange='View.DeixarApenasPerguntaUmVisivel($(this))' data-proximaPergunta='" + proximaPergunta + "'  >").mask("#");
            var d = $("<div></div>");
            d.append(campoTexto);
            return div.append(d);
        },

        Decimal: function(inputName, proximaPergunta) {
            var div = $("<div class='decimal'></div>");
            var campoTexto = $("<input type='text' name=" + inputName + " placeholder='Digite apenas números' onchange='View.DeixarApenasPerguntaUmVisivel($(this))' data-proximaPergunta='" + proximaPergunta + "'  >").mask("#.##0,00", { reverse: true });
            var d = $("<div></div>");
            d.append(campoTexto);
            return div.append(d);
        },

        CriarInputRadio: function(inputName, inputValor, inputId, proximaPergunta) {
            var inputRadio = $("<div><input type='radio' name=" + inputName + " value='" + inputValor + "' onchange='View.DeixarApenasPerguntaUmVisivel($(this))' data-id='" + inputId + "' data-proximaPergunta='" + proximaPergunta + "'  ><h5 class='opcoes' >" + inputValor + "</h5></div>");
            return inputRadio;
        },

        CriarInputCheckbox: function(inputName, inputValor, inputId, proximaPergunta) {
            var inputCheckbox = $("<div><input type='checkbox' name=" + inputName + " value='" + inputValor + "' onchange='View.DeixarApenasPerguntaUmVisivel($(this))' data-id='" + inputId + "' data-proximaPergunta='" + proximaPergunta + "'  ><h5 class='opcoes' >" + inputValor + "</h5></div>");
            return inputCheckbox;
        }
    },

    CriarCampoDaPergunta: {
        Pergunta: function(pergunta, resposta, append, id) {
            var div = $("<div>", { id: id, class: "pergunta invisivel" });
            var pergunta = $("<h4></h4>").text(pergunta);
            $(append).append(div.append(pergunta, resposta));
        }
    },

    IniciarPesquisa: function(divIdentificador, perguntaIdentificador) {
        View.DadosDaPesquisa()
        if (!Business.PesquisaVencida()) {
        View.CriarPergunta(View.Pesquisa, divIdentificador);
        View.TornarVisivel(perguntaIdentificador);
        }
        else {
            View.TornarVisivel(".fimDaPesquisa");
            View.TornarInvisivel(".botaoFinalizarPesquisa");
            Business.SalvarAlteracoesNoCrm();
        }
    },

    FinalizarPesquisa: function (pesquisa) {
        //____________________________________________
        View.PesquisaFinalizada();
        //____________________________________________    
        if (View.ChecarRespostaValida()) {
            View.LimparRespostasDePerguntasInvisivel();
            View.PegarResultadoDaPesquisa();
            if (Business.CriarItensDaPesquisa(Business.ResultadoDaPesquisa(pesquisa))) {
                Business.SetarCampo("bso_pesquisarespondida", true);
                Business.SalvarAlteracoesNoCrm();
                View.TornarVisivel(".fimDaPesquisa");
                View.TornarInvisivel("#botaoFinalizarPesquisa");
                View.TornarInvisivel(".pergunta");
            }
        }
    },

    RetornarPerguntaPeloId: function(id) {
        //return View.Pesquisa.perguntas.find(pergunta => pergunta.id == id) // incompativel com internet explorer
        return ($.grep(View.Pesquisa.perguntas, function (pergunta) { return pergunta.id == id }))[0];
    },

    LimparRespostasDePerguntasInvisivel: function () {
        var inputs = $(".pergunta.invisivel").find("input");
        for (let i = 0; i < inputs.length; i++) {
            if (inputs[i].type == "checkbox" || inputs[i].type == "radio") {
                inputs[i].checked = false;
            } else {
                inputs[i].value = "";
            }
        }
    },

    LimparRespostaDaPergunta: function (perguntaId) {
        var inputs = $("#" + perguntaId).find("input");
        for (let i = 0; i < inputs.length; i++) {
            if (inputs[i].type == "checkbox" || inputs[i].type == "radio") {
                inputs[i].checked = false;
            } else {
                inputs[i].value = "";
            }
        }
    },

    PerguntaAtual: 0,
    
    DeixarApenasPerguntaUmVisivel: function (input) {
        View.LimparRespostasDePerguntasInvisivel();
        View.PerguntaAtual = parseInt(input.parent().parent().parent().attr('id'));
        var perguntas = $(".pergunta.visivel");
        for (var i = 0; i < perguntas.length; i++) {
            View.TornarInvisivel("#" + perguntas[i].id);
        }
        View.TornarInvisivel("#botaoFinalizarPesquisa");
        View.TornarPerguntaVisivel(1);
    },
    TornarPerguntaVisivel: function (perguntaId) {
        //____________________________________________
        View.PesquisaIniciada(perguntaId);
         //____________________________________________
        if (perguntaId < View.PerguntaAtual) {
            View.TornarVisivel("#" + perguntaId);
            if (!View.RetornarPerguntaPeloId(perguntaId).ultimapergunta) {
                var tipoDeInput = $("#" + perguntaId).find("input")[0].type;
                if (tipoDeInput == "radio" || tipoDeInput == "checkbox") {
                    var inputs = $("#" + perguntaId).find("input:checked");
                    if (inputs.length > 0) {
                        for (var i = 0; i < inputs.length; i++) {
                            if (inputs[i].dataset.proximapergunta <= View.PerguntaAtual) {
                                View.TornarPerguntaVisivel(inputs[i].dataset.proximapergunta);
                            } else {
                                View.LimparRespostaDaPergunta(inputs[i].dataset.proximapergunta);
                                View.TornarVisivel("#"+inputs[i].dataset.proximapergunta);
                            }
                        }
                    }
                } else {
                    if ($("#" + perguntaId).find('input').val() != "") {
                        View.TornarPerguntaVisivel($("#" + perguntaId).find('input')[0].dataset.proximapergunta);
                    }
                }
            } else {
                View.TornarVisivel("#botaoFinalizarPesquisa");
                $("#" + perguntaId).addClass("ultimapergunta");
            }
        } else if (perguntaId == View.PerguntaAtual){
            View.TornarVisivel("#" + perguntaId);
            if (!View.RetornarPerguntaPeloId(perguntaId).ultimapergunta) {
                var tipoDeInput = $("#" + perguntaId).find("input")[0].type;
                if (tipoDeInput == "radio" || tipoDeInput == "checkbox") {
                    var inputs = $("#" + perguntaId).find("input:checked");
                    if (inputs.length > 0) {
                        for (var i = 0; i < inputs.length; i++) {
                            View.LimparRespostaDaPergunta(inputs[i].dataset.proximapergunta);
                            View.TornarVisivel("#" + inputs[i].dataset.proximapergunta);
                        }
                    }
                } else {
                    if ($("#" + perguntaId).find('input').val() != "") {
                        View.LimparRespostaDaPergunta($("#" + perguntaId).find('input')[0].dataset.proximapergunta);
                        View.TornarVisivel("#" + $("#" + perguntaId).find('input')[0].dataset.proximapergunta);
                    }
                }
            } else {
                View.TornarVisivel("#botaoFinalizarPesquisa");
                $("#" + perguntaId).addClass("ultimapergunta");
            }
        }
    },

    ScrollParaPerguntaMalPreenchida: function(objeto) {
        alert("Favor responder a pergunta corretamente");
        objeto.find("input").focus();
    },

    PegarResultadoDaPesquisa: function() {
        var questoes = $(".questao .visivel");
        for (let i = 0; i < questoes.length; i++) {
            var pergunta = View.RetornarPerguntaPeloId(questoes[i].id);
            pergunta.respostaFinal = View.RetornarRespostaDaPergunta('#' + questoes[i].id);
        }
    },

    DadosDaPesquisa: function () {
        //obter id do modelo de pesquisa
        var consultaCampanha = Util.Consultar(URLWebAPI, "campaigns?$select=_bso_modelodepesquisaid_value, typecode&$filter=campaignid eq " + Util.ObterIdDoCampoLookup("bso_campanhaid"))
        //obter dados necesssarios do modelo de pesquisa
        if (consultaCampanha[0].typecode == 861500000) {
            this.TornarVisivel(".branco")
            this.TornarVisivel(".descricao")
            //this.TornarVisivel(".contato")
            var modeloDePesquisa = Util.Consultar(URLWebAPI, "bso_modelodepesquisas?$select=bso_canal,%20bso_name&$filter=bso_modelodepesquisaid%20eq%20" + consultaCampanha[0]._bso_modelodepesquisaid_value)
            $(".descricao").find("p").text("Retorno dos Corretores do Canal " + modeloDePesquisa[0]["bso_canal@OData.Community.Display.V1.FormattedValue"] + " - " + modeloDePesquisa[0]['bso_name'])
            var itemid = Util.ObterIdDoCampoLookup("bso_itemdofeedbackid");
            debugger;
            if (itemid.length > 0) {
                var contato = Util.Consultar(URLWebAPI, "bso_itemdofeedbacks?$select=bso_contatodacorretora&$filter=bso_itemdofeedbackid  eq " + itemid)
                if (contato[0].bso_contatodacorretora != null) {
                    $(".contato").find("p").text(contato[0].bso_contatodacorretora)
                }
            }
        }
        
    }
}
