﻿
if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_desqualify_leads) === "undefined") { bradescoseguros.corp_desqualify_leads = {}; }



bradescoseguros.corp_desqualify_leads = {

    click_desqualify: function () {
        debugger;
        var text = document.getElementById("text_area");

        Xrm.Page.getAttribute("description").setValue(text);
    }

};
