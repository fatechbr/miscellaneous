﻿
if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_xmlhttprequest) === "undefined") { bradescoseguros.corp_xmlhttprequest = {}; }



bradescoseguros.corp_xmlhttprequest = {

    getasync: async function (entity, option) {

        var response = await bradescoseguros.corp_xmlhttprequest.get(entity, option, true);

        return response;
    },

    getsync: function (entity, option) {

        var response = bradescoseguros.corp_xmlhttprequest.get(entity, option, false);

        return response;
    },

    get: function (entity, option, isAsync) {

        var versao = "v8.2"
        var oDataSelect = Xrm.Page.context.getClientUrl() + "/api/data/" + versao + "/" + entity;

        if (option !== null && option !== "")
            oDataSelect += "?$" + option;

        if (isAsync) {
            return new Promise(function (resolve, reject) {
                let xhr = new XMLHttpRequest();
                xhr.open("GET", oDataSelect);
                xhr.onload = function () {
                    if (this.status >= 200 && this.status < 300) {
                        resolve(xhr.response);
                    } else {
                        reject({
                            status: this.status,
                            statusText: xhr.statusText
                        });
                    }
                };
                xhr.onerror = function () {
                    reject({
                        status: this.status,
                        statusText: xhr.statusText
                    });
                };
                xhr.send();
            });
        }
        else {
            var data = null;

            var xhr = new XMLHttpRequest();
            xhr.open("GET", oDataSelect, false);

            xhr.onreadystatechange = function () {
                if (this.readyState === 4) {
                    xhr.onreadystatechange = null;
                    if (this.status === 200) {
                        data = this.response;

                    } else {

                    }
                }
            };
            xhr.send();

            return data;
        }
    }

};