﻿function displayIconTooltip(rowData, userLCID) {
    debugger
    var str = JSON.parse(rowData);
    var col_data = str.name;
    var imgName = "";
    var tooltip = "{" + col_data + "}";
    
        let reg = new RegExp(/(bso_farol+)":"(\w+)"/g);
        var arr = rowData.match(reg);
        if (arr.length > 0) {
            var cor = arr[0].replace('bso_farol":"', '').replace('"', '');
            switch (cor) {
                case "Vermelho":
                    imgName = "bso_\\icon\\redArrow.gif";
                    tooltip = "Oportunidade fraca...";
                    break;
                case "Azul":
                    imgName = "bso_\\icon\\blueArrow.gif";
                    tooltip = "Oportunidade média.";
                    break;
                case "Verde":
                    imgName = "bso_\\icon\\greenArrow.gif";
                    tooltip = "Oportunidade forte!";
                    break;
            }
            var resultArray = [imgName, tooltip];

            return resultArray;
    }
    
}