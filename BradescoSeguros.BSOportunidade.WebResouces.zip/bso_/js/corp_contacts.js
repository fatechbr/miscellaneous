﻿/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />

var entity = "contacts";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_contacts) === "undefined") { bradescoseguros.corp_contacts = {}; }



bradescoseguros.corp_contacts = {
    onload: function () {

        bradescoseguros.corp_common.cpf.mask_cpf();

        //add on change
        Xrm.Page.getAttribute("bso_cpf").addOnChange(bradescoseguros.corp_contacts.checkdocument);
        Xrm.Page.getAttribute("bso_cpf").addOnChange(bradescoseguros.corp_common.cpf.mask_cpf);

    },

    onsave: function (context) {

        var eventArgs = context.getEventArgs()
        var isSave = bradescoseguros.corp_contacts.prevent_save(eventArgs);

    },

    prevent_save: function (eventArgs) {

        var isSave = true;

        //deactivate
        if (eventArgs.getSaveMode() == 5) {
            var id = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
            var opp = bradescoseguros.corp_opportunities.getbycontact(id, false);

            if (opp !== null) {
                bradescoseguros.corp_common.message.alertasync("M_A_1000007");
                eventArgs.preventDefault();
                isSave = false;
            }
        }

        if (eventArgs.getSaveMode() == 6) {

            return true;
        }


        if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 1) {
            isSave = bradescoseguros.corp_contacts.validatefields();
        }



        if (!isSave)
            eventArgs.preventDefault();


        return isSave;
    },

    validatefields() {
        if (Xrm.Page.getAttribute("bso_corretoraid").getValue() === null && Xrm.Page.getAttribute("parentcustomerid").getValue() === null) {
            Alert.show("Campos obrigatórios", "Obrigatório preencher o campo 'Corretora' e ou 'Empresa'", null, "ERROR", 500, 250);
            Xrm.Page.getControl("bso_corretoraid").setFocus();
            return false;
        }

        return true;
    },

    /// * Verifica o campo CPF
    /// ** Caso o CPF exista na base do CRM
    checkdocument: async function () {

        var cpf = Xrm.Page.getAttribute("bso_cpf").getValue();

        if (cpf == "" || cpf == null)
            return true;

        if (!bradescoseguros.corp_common.cpf.validation_cpf(cpf)) {
            var message = await bradescoseguros.corp_common.message.get("M_A_1000000"); //Documento inválido
            Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, 500, 250);
            Xrm.Page.getAttribute("bso_cpf").setValue(null);
            return false;
        }

        var contactid = await bradescoseguros.corp_contacts.get_cpf(cpf);

        if (contactid !== null) {
            var id = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
            debugger;
            if (contactid.contactid !== id) {
                Xrm.Page.getAttribute("bso_cpf").setValue(null);
                window.open(Xrm.Page.context.getClientUrl() + "/main.aspx?etc=2&id=%7b" + contactid.contactid + "%7d&pagetype=entityrecord");
                return false;
            }
        }

        return true;
    },

    get_cpf: async function (cpf) {

        cpf = cpf.replace(/[^\d]+/g, '');

        var select = "select=";
        var selectparam = "contactid,fullname,bso_cpf";

        select += selectparam;

        var filter = "filter="
        var filterparam = "bso_cpf eq '" + cpf + "'";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = await bradescoseguros.corp_xmlhttprequest.get("contacts", option);

        var json = JSON.parse(response);

        if (json.value.length > 0)
            return json.value[0];
        else
            return null;
    }
};