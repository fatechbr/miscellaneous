/// <reference path="_corp_common.js" />
/// <reference path="_corp_xmlhttprequest.js" />
/// <reference path="base/helpers.js" />

var entity = "leads";
var istimedisqualify = true;

if (typeof (bradescoseguros) === "undefined") {
    bradescoseguros = {};
}

if (typeof (bradescoseguros.corp_leads) === "undefined") {
    bradescoseguros.corp_leads = {};
}

bradescoseguros.corp_leads = {
    onload: function (event) {
        //debugger;
        context = event.getFormContext();

        setTimeout(bradescoseguros.corp_leads.collapseBusinessProcess, 300);

        bradescoseguros.corp_leads.setVidasZero();
        bradescoseguros.corp_leads.ShowHideFieldsBasedOnProduct();
        var cnpjmask = Xrm.Page.getAttribute("bso_cnpjmask").getValue();
        bradescoseguros.corp_leads.set_onchangefield();
        bradescoseguros.corp_leads.configurarConjuntoFamiliadeProduto();
        bradescoseguros.corp_leads.PreencherDatasAoConverterEmail();
        Xrm.Page.getAttribute("bso_cnpjmask").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);
        Xrm.Page.getAttribute("bso_gerente_comercial").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);
        Xrm.Page.getAttribute("bso_sucursal").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);
        Xrm.Page.getAttribute("bso_corretora").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);
        Xrm.Page.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);
        Xrm.Page.getAttribute("bso_famliadeprodutos").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);
        Xrm.Page.getAttribute("bso_subproduto").addOnChange(bradescoseguros.corp_leads.VerificarCamposObrigatorios);

        if (cnpjmask != null && cnpjmask.length === 14) {
            bradescoseguros.corp_common.cnpj.mask_cnpj("bso_cnpjmask");
        } else if (cnpjmask != null && cnpjmask.length === 12) {
            bradescoseguros.corp_common.cnpj.mask_cei("bso_cnpjmask");
        }
    },

    collapseBusinessProcess: function () {
        if (Xrm.Page.ui.process != null)
            Xrm.Page.ui.process.setDisplayState("collapsed");
    },

    onsave: function (event) {
        //debugger;

        var savemode = event.getEventArgs().getSaveMode();
        context = event.getFormContext();
        bradescoseguros.corp_leads.prevent_disqualify(savemode);
        //bradescoseguros.corp_leads.preventSave();
    },

    prevent_disqualify: async function (savemode) {

        //disqualify
        if (savemode == 15) {
            var btn = [
                new Alert.Button("Desqualificar", bradescoseguros.corp_leads.btn_desqulify, true, false),
                new Alert.Button("Cancelar", bradescoseguros.corp_leads.btn_cancel, true, false)
            ]

            var x = Alert.showWebResource("bso_/html/corp_desqualify_leads.html", 740, 390, "Informe o Motivo:", btn, Xrm.Page.context.getClientUrl(), true, 30)
        }
    },

    setVidasZero: function () {
        if (Xrm.Page.getAttribute("bso_vidasitens").getValue() == null) {
            Xrm.Page.getAttribute("bso_vidasitens").setValue(0);
        }
    },

    btn_desqulify: function () {
        //debugger;

        var iFrameWindow = Alert.getIFrameWindow();
        var textarea = iFrameWindow.document.getElementById("text_area");

        if (textarea.value === null || textarea.value === "") {
            Xrm.Page.getAttribute("bso_motivo").setValue("#reativar");
            bradescoseguros.corp_common.message.alertasync("M_A_1000005");
            Xrm.Page.data.entity.save();
        } else {
            Xrm.Page.getAttribute("bso_motivo").setValue(textarea.value);
            Xrm.Page.data.entity.save();
        }

    },

    btn_cancel: function () {
        //debugger;
        Xrm.Page.getAttribute("bso_motivo").setValue("#reativar");
        Xrm.Page.data.entity.save();
    },

    set_onchangefield: function () {
        //debugger;
        Xrm.Page.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_leads.configurarConjuntoFamiliadeProduto);
        Xrm.Page.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_leads.ShowHideFieldsBasedOnProduct);
        Xrm.Page.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("bso_cnpjmask").addOnChange(bradescoseguros.corp_leads.onchangecnpjmask);
        Xrm.Page.getAttribute("bso_acaocomercial").addOnChange(bradescoseguros.corp_leads.showComercialAction);
        Xrm.Page.getAttribute("bso_corretora").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("parentaccountid").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("bso_gerente_comercial").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("bso_famliadeprodutos").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("bso_subproduto").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("bso_vidasitens").addOnChange(bradescoseguros.corp_leads.preventQualify);
        Xrm.Page.getAttribute("companyname").addOnChange(bradescoseguros.corp_leads.preventSave);
        Xrm.Page.getAttribute("parentaccountid").addOnChange(bradescoseguros.corp_leads.preventSave);
    },

    onchangecnpjmask: function () {
        var cnpj = Xrm.Page.getAttribute("bso_cnpj").getValue();
        var cnpjmask = Xrm.Page.getAttribute("bso_cnpjmask").getValue();

        if (cnpjmask != null && cnpjmask.length === 12) {

            if (cnpj !== null)
                cnpj = cnpj.replace(/[^\d]+/g, '');

            if (cnpjmask !== null)
                cnpjmask = cnpjmask.replace(/[^\d]+/g, '');

            if (cnpj === cnpjmask)
                return;

            Xrm.Page.getAttribute("bso_cnpj").setValue(cnpjmask);

            bradescoseguros.corp_common.cnpj.mask_cei("bso_cnpjmask");
            bradescoseguros.corp_leads.onchangecnpj();

        } else {
            if (cnpjmask != null && cnpjmask.length === 14) {

                if (cnpj !== null)
                    cnpj = cnpj.replace(/[^\d]+/g, '');

                if (cnpjmask !== null)
                    cnpjmask = cnpjmask.replace(/[^\d]+/g, '');

                if (cnpj === cnpjmask)
                    return;

                if (!bradescoseguros.corp_common.cnpj.validation_cnpj(cnpjmask)) {
                    bradescoseguros.corp_leads.cnpjinvalid();
                    return;
                }

                Xrm.Page.getAttribute("bso_cnpj").setValue(cnpjmask);
                bradescoseguros.corp_leads.onchangecnpj();

                bradescoseguros.corp_common.cnpj.mask_cnpj("bso_cnpjmask");
            } else {
                if (cnpjmask != null && cnpjmask.length === 18) {

                    if (!bradescoseguros.corp_common.cnpj.validation_cnpj(cnpjmask)) {
                        bradescoseguros.corp_leads.cnpjinvalid();
                        return;
                    }

                    Xrm.Page.getAttribute("bso_cnpj").setValue(cnpjmask);
                    bradescoseguros.corp_leads.onchangecnpj();

                } else {
                    bradescoseguros.corp_leads.cnpjinvalid();
                }
            }
        }
    },

    removeOptions: (options) => {
        let pickList = Xrm.Page.getControl("bso_famliadeprodutos")
        options.forEach(element => { pickList.removeOption(element) })
    },

    addOptions: (options) => {
        let pickList = Xrm.Page.getControl("bso_famliadeprodutos")
        options.forEach(element => { pickList.addOption(element) })
    },

    addOptionsSubProduto: (options) => {
        let pickList = Xrm.Page.getControl("bso_subproduto")
        options.forEach(element => { pickList.addOption(element) })
    },

    removeOptionsSubProduto: (options) => {
        let pickList = Xrm.Page.getControl("bso_subproduto")
        options.forEach(element => { pickList.removeOption(element) })
    },

    configurarConjuntoFamiliadeProduto: function () {
        //debugger;

        var optionSubProduto = [100000000, 100000001, 100000002, 100000003, 100000004, 100000005];

        var options1 = [100000000, 100000001, 100000002, 100000003, 100000004, 100000005, 100000006, 100000007, 100000008, 100000009, 100000010, 100000011, 100000012,
            100000013, 100000014, 100000015, 100000016, 100000017, 100000018, 100000019, 100000020, 100000021, 100000022, 100000023, 100000024, 100000025, 100000026, 100000027,
            100000028, 100000029, 100000030, 861500000, 861500001, 861500003, 861500004, 861500005, 861500008, 861500009, 861500010, 861500011];

        var produtopr = Xrm.Page.getAttribute("bso_produto").getValue();

        switch (produtopr) {
            //auto
            case 861500000:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");

                let addAuto = [{ value: 861500000, text: "Auto" }, { value: 100000010, text: "Frota" }, { value: 100000011, text: "Individual" }];
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addAuto);

                bradescoseguros.corp_leads.removeOptionsSubProduto(optionSubProduto);
                Xrm.Page.getControl("bso_subproduto").setVisible(false);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_subproduto").setValue(null);

                break;

            //dental
            case 861500001:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");
                let addDental = [{ value: 861500001, text: "Dental - Empresarial" }, { value: 100000001, text: "Dental - SPG" }];
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addDental);

                Xrm.Page.getControl("bso_subproduto").setVisible(true);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("required");

                let addSubDental = [{ value: 100000002, text: "Clinic" }, { value: 100000005, text: "Premium" }];
                bradescoseguros.corp_leads.removeOptionsSubProduto(optionSubProduto);
                bradescoseguros.corp_leads.addOptionsSubProduto(addSubDental);

                break;

            //saude
            case 861500005:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");
                let addSaude = [{ value: 861500009, text: "Saúde - Empresarial" }, { value: 100000000, text: "Saúde - SPG" }];
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addSaude);

                Xrm.Page.getControl("bso_subproduto").setVisible(true);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("required");
                let addSubSaude = [{ value: 100000000, text: "Top" }, { value: 100000001, text: "Hospitalar" }];
                bradescoseguros.corp_leads.removeOptionsSubProduto(optionSubProduto);
                bradescoseguros.corp_leads.addOptionsSubProduto(addSubSaude);

                break;

            //vida
            case 861500004:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");
                let addVida = [{ value: 100000017, text: "Grupo - Apólice específica" }, { value: 100000005, text: "Capital Escalonado" }, { value: 100000003, text: "Capital Global" }, { value: 100000004, text: "Capital Salarial" }, { value: 100000002, text: "Capital Uniforme" }, { value: 100000007, text: "Educacional" }, { value: 100000006, text: "Prestamista" }];
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addVida);

                Xrm.Page.getControl("bso_subproduto").setVisible(false);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_subproduto").setValue(null);

                bradescoseguros.corp_leads.removeOptionsSubProduto(optionSubProduto);
                break;

            //previdencia
            case 861500002:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");
                let addPrev = [{ value: 100000008, text: "Aberta" }, { value: 100000009, text: "Multipatrocinado" }];
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addPrev);

                Xrm.Page.getControl("bso_subproduto").setVisible(false);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_subproduto").setValue(null);

                bradescoseguros.corp_leads.removeOptionsSubProduto(optionSubProduto);
                break;

            //RE
            case 861500003:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");

                let addRe = [{ value: 861500003, text: "Equipamento" }, { value: 861500004, text: "Habitacional" }, { value: 861500005, text: "Náutico" },
                { value: 861500008, text: "Riscos Patrimoniais" }, { value: 861500010, text: "Transporte" }, { value: 100000013, text: "Garantia" }, { value: 100000012, text: "Aeronáutico" },
                { value: 100000014, text: "Rural" }, { value: 100000015, text: "D&O" }, { value: 100000016, text: "Risco Civil" }, { value: 100000019, text: "Agro" }, { value: 100000020, text: "Aviation" },
                { value: 100000021, text: "Casualty" }, { value: 100000022, text: "Credit" }, { value: 100000023, text: "Engineering" }, { value: 100000024, text: "FinPro" }, { value: 100000025, text: "Marine Cargo" },
                { value: 100000026, text: "Marine Hull" }, { value: 100000027, text: "Property" }, { value: 100000028, text: "Weather" }, { value: 100000029, text: "Special Lines" }, { value: 100000030, text: "Surety" }];

                Xrm.Page.getControl("bso_subproduto").setVisible(false);
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addRe);

                break;

            //capitalização
            case 861500006:
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("none");
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(false);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setValue(null);
                Xrm.Page.getControl("bso_subproduto").setVisible(false);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_subproduto").setValue(null);
                bradescoseguros.corp_leads.removeOptions(options1);
                break;

            //Saúde/Dental – Conjugado
            case 100000000:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(true);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("required");
                let addSaudeDental = [{ value: 861500009, text: "Saúde - Empresarial" }, { value: 100000000, text: "Saúde - SPG" }];
                bradescoseguros.corp_leads.removeOptions(options1);
                bradescoseguros.corp_leads.addOptions(addSaudeDental);

                Xrm.Page.getControl("bso_subproduto").setVisible(true);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("required");
                let addSubSaudeDental = [{ value: 100000000, text: "Top" }, { value: 100000001, text: "Hospitalar" }];
                bradescoseguros.corp_leads.removeOptionsSubProduto(optionSubProduto);
                bradescoseguros.corp_leads.addOptionsSubProduto(addSubSaudeDental);
                break;

            default:
                Xrm.Page.getControl("bso_famliadeprodutos").setVisible(false);
                Xrm.Page.getAttribute("bso_famliadeprodutos").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_famliadeprodutos").setValue(null);
                Xrm.Page.getControl("bso_subproduto").setVisible(false);
                Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_subproduto").setValue(null);
                bradescoseguros.corp_leads.removeOptions(options1);
                break;
        }
    },

    showComercialAction: function () {

        if (Xrm.Page.getAttribute("bso_acaocomercial").getValue() === true) {
            Xrm.Page.getControl("bso_acao").setVisible(true);
            Xrm.Page.getAttribute("bso_acao").setRequiredLevel("required");
        } else {
            Xrm.Page.getAttribute("bso_acao").setRequiredLevel("none");
            Xrm.Page.getControl("bso_acao").setVisible(false);
        }
    },

    ShowHideFieldsBasedOnProduct: async function () {
        let product = Xrm.Page.getAttribute("bso_produto").getValue();
        let showfields = [];
        let hidefields = [];
        switch (product) {
            //Auto
            case 861500000:
                //showfields = ["bso_valordefatura", "bso_individual_frota", "bso_sinistralidade"];
                hidefields = ["bso_tipodeplano", "bso_premiomensalcongenere", "bso_portabilidade", "bso_modalidade",
                    "bso_ndofluig", "bso_quantidade", "bso_afastados", "bso_taxabradescoseguros", "bso_adesao",
                    "bso_taxadeadm", "bso_reserva", "bso_tipodepagamento", "bso_taxacongenere", "bso_tabua", "bso_juros", "bso_valor_per_capta",
                    "bso_valordefatura", "bso_individual_frota", "bso_sinistralidade"];
                break;

            //Dental
            case 861500001:
                showfields = ["bso_modalidade", "bso_premiomensalcongenere", "bso_valordefatura", "bso_sinistralidade", "bso_adesao"];
                hidefields = ["bso_tipodeplano", "bso_portabilidade", "bso_tipodepagamento", "bso_ndofluig", "bso_quantidade",
                    "bso_afastados", "bso_taxabradescoseguros", "bso_taxadeadm", "bso_reserva",
                    "bso_tipodepagamento", "bso_individual_frota", "bso_tabua", "bso_taxacongenere", "bso_juros", "bso_valor_per_capta"];
                break;

            //Previdência
            case 861500002:
                showfields = ["bso_tipodeplano", "bso_premiomensalcongenere", "bso_valordefatura", "bso_portabilidade",
                    "bso_reserva", "bso_tabua", "bso_juros", "bso_taxadeadm"];
                hidefields = ["bso_tipodepagamento", "bso_modalidade", "bso_ndofluig", "bso_sinistralidade", "bso_quantidade",
                    "bso_afastados", "bso_taxabradescoseguros", "bso_tipodepagamento", "bso_taxacongenere", "bso_valor_per_capta",
                    "bso_individual_frota", "bso_adesao"];
                break;

            //RE
            case 861500003:
                showfields = ["bso_premiomensalcongenere"];
                hidefields = ["bso_modalidade", "bso_tipodepagamento", "bso_tipodeplano", "bso_portabilidade",
                    "bso_sinistralidade", "bso_quantidade", "bso_afastados", "bso_taxabradescoseguros", "bso_taxadeadm", "bso_adesao",
                    "bso_reserva", "bso_tipodepagamento", "bso_ndofluig", "bso_individual_frota", "bso_tabua", "bso_taxacongenere", "bso_valor_per_capta", "bso_juros", "bso_valordefatura"];
                break;

            //Vida
            case 861500004:
                showfields = ["bso_sinistralidade", "bso_quantidade", "bso_afastados", "bso_premiomensalcongenere", "bso_valordefatura",
                    "bso_taxabradescoseguros", "bso_valor_per_capta", "bso_taxacongenere"];
                hidefields = ["bso_tipodeplano", "bso_portabilidade", "bso_tipodepagamento", "bso_modalidade", "bso_ndofluig", "bso_adesao",
                    "bso_taxadeadm", "bso_reserva", "bso_individual_frota", "bso_tabua", "bso_ndofluig", "bso_juros"];
                break;

            //Saúde	
            case 861500005:
                showfields = ["bso_modalidade", "bso_premiomensalcongenere", "bso_valordefatura", "bso_sinistralidade", "bso_adesao"];
                hidefields = ["bso_portabilidade", "bso_tipodepagamento", "bso_tipodeplano", "bso_ndofluig", "bso_quantidade",
                    "bso_afastados", "bso_taxabradescoseguros", "bso_taxadeadm", "bso_reserva", "bso_taxacongenere", "bso_valor_per_capta", "bso_individual_frota",
                    "bso_tabua", "bso_juros"];
                break;

            //Capitalização
            case 861500006:
                showfields = ["bso_tipodepagamento"];
                hidefields = ["bso_premiomensalcongenere", "bso_tipodeplano", "bso_modalidade", "bso_portabilidade",
                    "bso_valordefatura", "bso_ndofluig", "bso_sinistralidade", "bso_quantidade", "bso_afastados",
                    "bso_taxabradescoseguros", "bso_taxadeadm", "bso_reserva", "bso_taxacongenere", "bso_valor_per_capta", "bso_individual_frota",
                    "bso_tabua", "bso_juros", "bso_adesao"];
                Xrm.Page.getAttribute("bso_valordefatura").setRequiredLevel("none");
                break;

            default:
                hidefields = ["bso_sinistralidade", "bso_quantidade", "bso_afastados", "bso_premiomensalcongenere",
                    "bso_taxabradescoseguros", "bso_taxadeadm", "bso_reserva", "bso_tipodepagamento", "bso_individual_frota",
                    "bso_tabua", "bso_ndofluig", "bso_juros", "bso_taxacongenere", "bso_adesao", "bso_valor_per_capta"];
                Xrm.Page.getAttribute("bso_valordefatura").setRequiredLevel("none");
                break;
        }

        bradescoseguros.corp_leads.set_display_properties(showfields, true);
        bradescoseguros.corp_leads.set_display_properties(hidefields, false);
    },

    set_display_properties: async function (fields, property) {
        for (var i = 0; i < fields.length; i++) {
            Xrm.Page.getControl(fields[i]).setVisible(property);
        }
    },

    /// * Verifica o campo CNPJ do cliente potencial
    /// ** Caso o CNPJ exista na base do CRM é vinculuado ao cliente potencial ao cliente PJ
    onchangecnpj: async function () {
        //debugger;
        var cnpj = Xrm.Page.getAttribute("bso_cnpj").getValue();
        Xrm.Page.getAttribute("parentaccountid").setValue(null);

        if (cnpj == "" || cnpj == null) {
            Xrm.Page.getAttribute("companyname").setValue(null);
            Xrm.Page.getAttribute("companyname").setRequiredLevel("none");
            return;
        }

        var accountid = await bradescoseguros.corp_accounts.get_cnpj(cnpj);
        if (accountid !== null) {
            bradescoseguros.corp_common.lookup.set(accountid.accountid, accountid.name, "account", "parentaccountid");
            Xrm.Page.getAttribute("companyname").setValue(null);
            Xrm.Page.getAttribute("companyname").setRequiredLevel("none");
            Xrm.Page.getAttribute("parentaccountid").setRequiredLevel("required");
        } else {
            if (Xrm.Page.getAttribute("statecode").getValue() === 0) {
                var message = await bradescoseguros.corp_common.message.get("M_A_1000001"); //CNPJ não encontrado
                Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, 500, 250);
                Xrm.Page.getAttribute("companyname").setRequiredLevel("required");
                Xrm.Page.getAttribute("parentaccountid").setRequiredLevel("none");
            }
        }
    },

    cnpjinvalid: async function () {
        var message = await bradescoseguros.corp_common.message.get("M_A_1000000"); //CNPJ Inválido        
        Xrm.Page.getControl("bso_cnpjmask").setFocus();
        //Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, 500, 250);
        Alert.show(message.bso_titulodamensagem, message.bso_valor, [
            new Alert.Button("OK", null, true)
        ], message.bso_tipodemensagem, 500, 250);
        Xrm.Page.getAttribute("bso_cnpj").setValue(null);
        Xrm.Page.getAttribute("bso_cnpjmask").setValue(null);
    },

    preventQualify: async function () {
        debugger;
        //Xrm.Page.getAttribute("bso_podequalificar").setValue(true);

        var oportunidade;

        var produto = Xrm.Page.getAttribute("bso_produto").getValue();
        var cliente = Xrm.Page.getAttribute("parentaccountid").getValue();
        var corretora = Xrm.Page.getAttribute("bso_corretora").getValue();

        var fieldOk = bradescoseguros.corp_leads.validateFieldPreventQualify();

        if (fieldOk == "saudeCorretoraCliente" && Xrm.Page.getAttribute("bso_podequalificar").getValue() == true) {

            cliente = Xrm.Page.getAttribute("parentaccountid").getValue()[0].id;
            //corretora = Xrm.Page.getAttribute("bso_corretora").getValue()[0].id;
            cliente = cliente.replace("{", "").replace("}", "");
            //corretora = corretora.replace("{", "").replace("}", "");

            //oportunidade = await bradescoseguros.corp_leads.getOpportunity(produto, cliente, "", "", "", "", "", corretora);
            oportunidade = await bradescoseguros.corp_leads.getOpportunity(produto, cliente, "", "", "", "", "", "");
        }

        if (fieldOk == "true") {

            cliente = Xrm.Page.getAttribute("parentaccountid").getValue()[0].id;
            let gerente = Xrm.Page.getAttribute("bso_gerente_comercial").getValue()[0].id;
            let familiaProdutos = Xrm.Page.getAttribute("bso_famliadeprodutos").getValue();
            let vidasItens = Xrm.Page.getAttribute("bso_vidasitens").getValue();
            let subProduto = Xrm.Page.getAttribute("bso_subproduto").getValue()
            let modalidade = Xrm.Page.getAttribute("bso_modalidade").getValue()
            cliente = cliente.replace("{", "").replace("}", "");
            gerente = gerente.replace("{", "").replace("}", "");

            oportunidade = await bradescoseguros.corp_leads.getOpportunity(produto, cliente, gerente, vidasItens, familiaProdutos, subProduto, modalidade, corretora);
        }

        if (fieldOk == "false") {
            Xrm.Page.getAttribute("bso_podequalificar").setValue(true);
            return;
        }

        if (oportunidade == null && fieldOk == "saudeCorretoraCliente") {
            Xrm.Page.getAttribute("bso_podequalificar").setValue(true);
            return;
        }
        else {
            if (fieldOk != "saudeCorretoraCliente") {
                Xrm.Page.getAttribute("bso_podequalificar").setValue(true);
                return;
            }
        }

        if (oportunidade.value.length == 0 && fieldOk == "saudeCorretoraCliente") {
            Xrm.Page.getAttribute("bso_podequalificar").setValue(true);
            return;
        }
        else {
            if (fieldOk != "saudeCorretoraCliente") {
                Xrm.Page.getAttribute("bso_podequalificar").setValue(true);
                return;
            }
        }

        bradescoseguros.corp_leads.validatePreventQualify(oportunidade, produto);
    },

    validateFieldPreventQualify: function () {
        var produto = Xrm.Page.getAttribute("bso_produto").getValue();
        var corretora = Xrm.Page.getAttribute("bso_corretora").getValue();
        var account = Xrm.Page.getAttribute("parentaccountid").getValue();
        let gerenteComercial = Xrm.Page.getAttribute("bso_gerente_comercial").getValue();
        let vidasItens = Xrm.Page.getAttribute("bso_vidasitens").getValue();

        if (produto == null) {
            return "false";
        }

        if (corretora == null) {
            return "false";
        }

        if (account == null) {
            return "false";
        }

        if (gerenteComercial == null) {
            return "false";
        }

        if (vidasItens == null) {
            return "false";
        }

        //if ((produto == 861500005 || produto == 100000000 || produto == 861500001) && corretora != null && account != null) {
        if ((produto == 861500005 || produto == 100000000 || produto == 861500001) && account != null) {
            return "saudeCorretoraCliente";
        }

        return "true";
    },

    getOpportunity: async function (produto, cliente, gerente, vidasItens, familiaProdutos, subProduto, modalidade, corretora) {
		
		var hoje = new Date();
		var limite = new Date(hoje.setMonth(hoje.getMonth() + -3)).toISOString().split('T')[0];

        if (produto == 861500005 || produto == 100000000 || produto == 861500001) {

            //var response = await bradescoseguros.corp_xmlhttprequest.getasync("opportunities", `select=_bso_corretora_value,bso_produto,_customerid_value&$filter=bso_produto eq ${produto} and _customerid_value eq ${cliente} and _bso_corretora_value eq ${corretora} and statecode eq 0`);
            var response = await bradescoseguros.corp_xmlhttprequest.getasync("opportunities", `select=_bso_corretora_value,modifiedon,bso_produto,_customerid_value&$filter=bso_produto eq ${produto} and _customerid_value eq ${cliente} and statecode eq 0`);
        }
        else {

            if (produto == 100000000) {
                var response = await bradescoseguros.corp_xmlhttprequest.getasync("opportunities", `select=_bso_corretora_value,modifiedon,bso_produto,_customerid_value&$filter=bso_produto eq ${produto} and _customerid_value eq ${cliente} and _bso_gerente_comercial_value eq ${gerente} and bso_numeroitens eq ${vidasItens} and bso_subproduto eq ${subProduto} and bso_familiadeprodutos eq ${familiaProdutos} and bso_modalidade eq ${modalidade} and statecode eq 0`);
            }
            else {
                var response = await bradescoseguros.corp_xmlhttprequest.getasync("opportunities", `select=_bso_corretora_value,modifiedon,bso_produto,_customerid_value&$filter=bso_produto eq ${produto} and _customerid_value eq ${cliente} and _bso_gerente_comercial_value eq ${gerente} and bso_numeroitens eq ${vidasItens} and bso_subproduto eq ${subProduto} and bso_familiadeprodutos eq ${familiaProdutos} and statecode eq 0`);
            }
        }

        if (response != null) {
            var json = JSON.parse(response);
			var controle = false;
			
			var qtd = json.value.length;
			var i;
			for (i = 0; i < json.value.length; i++) {
			  var dataretornada = json.value[i].modifiedon;
			  if(dataretornada > limite){
				  controle = true;
			  }
			}
			
			if(controle){
				return json;
			}
			else{
				return null;
			}

            //return json;
        } else
            return null;
    },

    justTesting: function () {
        let lookupOptions = {
            defaultEntityType: "account",
            entityTypes: ["account"],
            allowMultiSelect: false,
            //customFilterTypes: [""]
        };
        Xrm.Utility.lookupObjects(lookupOptions).then(alert("sucesss")).fail(alert("fail"));
    },

    validatePreventQualify: function (oportunidade, produto) {
        var corretoraClientePotencial = Xrm.Page.getAttribute("bso_corretora").getValue()[0].id.replace("{", "").replace("}", "");
        let validation = 0;

        for (var i = 0; i < oportunidade.value.length; i++) {
            if (oportunidade.value[i]._bso_corretora_value == null)
                continue;
            var corretoraOportunidade = oportunidade.value[i]._bso_corretora_value.replace("{", "").replace("}", "");

            if (corretoraClientePotencial.toUpperCase() == corretoraOportunidade.toUpperCase()) {
                Xrm.Page.getAttribute("statuscode").setValue(1);
                Xrm.Page.getAttribute("bso_podequalificar").setValue(false);
                validation = 1;
                break;
            } else {
                Xrm.Page.getAttribute("statuscode").setValue(100000001);
                Xrm.Page.getAttribute("bso_podequalificar").setValue(false);

                validation = validation == 1 ? 1 : 2;
            }
        }

        if (validation == 1) {
            if (produto == 861500005 || produto == 861500001 || produto == 100000000)
                bradescoseguros.corp_common.message.alertasync("M_A_1000013");
            else
                bradescoseguros.corp_common.message.alertasync("M_A_1000012");
        } else {
            if (produto == 861500005 || produto == 861500001 || produto == 100000000)
                bradescoseguros.corp_common.message.alertasync("M_A_1000013");
            else
                bradescoseguros.corp_common.message.alertasync("M_A_1000012");
        }
    },

    // Início das funções criadas para atendimento da Estória 1 do projeto EFV - Melhorias Área Suporte Comercial

    PreencherDatasAoConverterEmail: function () {
        try {
            var emailRecebidoEm = Xrm.Page.getAttribute("bso_emailrecebidoem").getValue();
            var clientePotencialEm = Xrm.Page.getAttribute("bso_emailrecebidoem").getValue();

            if (emailRecebidoEm === null || emailRecebidoEm === undefined) {
                var email = bradescoseguros.corp_leads.FetchEmail(Xrm.Page.getAttribute("subject").getValue());

                if (email != null && email != undefined) {
                    var dataCriacaoEmail = email[0].attributes.createdon.value;
                    Xrm.Page.getAttribute("bso_emailrecebidoem").setValue(dataCriacaoEmail);
                }
            }

            if (clientePotencialEm === null || clientePotencialEm === undefined) {
                var dataCriacaoLead = Xrm.Page.getAttribute("createdon").getValue();
                Xrm.Page.getAttribute("bso_clientepotencialem").setValue(dataCriacaoLead);
            }
        } catch (e) {
            alert("Ocorreu um erro ao tentar preencher os campos 'Email Recebido em' e 'Cliente Potencial em': " + e);
        }
    },

    FetchEmail: function (subject) {
        var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='email'>" +
            "<attribute name='activityid'/>" +
            "<attribute name='createdon'/>" +
            "<order attribute='createdon' descending='false'/>" +
            "<filter type='and'>" +
            "<condition attribute='subject' operator='eq' value='" + subject + "'/>" +
            "</filter>" +
            "</entity>" +
            "</fetch>";

        var Email = XrmServiceToolkit.Soap.Fetch(fetchXML);

        if (Email != null && Email.length > 0) {
            return Email;
        }
        return null;
    },

    VerificarCamposObrigatorios: function () {
        var preenchido = true;

        Xrm.Page.getAttribute(function (attribute, index) {
            if (attribute.getRequiredLevel() == "required") {
                if (attribute.getValue() === null) {
                    preenchido = false;
                }
            }
        });

        if (preenchido) {
            Xrm.Page.getAttribute("bso_status").setValue(1); // Liberado
            Xrm.Page.getControl("bso_status").setDisabled(true);
            Xrm.Page.getAttribute("bso_trabalhadoem").setValue(new Date());
            Xrm.Page.data.entity.save();
        }
        else {
            Xrm.Page.getAttribute("bso_status").setValue(0); // Bloqueado
            Xrm.Page.getControl("bso_status").setDisabled(false);
            Xrm.Page.getAttribute("bso_trabalhadoem").setValue(null);
            Xrm.Page.data.entity.save();
        }
    }

    // Fim das funções criadas para atendimento da Estória 1 do projeto EFV - Melhorias Área Suporte Comercial
}