﻿/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_quote) === "undefined") { bradescoseguros.corp_quote = {}; }

bradescoseguros.corp_quote = {
    onload: async function (event) {
        debugger;
        context = event.getFormContext();

        if (Xrm.Page.ui.getFormType() != 1) 
            bradescoseguros.corp_quote.validarCotacaoSemMotivoEstudo();

    },

    validarCotacaoSemMotivoEstudo: function () {
        var motivoEstudoReestudo = Xrm.Page.getAttribute("bso_motivodeestudoreestudo").getValue();
        var flagPreencheuMotivo = Xrm.Page.getAttribute("bso_flagpreencheumotivoestudo").getValue();
        var dataCriacao = new Date(Xrm.Page.getAttribute("createdon").getValue());
        var dataBase = new Date(2021, 0, 22);

        if (dataCriacao < dataBase) {
            Xrm.Page.getAttribute("bso_motivodeestudoreestudo").setRequiredLevel("none");
            return;
        }

        if (motivoEstudoReestudo == null && flagPreencheuMotivo != true) {
            //Xrm.Utility.alertDialog("É necessário preencher o motivo de estudo/reestudo!");
            Xrm.Page.getControl("bso_motivodeestudoreestudo").setFocus();
            Xrm.Page.getAttribute("bso_flagpreencheumotivoestudo").setValue(true);
        }
    }
};



