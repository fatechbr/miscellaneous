/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />

var entity = "opportunities";
var motivoPendenciaPreviousValue;
var dataRetornoAnalisePreviousValue;
var dataRetornoAnaliseOdontoPreviousValue;
var stageID;
var stagename;
var razaoStatusInicial;

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_opportunities) === "undefined") { bradescoseguros.corp_opportunities = {}; }


bradescoseguros.corp_opportunities = {
    onload: async function (event) {
        context = event.getFormContext();

        //Esconder BPF
        setTimeout(collapseBusinessProcess, 300);

        //hide 'next' button
        //bradescoseguros.corp_opportunities.HideNextButton();

        //rule create
        if (Xrm.Page.ui.getFormType() === 1) {
            var message = await bradescoseguros.corp_common.message.get("M_A_1000003"); //Não criar oportunidade sem passar por cliente potencial
            Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, message.bso_larguradopainel, message.bso_alturadopainel);
        }

        razaoStatusInicial = Xrm.Page.getAttribute("statuscode").getValue();

        bradescoseguros.corp_opportunities.set_onchangefield();
        bradescoseguros.corp_opportunities.show_product_fields();
        bradescoseguros.corp_opportunities.configurarSubproduto();
        bradescoseguros.corp_opportunities.validaCampos();
        bradescoseguros.corp_opportunities.getClientOpportunities();
        bradescoseguros.corp_opportunities.validarCotacaoSemMotivoEstudo();
        //bradescoseguros.corp_opportunities.carregarGerenteComercial();
        // bradescoseguros.corp_opportunities.getSucursal();

        bradescoseguros.corp_opportunities.habilitarMotivoPendencia();
        bradescoseguros.corp_opportunities.filtrarStatus();
        motivoPendenciaPreviousValue = Xrm.Page.getAttribute("bso_motivopendencia").getValue();
        dataRetornoAnalisePreviousValue = Xrm.Page.getAttribute("bso_dataretornoanalise").getValue();
        dataRetornoAnaliseOdontoPreviousValue = Xrm.Page.getAttribute("bso_dataretornoanalisesaudeodontoprev").getValue();
        Xrm.Page.getAttribute("bso_pendencianacotacao").addOnChange(bradescoseguros.corp_opportunities.habilitarMotivoPendencia);
        Xrm.Page.getAttribute("bso_pendencianacotacao").addOnChange(bradescoseguros.corp_opportunities.preencherDataRetornoAnalise);
        Xrm.Page.getAttribute("statuscode").addOnChange(bradescoseguros.corp_opportunities.preencherDataRetornoAnaliseOdonto);
        Xrm.Page.getAttribute("bso_motivopendencia").addOnChange(bradescoseguros.corp_opportunities.preencherEnvioSUCCORR);
        Xrm.Page.getAttribute("statuscode").addOnChange(bradescoseguros.corp_opportunities.onChangeRazaodoStatus);
        Xrm.Page.getAttribute("stepname").addOnChange(bradescoseguros.corp_opportunities.filtrarStatus);

        //pre search
        var currentuser = bradescoseguros.corp_common.user.get_current_userid();
        var sucursalmumbers = await bradescoseguros.corp_estruturadistribuicao.get_distinct_sucursalnumber(currentuser);
        var cpfcnpjcorretora = await bradescoseguros.corp_estruturadistribuicao.get_distinct_cpfcnpjcorretora(currentuser);



        Xrm.Page.getControl("bso_sucursal").addPreSearch(function () {
            if (sucursalmumbers != null)
                bradescoseguros.corp_opportunities.add_sucursal_filter(sucursalmumbers);
        });

        Xrm.Page.getControl("bso_corretora").addPreSearch(function () {
            if (cpfcnpjcorretora != null)
                bradescoseguros.corp_opportunities.add_corretora_filter(cpfcnpjcorretora);
        });
    },

    motivoDeclinioChange: function () {
        debugger;

        var razaoStatus = Xrm.Page.getAttribute("statuscode").getValue();
        var produto = Xrm.Page.getAttribute("bso_produto").getValue();

        if ((produto === 861500003 || produto === 861500000) && razaoStatus === 861500012) {
            var src = "/WebResources/bso_motivo_declinio";
            var DialogOptions = new Xrm.DialogOptions();
            DialogOptions.width = 630;
            DialogOptions.height = 400;

            Xrm.Internal.openDialog(src, DialogOptions, null, null, CallbackFunction);
        }
    },

    set_onchangefield: function () {
        //onchange
        context.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_opportunities.showAdesao);
        context.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_opportunities.show_product_fields);
        context.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_opportunities.setObrigatorioProductFamily);
        context.getAttribute("bso_produto").addOnChange(bradescoseguros.corp_opportunities.configurarSubproduto);
        context.getAttribute("stepname").addOnChange(bradescoseguros.corp_opportunities.validaCampos);
        context.getAttribute("statuscode").addOnChange(bradescoseguros.corp_opportunities.messageStatus);
        context.getAttribute("bso_familiadeprodutos").addOnChange(bradescoseguros.corp_opportunities.familiaProdutos);
    },

    showAdesao: function () {
        if (Xrm.Page.getAttribute("bso_produto").getValue() === 861500005 || Xrm.Page.getAttribute("bso_produto").getValue() === 861500001) {
            Xrm.Page.getControl("bso_adesao").setVisible(true)
        }
        else {
            Xrm.Page.getControl("bso_adesao").setVisible(false)
        }
    },

    familiaProdutos: function () {
        if (Xrm.Page.getAttribute("bso_familiadeprodutos").getValue() === 100000010) {
            Xrm.Page.getAttribute("bso_cobertura").setRequiredLevel("required");
        }
        else {
            Xrm.Page.getAttribute("bso_cobertura").setRequiredLevel("none");
            Xrm.Page.getAttribute("bso_cobertura").setValue(null);
        }
    },

    getClientOpportunities: function () {
        let client = Xrm.Page.getAttribute("customerid").getValue()[0].id.replace("{", "").replace("}", "");
        let recId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");

        let opportunityid = [];
        let results = null;
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/opportunities?$select=bso_canal,name,statecode&$filter=_customerid_value eq " + client + "", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        if (results.value[i].statecode == 0 && results.value[i].bso_canal == 861500002) {
                            opportunityid.push(results.value[i]["opportunityid"]);
                        }
                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();

        if (results === null)
            return;

        var exibeAlerta = false;

        opportunityid.forEach(guid => {
            if (guid != recId.toLowerCase()) {
                exibeAlerta = true;
            }
        });

        if (exibeAlerta) {
            Xrm.Page.ui.setFormNotification("Existe mais de uma Oportunidade em aberto para o cliente envolvido, com as mesmas características.", "WARNING");
        }
    },

    add_sucursal_filter: function (fieldvalues) {


        var fetchFilter = "<filter type='and'>";
        fetchFilter += "<filter type='or'>";

        for (var i = 0; i < fieldvalues.length; i++) {
            fetchFilter += "<condition attribute='camp_codigosucursal' operator='eq' value='" + fieldvalues[i] + "' />";
        }

        fetchFilter += "</filter>";
        fetchFilter += "</filter>";

        Xrm.Page.getControl("bso_sucursal").addCustomFilter(fetchFilter);
    },

    add_corretora_filter: function (fieldvalues) {


        var fetchFilter = "<filter type='and'>";
        fetchFilter += "<filter type='or'>";

        for (var i = 0; i < fieldvalues.length; i++) {
            fetchFilter += "<condition attribute='bso_cnpj' operator='eq' value='" + fieldvalues[i] + "' />";
        }

        fetchFilter += "</filter>";
        fetchFilter += "</filter>";

        Xrm.Page.getControl("bso_corretora").addCustomFilter(fetchFilter);
    },

    onsave: function (context) {

        var isSave = true;

        if (Xrm.Page.ui.getFormType() === 1)
            isSave = false;

        if (!isSave) {
            bradescoseguros.corp_common.message.alertasync("M_A_1000004");

            var eventArgs = context.getEventArgs()
            eventArgs.preventDefault();
        }
    },

    getbyaccount: function (accountid, isAsync) {

        var select = "select=";
        var selectparam = "opportunityid,_customerid_value";

        select += selectparam;

        var filter = "filter="
        var filterparam = "_customerid_value eq " + accountid + " and statecode eq 0";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = null;

        if (isAsync)
            response = bradescoseguros.corp_xmlhttprequest.getasync("opportunities", option);
        else
            response = bradescoseguros.corp_xmlhttprequest.getsync("opportunities", option);

        if (response == null)
            return null;

        var json = JSON.parse(response);

        if (json.value.length > 0)
            return json.value[0];
        else
            return null;

    },

    show_product_fields: async function () {
        let product = Xrm.Page.getAttribute("bso_produto").getValue();
        let showfields = [];
        let hidefields = [];

        switch (product) {
            //Auto
            case 861500000:
                hidefields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(true); // Auto
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(true); // Auto
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);

                break;

            //Dental
            case 861500001:
                hidefields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(true); //Dental
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(false);

                break;

            //Previdência
            case 861500002:
                hidefields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(true); //Previdência
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(false);

                break;

            //RE
            case 861500003:
                hidefields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(true); // RE
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(true); // RE

                break;

            //Vida
            case 861500004:
                hidefields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(true); //Vida
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(false);

                break;

            //Saúde	
            case 861500005:
                hidefields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(true); //Saúde
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(false);

                break;

            //Capitalização
            case 861500006:
                showfields = ["bso_tipodepagamento"];
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(false);
                Xrm.Page.getControl("bso_premiomensal").setVisible(true);
                break;

            default:
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_7").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_8").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_9").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_11").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_12").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_10").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_13").setVisible(false);
                Xrm.Page.getControl("bso_premiomensal").setVisible(true);
                break;
        }

        bradescoseguros.corp_common.display.set_display_properties(showfields, true);
        bradescoseguros.corp_common.display.set_display_properties(hidefields, false);
    },

    set_product_family: async function () {
        var producttype = Xrm.Page.getAttribute("bso_produto").getValue();
        var productfamily = Xrm.Page.getAttribute("bso_familiadeprodutos");

        switch (producttype) {
            case 861500000:
                //Auto
                productfamily.setValue(861500000);
                break;
            case 861500001:
                //Dental
                productfamily.setValue(861500001);
                break;
            case 861500002:
                //Previdencia
                productfamily.setValue(861500006);
                break;
            case 861500004:
                //Vida
                productfamily.setValue(861500011);
                break;
            case 861500005:
                //Saude
                productfamily.setValue(861500009);
                break;

            default:

                productfamily.setValue(null);
                break;
        }
    },

    getbycontact: function (contactid, isAsync) {

        var select = "select=";
        var selectparam = "opportunityid,_parentcontactid_value";

        select += selectparam;

        var filter = "filter="
        var filterparam = "_parentcontactid_value eq " + contactid + " and statecode eq 0";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = null;

        if (isAsync)
            response = bradescoseguros.corp_xmlhttprequest.getasync("opportunities", option);
        else
            response = bradescoseguros.corp_xmlhttprequest.getsync("opportunities", option);

        if (response == null)
            return null;

        var json = JSON.parse(response);

        if (json.value.length > 0)
            return json.value[0];
        else
            return null;


    },

    validaCampos: function () {

        switch (context.getAttribute("stepname").getValue()) {
            case "2-Cotar":
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_4").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_5_section_3").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_6").setVisible(false);
                break;

            case "3-Negociar":
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_4").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_5_section_3").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_6").setVisible(false);
                break;

            case "4-Implantar":
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_4").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_5_section_3").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_6").setVisible(false);
                break;

            case "5-Encerrar":
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_4").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_5_section_3").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_6").setVisible(true);
                break;

            default:
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_1").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_2").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_11_section_3").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_11_section_4").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_4").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_5_section_3").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_6").setVisible(false);
                break;
        }
		
		if (context.getAttribute("bso_ndofluig").getValue() != null)
            Xrm.Page.ui.tabs.get("tab_7").setVisible(true);
        else
            Xrm.Page.ui.tabs.get("tab_7").setVisible(false);

    },

    SubgridButtonShowHide: function () {
        let exibirBotao = false;
        let funcoesUsuario = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < funcoesUsuario.length; i++) {
            let funcaoGuid = funcoesUsuario[i];
            let nomeFuncao = bradescoseguros.corp_opportunities.GetRoleName(funcaoGuid);
            if (nomeFuncao === "Gerente de Negócios - Corporate" || nomeFuncao === "Gerente de Cotação/Implantação - Corporate") {
                exibirBotao = true;
                break;
            }
        }
        return exibirBotao;
    },

    GetRoleName: function (roleId) {
        var serverUrl = Xrm.Page.context.getClientUrl();
        var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$filter=RoleId eq guid'" + roleId + "'";
        var nomeFuncao = null;

        $.ajax(
            {
                type: "GET",
                async: false,
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: odataSelect,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data, textStatus, XmlHttpRequest) {
                    nomeFuncao = data.d.results[0].Name;
                },
                error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
            }
        );
        return nomeFuncao;
    },

    showSolicitarAprovacao: function () {
        debugger;
        var btn = [
            new Alert.Button("Enviar", bradescoseguros.corp_opportunities.btn_enviar, true, true),
            new Alert.Button("Cancelar", bradescoseguros.corp_opportunities.btn_cancel, true, false)
        ]
        var id = Xrm.Page.data.entity.getId();
        id = id.replace("{", "").replace("}", "")
        var solicitacaoAlert = Alert.showWebResource("bso_/html/corp_solicitar_aprovacao.html?id=" + id, 1300, 690, "", btn, context.context.getClientUrl(), true, 30)
    },

    enviar_solicitacao_cotacao: function () {
        bradescoseguros.corp_opportunities.transformToObject();

    },

    transformToObject: function () {
        var iFrameWindow = Alert.getIFrameWindow();
        var selectedRows = [];
        iFrameWindow.$("input:checked").parents("tr").each(function (index) {
            var cotacaoId = $(this).attr('id').replace('TRID', '');
            var responsavel = $($($($($($(this).children("td")[5]).children("div")).children("div")).children("input"))[0]).attr("data-id");
            var responsavelVertical = $($($($($($(this).children("td")[6]).children("div")).children("div")).children("input"))[0]).attr("data-id");
            var desconto = $($($(this).children("td")[4]).children()[0]).children()[0].value;
            var pleito = iFrameWindow.$("#pleito").val();
            var tipoSolicitacaoValue = $($($(this).children("td")[3]).children()[0]).val();
            var tipoSolicitacao = tipoSolicitacaoValue == "1" ? 100000000 : 100000001;

            if (pleito == "" || pleito == null) {
                iFrameWindow.$("#informativo p").text("")
                iFrameWindow.$("#informativo").removeClass("alert-danger").removeClass("alert-danger").addClass("alert-warning")
                iFrameWindow.$("#informativo p").text("Você deve preencher o pleito para todas as cotações selecionadas.")
                iFrameWindow.$("#informativo").show().delay(5000).fadeOut();
                return;
            }

            if ((desconto == "" || desconto == null) && tipoSolicitacao == 100000000) {
                iFrameWindow.$("#informativo p").text("")
                iFrameWindow.$("#informativo").removeClass("alert-danger").removeClass("alert-danger").addClass("alert-warning")
                iFrameWindow.$("#informativo p").text("Você deve preencher o desconto para todas as cotações selecionadas.")
                iFrameWindow.$("#informativo").show().delay(5000).fadeOut();
                return;
            }

            if (responsavel != "" && responsavel != null) {

                var CotacaoObject = {
                    CotacaoId: cotacaoId,
                    descontoCotacao: desconto,
                    responsavel: responsavel,
                    responsavelVertical: "",
                    pleito: pleito,
                    tipoSolicitacao: tipoSolicitacao
                }

            } else if (responsavelVertical != "" && responsavelVertical != null) {
                var CotacaoObject = {
                    CotacaoId: cotacaoId,
                    descontoCotacao: desconto,
                    responsavel: "",
                    responsavelVertical: responsavelVertical,
                    pleito: pleito,
                    tipoSolicitacao: tipoSolicitacao
                }

            } else {
                iFrameWindow.$("#informativo p").text("");
                iFrameWindow.$("#informativo").removeClass("alert-danger").removeClass("alert-danger").addClass("alert-warning");
                iFrameWindow.$("#informativo p").text("Você deve preencher um responsável para todas as cotações selecionadas.");
                iFrameWindow.$("#informativo").show().delay(5000).fadeOut();
                return
            }

            selectedRows.push(CotacaoObject)
        })

        bradescoseguros.corp_opportunities.solicitarCotacao(selectedRows);
    },
    solicitarCotacao: function (rows) {
        var currentuser = bradescoseguros.corp_common.user.get_current_userid();

        $.each(rows, function (index, row) {

            var parameters = {};
            parameters.tipoSolicitacao = row.tipoSolicitacao;
            var ownerid = {};
            if (row.responsavel == "") {
                ownerid.systemuserid = currentuser;
            } else {
                ownerid.systemuserid = row.responsavel;
            }

            ownerid["@odata.type"] = "Microsoft.Dynamics.CRM.systemuser";
            parameters.ownerId = ownerid;
            var cotacao = {};
            cotacao.quoteid = row.CotacaoId;
            cotacao["@odata.type"] = "Microsoft.Dynamics.CRM.quote";
            parameters.Cotacao = cotacao;
            if (row.responsavel == "") {
                var responsavelvertical = {};
                responsavelvertical.bso_usuarioverticalid = row.responsavelVertical;
                responsavelvertical["@odata.type"] = "Microsoft.Dynamics.CRM.bso_usuariovertical";
                parameters.responsavelVertical = responsavelvertical;
            }
            parameters.descontoSolicitado = row.descontoCotacao == "" ? 0 : row.descontoCotacao;
            parameters.Descricao = row.pleito;
            var oportunidade = {};
            oportunidade.opportunityid = Xrm.Page.data.entity.getId();
            oportunidade["@odata.type"] = "Microsoft.Dynamics.CRM.opportunity";
            parameters.Oportunidade = oportunidade;
            var corretora = {};
            corretora.bso_corretoraid = Xrm.Page.getAttribute("bso_corretora").getValue()[0].id;
            corretora["@odata.type"] = "Microsoft.Dynamics.CRM.bso_corretora";
            parameters.Corretora = corretora;
            var cliente = {};
            cliente.accountid = Xrm.Page.getAttribute("customerid").getValue()[0].id;
            cliente["@odata.type"] = "Microsoft.Dynamics.CRM.account";
            parameters.Cliente = cliente;

            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_CriarSolicitaodeAprovao",
                data: JSON.stringify(parameters),
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                    XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                async: true,
                success: function (data, textStatus, xhr) {
                    if (index == rows.length - 1)
                        Alert.hide();
                },
                error: function (xhr, textStatus, errorThrown) {
                    Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                }
            });
        })

    },

    btn_enviar: function () {

        var iFrameWindow = Alert.getIFrameWindow();

        if (iFrameWindow.$("input:checked").toArray().length == 0) {
            iFrameWindow.$("#informativo p").text("")
            iFrameWindow.$("#informativo").removeClass("alert-danger").removeClass("alert-danger").addClass("alert-warning")
            iFrameWindow.$("#informativo p").text("Você deve selecionar ao menos uma cotação para enviar.")
            iFrameWindow.$("#informativo").show().delay(5000).fadeOut();
        } else {
            bradescoseguros.corp_opportunities.enviar_solicitacao_cotacao();
        }
    },

    btn_cancel: function () {

    },

    addOptionsSubProduto: (options) => {
        let pickList = Xrm.Page.getControl("bso_subproduto")
        options.forEach(element => { pickList.addOption(element) })
    },

    removeOptionsSubProduto: (options) => {
        let pickList = Xrm.Page.getControl("bso_subproduto")
        options.forEach(element => { pickList.removeOption(element) })
    },

    configurarSubproduto: function () {
        var produtopr = Xrm.Page.getAttribute("bso_produto").getValue();

        if (produtopr != null) {
            var optionSubProduto = [100000000, 100000001, 100000002, 100000003, 100000004, 100000005];

            switch (produtopr) {
                //auto
                case 861500000:
                    Xrm.Page.getControl("bso_subproduto").setVisible(false);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);
                    break;

                //dental
                case 861500001:

                    Xrm.Page.getControl("bso_subproduto").setVisible(true);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("required");

                    let addSubDental = [{ value: 100000002, text: "Clinic" }, { value: 100000005, text: "Premium" }];
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);
                    bradescoseguros.corp_opportunities.addOptionsSubProduto(addSubDental);

                    break;

                //saude
                case 861500005:
                    Xrm.Page.getControl("bso_subproduto").setVisible(true);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("required");

                    let addSubSaude = [{ value: 100000000, text: "Top" }, { value: 100000001, text: "Hospitalar" }];
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);
                    bradescoseguros.corp_opportunities.addOptionsSubProduto(addSubSaude);

                    break;

                //vida
                case 861500004:
                    Xrm.Page.getControl("bso_subproduto").setVisible(false);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);
                    break;

                //previdencia
                case 861500002:
                    Xrm.Page.getControl("bso_subproduto").setVisible(false);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);
                    break;

                //RE
                case 861500003:
                    Xrm.Page.getControl("bso_subproduto").setVisible(false);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);

                    break;

                //capitalização
                case 861500006:
                    Xrm.Page.getControl("bso_subproduto").setVisible(false);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(options1);
                    break;

                //Saúde/Dental – Conjugado
                case 100000000:
                    Xrm.Page.getControl("bso_subproduto").setVisible(true);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("required");

                    let addSubSaudeDental = [{ value: 100000000, text: "Top" }, { value: 100000001, text: "Hospitalar" }];
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(optionSubProduto);
                    bradescoseguros.corp_opportunities.addOptionsSubProduto(addSubSaudeDental);
                    break;

                default:
                    Xrm.Page.getControl("bso_subproduto").setVisible(false);
                    Xrm.Page.getAttribute("bso_subproduto").setRequiredLevel("none");
                    bradescoseguros.corp_opportunities.removeOptionsSubProduto(options1);
                    break;
            }
        }
    },


    setObrigatorioProductFamily: function () {
        var produtopr = Xrm.Page.getAttribute("bso_produto").getValue();
        if ((produtopr == 861500006) || (produtopr == 100000000)) {
            Xrm.Page.getAttribute("bso_familiadeprodutos").setRequiredLevel("none");
        } else { Xrm.Page.getAttribute("bso_familiadeprodutos").setRequiredLevel("required"); }
    },

    messageStatus: function () {

        var codestatus = Xrm.Page.getAttribute("statuscode").getValue();
        if (codestatus == 861500007) {
            bradescoseguros.corp_common.message.alertasync("M_A_1000014");
        } else {
            return false;
        }
    },

    getSucursal: function () {
        let sucursalIndicacao = Xrm.Page.getAttribute("bso_sucursaldeindicacao").getValue().replace(" ", "");

        let sucursalid = [];
        let results = null;
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/camp_sucursal?$filter=camp_codigosucursal eq " + sucursalIndicacao + "", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    alert('');
                    results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        sucursalid.push(results.value[0]);
                    }

                    var lookupValue = new Array();
                    lookupValue[0] = new Object();
                    lookupValue[0].id = sucursalid.getValue()[0].id;
                    lookupValue[0].name = sucursalid.getValue()[0].name;
                    lookupValue[0].entityType = "camp_sucursal";

                    Xrm.Page.getAttribute("bso_sucursal").setValue(lookupValue);
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();

        if (results === null)
            return;
    },

    // Início das funções criadas para atendimento da estória 1 do projeto EFV - Melhorias Área Suporte Comercial

    habilitarMotivoPendencia: function () {
        var pendenciaCotacao = Xrm.Page.getAttribute("bso_pendencianacotacao").getValue();

        if (pendenciaCotacao === 1) { // Sim
            Xrm.Page.getControl("bso_motivopendencia").setVisible(true);
            Xrm.Page.getAttribute("bso_motivopendencia").setRequiredLevel("required");
        }
        else {
            Xrm.Page.getControl("bso_motivopendencia").setVisible(false);
            Xrm.Page.getAttribute("bso_motivopendencia").setValue(null);
            Xrm.Page.getAttribute("bso_motivopendencia").setRequiredLevel("none");
        }
    },

    preencherEnvioSUCCORR: function () {
        if (motivoPendenciaPreviousValue === null || motivoPendenciaPreviousValue == undefined) {
            var motivoPendencia = Xrm.Page.getAttribute("bso_motivopendencia").getValue();

            if (motivoPendencia != null && motivoPendencia != undefined) {
                Xrm.Page.getAttribute("bso_enviosuccorr").setValue(new Date());
                Xrm.Page.getAttribute("statuscode").setValue(861500011); // Pendência de Sucursal
                Xrm.Page.data.entity.save();
            }
        }
    },

    preencherDataRetornoAnalise: function () {
        if (dataRetornoAnalisePreviousValue === null || dataRetornoAnalisePreviousValue == undefined) {
            var pendenciaCotacao = Xrm.Page.getAttribute("bso_pendencianacotacao").getValue();
            var solicitacaoSucursal = Xrm.Page.getAttribute("bso_retornosuccorr").getValue();
            var envioSucursal = Xrm.Page.getAttribute("bso_enviosuccorr").getValue();

            if (pendenciaCotacao === 0 && solicitacaoSucursal == null && envioSucursal != null) { // Não
                Xrm.Page.getAttribute("bso_retornosuccorr").setRequiredLevel("required");
                Xrm.Page.getControl("bso_retornosuccorr").setDisabled(false);
                Xrm.Page.getControl("bso_retornosuccorr").setFocus();
                Xrm.Page.getControl("bso_motivopendencia").setVisible(false);
                Xrm.Page.getAttribute("bso_motivopendencia").setValue(null);
                Xrm.Page.getAttribute("bso_motivopendencia").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_dataretornoanalise").setValue(new Date());
                Xrm.Page.getControl("bso_dataretornoanalise").setDisabled(true);
                //Xrm.Page.getAttribute("statuscode").setValue(1); // Em Andamento
                Xrm.Page.data.entity.save();
            }
        }
    },

    preencherDataRetornoAnaliseOdonto: function () {
        var razaoStatus = Xrm.Page.getAttribute("statuscode").getValue();
        var envioOdonto = Xrm.Page.getAttribute("bso_enviosaudeodontoprev").getValue();
        var produto = Xrm.Page.getAttribute("bso_produto").getValue();

        if (razaoStatusInicial == 861500000 && razaoStatusInicial != razaoStatus && envioOdonto != null && produto != 861500000 && produto != 861500003 && razaoStatus != 1) {
            Xrm.Page.getAttribute("bso_retornosaudeodontoprev").setValue();
            Xrm.Page.getAttribute("bso_retornosaudeodontoprev").setRequiredLevel("required");
            Xrm.Page.getControl("bso_retornosaudeodontoprev").setDisabled(false);
            Xrm.Page.getControl("bso_retornosaudeodontoprev").setFocus();
            Xrm.Page.getAttribute("bso_dataretornoanalisesaudeodontoprev").setValue(new Date());
            Xrm.Page.getControl("bso_dataretornoanalisesaudeodontoprev").setDisabled(true);
            //Xrm.Page.getAttribute("statuscode").setValue(1); // Em Andamento
            Xrm.Page.data.entity.save();

        }
        if ((produto == 861500000 || produto == 861500003) && razaoStatus != 1) {
            Xrm.Page.getAttribute("bso_data_distribuicao").setValue(new Date());
            Xrm.Page.getControl("bso_data_distribuicao").setVisible(true);
            Xrm.Page.data.entity.save();
        }
    },

    onChangeRazaodoStatus: function (context) {
        var razaoStatus = Xrm.Page.getAttribute("statuscode").getValue();
        var produto = Xrm.Page.getAttribute("bso_produto").getValue();

        switch (razaoStatus) {
            case 1: // Em Andamento
                break;
            case 2: // Suspenso
                break;
            case 861500011: // Pendência de Sucursal
                Xrm.Page.getAttribute("bso_pendencianacotacao").setValue(1);
                bradescoseguros.corp_opportunities.habilitarMotivoPendencia();
                break;
            case 861500000: // Pendente de Distribuição
                Xrm.Page.getAttribute("bso_enviosaudeodontoprev").setValue(new Date());
                Xrm.Page.getControl("bso_enviosaudeodontoprev").setDisabled(true);
                break;
            case 861500001: // Distribuída
                {
                    if (produto != 861500000 && produto != 861500003)
                        Xrm.Page.getAttribute("bso_dataretornoanalisesaudeodontoprev").setValue(new Date());
                    var solicitacaoDistribuicao = Xrm.Page.getAttribute("bso_enviosaudeodontoprev").getValue();
                    if (solicitacaoDistribuicao != null) {
                        var envioOdonto = Xrm.Page.getAttribute("bso_enviosaudeodontoprev").getValue();
                        if (envioOdonto != null) {
                            Xrm.Page.getAttribute("bso_retornosaudeodontoprev").setRequiredLevel("required");
                            Xrm.Page.getControl("bso_retornosaudeodontoprev").setDisabled(false);
                            Xrm.Page.getControl("bso_retornosaudeodontoprev").setFocus();
                        }
                    }
                }
                break;
            case 861500007: // Proposta Enviada
                Xrm.Page.getAttribute("bso_envioproposta").setValue(new Date());
                Xrm.Page.getControl("bso_envioproposta").setDisabled(true);
                break;
            case 861500009: // Proposta Devolvida
                Xrm.Page.getAttribute("bso_propostadevolvida").setValue(new Date());
                Xrm.Page.getControl("bso_propostadevolvida").setDisabled(true);
                break;
            default:
            //DoNothing
        }

        var estagioAtivo = Xrm.Page.getAttribute("stepname").getValue();

        //if (razaoStatusInicial == 861500011 && (razaoStatusInicial != razaoStatus)) {
        //    Xrm.Page.getAttribute("bso_pendencianacotacao").setValue(0);
        //    Xrm.Page.getAttribute("bso_retornosuccorr").setRequiredLevel("required");
        //    Xrm.Page.getControl("bso_retornosuccorr").setDisabled(false);
        //    Xrm.Page.getControl("bso_retornosuccorr").setFocus();
        //    Xrm.Page.getControl("bso_motivopendencia").setVisible(false);
        //    Xrm.Page.getAttribute("bso_motivopendencia").setValue(null);
        //    Xrm.Page.getAttribute("bso_motivopendencia").setRequiredLevel("none");
        //    bradescoseguros.corp_opportunities.preencherDataRetornoAnalise();
        //}
        //else {
        //    Xrm.Page.getAttribute("bso_retornosuccorr").setRequiredLevel("none");
        //}

        //Xrm.Page.data.entity.save();

        if (razaoStatus != 861500011) {
            Xrm.Page.getAttribute("bso_pendencianacotacao").setValue(0);
            var pendenciaCotacao = Xrm.Page.getAttribute("bso_pendencianacotacao").getValue();
            var solicitacaoSucursal = Xrm.Page.getAttribute("bso_retornosuccorr").getValue();
            var envioSucursal = Xrm.Page.getAttribute("bso_enviosuccorr").getValue();

            if (pendenciaCotacao === 0 && solicitacaoSucursal == null && envioSucursal != null) { // Não
                Xrm.Page.getAttribute("bso_retornosuccorr").setRequiredLevel("required");
                Xrm.Page.getControl("bso_retornosuccorr").setDisabled(false);
                Xrm.Page.getControl("bso_retornosuccorr").setFocus();
                Xrm.Page.getControl("bso_motivopendencia").setVisible(false);
                Xrm.Page.getAttribute("bso_motivopendencia").setValue(null);
                Xrm.Page.getAttribute("bso_motivopendencia").setRequiredLevel("none");
                Xrm.Page.getAttribute("bso_dataretornoanalise").setValue(new Date());
                Xrm.Page.getControl("bso_dataretornoanalise").setDisabled(true);
                //Xrm.Page.getAttribute("statuscode").setValue(1); // Em Andamento
                Xrm.Page.data.entity.save();
            }
        }
    },

    filtrarStatus: function () {
        var estagioAtivo = Xrm.Page.getAttribute("stepname").getValue();
        var produto = Xrm.Page.getAttribute("bso_produto").getValue();

        if (estagioAtivo.indexOf('Cotar') > 0) {
            Xrm.Page.getControl("statuscode").removeOption(1); // Em Andamento
            Xrm.Page.getControl("statuscode").removeOption(2); // Suspenso
            Xrm.Page.getControl("statuscode").removeOption(861500011); // Pendência de Sucursal
            Xrm.Page.getControl("statuscode").removeOption(861500000); // Pendente de Distribuição
            Xrm.Page.getControl("statuscode").removeOption(861500001); // Distribuída
            Xrm.Page.getControl("statuscode").removeOption(861500009); // Proposta Devolvida
            Xrm.Page.getControl("statuscode").removeOption(861500010); // Proposta Mestra Liberada
            Xrm.Page.getControl("statuscode").removeOption(861500008); // Proposta Assinada
            Xrm.Page.getControl("statuscode").removeOption(861500007); // Proposta Enviada
            Xrm.Page.getControl("statuscode").removeOption(3); // Venda Efetivada
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Ganha
            Xrm.Page.getControl("statuscode").removeOption(861500003); // Cancelada
            Xrm.Page.getControl("statuscode").removeOption(5); // Esgotada
            Xrm.Page.getControl("statuscode").removeOption(861500002); // Fechada
            Xrm.Page.getControl("statuscode").removeOption(861500006); // Outros
            Xrm.Page.getControl("statuscode").removeOption(861500005); // Prazo
            Xrm.Page.getControl("statuscode").removeOption(861500004); // Preço
            Xrm.Page.getControl("statuscode").removeOption(4); // Venda Perdida
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Declinar

            if (produto == 861500000 || produto == 861500003) {
                Xrm.Page.getControl("statuscode").addOption({ value: 1, text: "Em Andamento" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500001, text: "Distribuída" });
				Xrm.Page.getControl("statuscode").addOption({ value: 861500007, text: "Proposta Enviada" });
            }
            else {
                Xrm.Page.getControl("statuscode").addOption({ value: 1, text: "Em Andamento" });
                Xrm.Page.getControl("statuscode").addOption({ value: 2, text: "Suspenso" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500011, text: "Pendência de Sucursal" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500000, text: "Pendente de Distribuição" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500001, text: "Distribuída" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500007, text: "Proposta Enviada" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500009, text: "Proposta Devolvida" });
            }

        }
        else if (estagioAtivo.indexOf('Negociar') > 0) {
            Xrm.Page.getControl("statuscode").removeOption(861500007); // Proposta Enviada
            Xrm.Page.getControl("statuscode").removeOption(1); // Em Andamento
            Xrm.Page.getControl("statuscode").removeOption(2); // Suspenso
            Xrm.Page.getControl("statuscode").removeOption(861500011); // Pendência de Sucursal
            Xrm.Page.getControl("statuscode").removeOption(861500000); // Pendente de Distribuição
            Xrm.Page.getControl("statuscode").removeOption(861500001); // Distribuída
            Xrm.Page.getControl("statuscode").removeOption(861500009); // Proposta Devolvida
            Xrm.Page.getControl("statuscode").removeOption(861500010); // Proposta Mestra Liberada
            Xrm.Page.getControl("statuscode").removeOption(861500008); // Proposta Assinada
            Xrm.Page.getControl("statuscode").removeOption(3); // Venda Efetivada
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Ganha
            Xrm.Page.getControl("statuscode").removeOption(861500003); // Cancelada
            Xrm.Page.getControl("statuscode").removeOption(5); // Esgotada
            Xrm.Page.getControl("statuscode").removeOption(861500002); // Fechada
            Xrm.Page.getControl("statuscode").removeOption(861500006); // Outros
            Xrm.Page.getControl("statuscode").removeOption(861500005); // Prazo
            Xrm.Page.getControl("statuscode").removeOption(861500004); // Preço
            Xrm.Page.getControl("statuscode").removeOption(4); // Venda Perdida
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Declinar

            if (produto == 861500000 || produto == 861500003) {
				Xrm.Page.getControl("statuscode").addOption({ value: 861500007, text: "Proposta Enviada" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500009, text: "Proposta Devolvida" });
            }
            else {
                Xrm.Page.getControl("statuscode").addOption({ value: 861500007, text: "Proposta Enviada" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500009, text: "Proposta Devolvida" });
                Xrm.Page.getControl("statuscode").addOption({ value: 861500010, text: "Proposta Mestra Liberada" });
            }
        }
        else if (estagioAtivo.indexOf('Implantar') > 0) {
            Xrm.Page.getControl("statuscode").removeOption(861500007); // Proposta Enviada
            Xrm.Page.getControl("statuscode").removeOption(3); // Venda Efetivada
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Ganha
            Xrm.Page.getControl("statuscode").removeOption(1); // Em Andamento
            Xrm.Page.getControl("statuscode").removeOption(2); // Suspenso
            Xrm.Page.getControl("statuscode").removeOption(861500011); // Pendência de Sucursal
            Xrm.Page.getControl("statuscode").removeOption(861500000); // Pendente de Distribuição
            Xrm.Page.getControl("statuscode").removeOption(861500001); // Distribuída
            Xrm.Page.getControl("statuscode").removeOption(861500009); // Proposta Devolvida
            Xrm.Page.getControl("statuscode").removeOption(861500008); // Proposta Assinada
            Xrm.Page.getControl("statuscode").removeOption(861500003); // Cancelada
            Xrm.Page.getControl("statuscode").removeOption(5); // Esgotada
            Xrm.Page.getControl("statuscode").removeOption(861500002); // Fechada
            Xrm.Page.getControl("statuscode").removeOption(861500006); // Outros
            Xrm.Page.getControl("statuscode").removeOption(861500005); // Prazo
            Xrm.Page.getControl("statuscode").removeOption(861500004); // Preço
            Xrm.Page.getControl("statuscode").removeOption(4); // Venda Perdida
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Declinar

            //Xrm.Page.getControl("statuscode").addOption({ value: 861500010, text: "Proposta Assinada" });
            //Xrm.Page.getControl("statuscode").addOption({ value: 3, text: "Venda Efetivada" });
            //Xrm.Page.getControl("statuscode").addOption({ value: 861500012, text: "Ganha" });
            Xrm.Page.getControl("statuscode").addOption(861500010); // Proposta Mestra Liberada
        }
        else if (estagioAtivo.indexOf('Encerrar') > 0) {
            Xrm.Page.getControl("statuscode").removeOption(861500007); // Proposta Enviada
            Xrm.Page.getControl("statuscode").removeOption(861500003); // Cancelada
            Xrm.Page.getControl("statuscode").removeOption(5); // Esgotada
            Xrm.Page.getControl("statuscode").removeOption(861500002); // Fechada
            Xrm.Page.getControl("statuscode").removeOption(861500006); // Outros
            Xrm.Page.getControl("statuscode").removeOption(861500005); // Prazo
            Xrm.Page.getControl("statuscode").removeOption(861500004); // Preço
            Xrm.Page.getControl("statuscode").removeOption(4); // Venda Perdida
            Xrm.Page.getControl("statuscode").removeOption(1); // Em Andamento
            Xrm.Page.getControl("statuscode").removeOption(2); // Suspenso
            Xrm.Page.getControl("statuscode").removeOption(861500011); // Pendência de Sucursal
            Xrm.Page.getControl("statuscode").removeOption(861500000); // Pendente de Distribuição
            Xrm.Page.getControl("statuscode").removeOption(861500001); // Distribuída
            Xrm.Page.getControl("statuscode").removeOption(861500009); // Proposta Devolvida
            Xrm.Page.getControl("statuscode").removeOption(861500010); // Proposta Mestra Liberada
            Xrm.Page.getControl("statuscode").removeOption(861500008); // Proposta Assinada
            Xrm.Page.getControl("statuscode").removeOption(3); // Venda Efetivada
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Ganha
            Xrm.Page.getControl("statuscode").removeOption(861500012); // Declinar

            Xrm.Page.getControl("statuscode").addOption({ value: 861500003, text: "Cancelada" });
            Xrm.Page.getControl("statuscode").addOption({ value: 5, text: "Esgotada" });
            Xrm.Page.getControl("statuscode").addOption({ value: 861500002, text: "Fechada" });
            Xrm.Page.getControl("statuscode").addOption({ value: 861500006, text: "Outros" });
            Xrm.Page.getControl("statuscode").addOption({ value: 861500005, text: "Prazo" });
            Xrm.Page.getControl("statuscode").addOption({ value: 861500004, text: "Preço" });
            Xrm.Page.getControl("statuscode").addOption({ value: 4, text: "Venda Perdida" });
            Xrm.Page.getControl("statuscode").addOption({ value: 861500012, text: "Declinar" });
        }

        Xrm.Page.data.entity.save();
    },

    obterEstagioAtivo: function () {
        var activeStage = Xrm.Page.data.process.getActiveStage();
        stageID = activeStage.getId().toUpperCase();
        stagename = activeStage.getName();
    },

    // Fim das funções criadas para atendimento da Estória 1 do projeto EFV - Melhorias Área Suporte Comercial

    validarCotacaoSemMotivoEstudo: function () {
        var opportunityId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
        var select = "select=name,statecode,quoteid,createdon";
        //var filter = "filter=(Microsoft.Dynamics.CRM.OnOrAfter(PropertyName= createdon, PropertyValue= 2021-01-2) and _opportunityid_value eq " + opportunityId + " and bso_motivodeestudoreestudo eq null)"
        var filter = "filter=(Microsoft.Dynamics.CRM.OnOrAfter(PropertyName=%27createdon%27,PropertyValue=%272021-01-25%27)%20and%20_opportunityid_value%20eq%20" + opportunityId + "%20and%20bso_motivodeestudoreestudo%20eq%20null)"
        var request = select + "&$" + filter;

        var response = null;

        response = bradescoseguros.corp_xmlhttprequest.getsync("quotes", request);

        if (response == null)
            return null;

        var json = JSON.parse(response);

        if (json.value.length > 0) {
            var entityFormOptions = {};
            entityFormOptions["cmdbar"] = true;
            entityFormOptions["navbar"] = 'entity';
            var windowOptions = {
                openInNewWindow: true
            };
            Xrm.Utility.openEntityForm("quote", json.value[0].quoteid, entityFormOptions, windowOptions);
        }

        else
            return null;
    }
};

function collapseBusinessProcess() {
    if (Xrm.Page.ui.process != null)
        Xrm.Page.ui.process.setDisplayState("collapsed");
}

function definirGerenteComercial() {
    proprietario = Xrm.Page.data.entity.attributes.get('ownerid');

    var lookupValue = new Array();
    lookupValue[0] = new Object();
    lookupValue[0].id = proprietario.getValue()[0].id;
    lookupValue[0].name = proprietario.getValue()[0].name;
    lookupValue[0].entityType = "systemuser";
    Xrm.Page.getAttribute("bso_gerente_comercial").setValue(lookupValue);
}

function CallbackFunction(returnValue) {
    debugger;

    var optList = 0;

    switch (returnValue[0]) {
        case "Atividade da empresa":
            optList = 100000000;
            break;
        case "Sinistralidade":
            optList = 100000001;
            break;
        case "Prazo de cotação": 
            optList = 100000002;
            break;
        case "Protecionais": 
            optList = 100000003;
            break;
        case "Composição do risco": 
            optList = 100000004;
            break;
        case "CNPJ/CPF": 
            optList = 100000005;
            break;
        default:

    }
    
    if(optList == 0) {
        Xrm.Page.getAttribute("bso_motivo_declinio").setValue(null);
        Xrm.Page.getAttribute("bso_motivo_declinio").setSubmitMode("always");
    }

    else {
        Xrm.Page.getAttribute("bso_motivo_declinio").setValue(optList);
        Xrm.Page.getAttribute("bso_motivo_declinio").setSubmitMode("always");
    }

    Xrm.Page.getAttribute("bso_observacao_declinio").setValue(returnValue[1]);
    Xrm.Page.getAttribute("bso_observacao_declinio").setSubmitMode("always");
    Xrm.Page.data.entity.save();
}