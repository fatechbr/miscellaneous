﻿function displayIconTooltip(rowData, userLCID) {
    var str = JSON.parse(rowData);
    var col_data = str.scheduledend_Value;
    var imgName = "";
    var tooltip = "{" + col_data + "}";
    var datetimenow = new Date();
    datetimenow.setHours(0, 0, 0, 0);
    var dataconclusaoFormat = new Date(parseInt(str.scheduledend_Value.substring(0, 4)), parseInt(str.scheduledend_Value.substring(5, 7))-1, parseInt(str.scheduledend_Value.substring(8, 10)));    

    if (dataconclusaoFormat < datetimenow)
    {    
        imgName = "bso_\\icon\\corp_warning.gif";
        tooltip = "Atividade atrasada!";
    }
    else if (dataconclusaoFormat > datetimenow) {

        imgName = "bso_\\icon\\corp_calendarGreen.gif";
        tooltip = "Atividade no prazo.";
    }
    else {
        imgName = "bso_\\icon\\corp_warningYellow.gif";
        tooltip = "Prazo da atividade é hoje!";
    }

    var resultArray = [imgName, tooltip];
    return resultArray;
}