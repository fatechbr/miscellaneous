﻿/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />

var entity = "camp_estruturadistribuicao";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_estruturadistribuicao) === "undefined") { bradescoseguros.corp_estruturadistribuicao = {}; }



bradescoseguros.corp_estruturadistribuicao = {

    get_distinct_sucursalnumber: async function (userid) {
        var lookup = {};
        var result = [];
        var select = "select=";
        var selectparam = "camp_surcursal";

        select += selectparam;

        var filter = "filter="
        var filterparam = "_camp_usuarioid_value eq " + userid + " and "+ selectparam +" ne null and (camp_canal eq 861500002 or camp_canal eq 100000005)";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = await bradescoseguros.corp_xmlhttprequest.get("camp_estruturadistribuicaos", option);

        var json = JSON.parse(response);

        if (json.value.length > 0) {

            var fieldvalues = json.value;

            for (var item, i = 0; item = fieldvalues[i++];) {
                var name = item.camp_surcursal;

                if (!(name in lookup)) {
                    lookup[name] = 1;
                    result.push(name);
                }
            }

            return result;

        } else {
            return null;
        }

    },

    get_distinct_cpfcnpjcorretora: async function (userid) {
        var lookup = {};
        var result = [];
        var select = "select=";
        var selectparam = "bso_cpfcnpjdacorretora";

        select += selectparam;

        var filter = "filter="
        var filterparam = "_camp_usuarioid_value eq " + userid + " and "+ selectparam +" ne null and (camp_canal eq 861500002 or camp_canal eq 100000005)";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = await bradescoseguros.corp_xmlhttprequest.get("camp_estruturadistribuicaos", option);

        var json = JSON.parse(response);

        if (json.value.length > 0) {

            var fieldvalues = json.value;

            for (var item, i = 0; item = fieldvalues[i++];) {
                var name = item.bso_cpfcnpjdacorretora;

                if (!(name in lookup)) {
                    lookup[name] = 1;
                    result.push(name);
                }
            }

            return result;

        } else {

            return null;

        }
    },

}