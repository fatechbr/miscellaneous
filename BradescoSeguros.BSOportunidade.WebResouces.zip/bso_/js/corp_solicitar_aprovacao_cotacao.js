/// <reference path="_corp_common.js" />
/// <reference path="_corp_xmlhttprequest.js" />


if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_solicitar_aprovacao_cotacao) === "undefined") { bradescoseguros.corp_solicitar_aprovacao_cotacao = {}; }

bradescoseguros.corp_solicitar_aprovacao_cotacao = {
    carregarListaCotacoes: function () {
        debugger
        var url_string = window.location.href;
        var url = new URL(url_string);
        var id = url.searchParams.get("id");
        if (id != "") {
            bradescoseguros.corp_solicitar_aprovacao_cotacao.RetornarCotacoes(id);
        }

    },
    MontaTabelaCotacao: function (rows) {
        debugger

        for (var i = 0; i < rows.length; i++) {

            var tableRow = "<tr id='TRID" + rows[i].quoteid + "'><td id='TD" + rows[i].quoteid + "'><p class='text-center'></p>" + "<input type='checkbox' name='optcheck'/>" + "</td>"
                + "<td id='name'  style='vertical-align: middle;'>" + rows[i].name + "</td>"
                + "<td id='totalamount'  style='vertical-align: middle;'><label id='totalamountvalue' class='text-center'> R$ " + rows[i].totalamount + "</label></td>"
                + "<td id='tipo'><select class='form-control' onchange='bradescoseguros.corp_solicitar_aprovacao_cotacao.selecionaTipo(" + i + ", this)'><option value='1' > Desconto  </option><option value='2'> Desbloqueio  </option></td>"
                + "<td id='totaldiscountamount' class='col-md-2' > " +
                '<div class="input-group col-xs-7">' +
                '<input id="discount' + i + '" type="text" class="form-control" aria-describedby="sizing-addon1" min="0" max="100" onkeypress="bradescoseguros.corp_solicitar_aprovacao_cotacao.selectdiscount(' + i + ',event)" />  <span class="input-group-addon" id="sizing-addon1" >%</ span>' +
                '</div>' +
                "</td>" +
                "<td id='responsible' >" +
                '<span id="loadingimg1-' + i + '" hidden><img src="../icon/loading.gif" alt="Aguarde..."> </span> ' +
                '<div id="responsible' + i + '">' +
                '<div class="input-group">' +
                '<input id="responsible-' + i + '" onfocusout="bradescoseguros.corp_solicitar_aprovacao_cotacao.verificarResponsavelOnChange(' + i + ')" type="text" class="form-control" aria-describedby="sizing-addon1" disabled/>  <span class="input-group-addon" onclick="bradescoseguros.corp_solicitar_aprovacao_cotacao.toggleSearch(\'#responsible-' + i + '\')" id="sizing-addon1" ><span class="glyphicon glyphicon-search"></ span></ span>' +
                '</div>' +
                '</div>' +
                "</td>" +
                "<td id='responsiblevert' >" +
                '<span id="loadingimg2-' + i + '" hidden><img src="../icon/loading.gif" alt="Aguarde..."> </span> ' +
                '<div id="responsible-vert'+i+'">' +
                '<div class="input-group">' +
                '<input id="responsible-vert-' + i + '" onfocusout="bradescoseguros.corp_solicitar_aprovacao_cotacao.verificarResponsavelVertOnChange(' + i + ')" type="text" class="form-control" aria-describedby="sizing-addon2" disabled/>  <span class="input-group-addon" onclick="bradescoseguros.corp_solicitar_aprovacao_cotacao.toggleSearch(\'#responsible-vert-' + i + '\')" id="sizing-addon2" ><span class="glyphicon glyphicon-search"></ span></ span>' +
                '</div>' +
                '</div>' +
                '</div>' +
                "</td>" +
                "<td hidden>" + '<a href="#" onClick="bradescoseguros.corp_solicitar_aprovacao_cotacao.showTextArea(\'' + rows[i].quoteid + '\')"><span class="glyphicon glyphicon-align-justify" aria-hidden="true"></span></a>' + "</td></tr>";

            $("#tableCotacoes tbody").append(tableRow);
            $("label#totalamountvalue").toLocaleString('pt-BR');
        }

    },
    selecionaTipo: function (row, obj) {
        debugger
        if (obj.selectedOptions[0].value == 2) {
            $($($($($($(obj).closest("tr")[0]).children("td#totaldiscountamount")[0])[0]).children()[0]).children()[0]).prop("disabled", true)
            $($($($($($(obj).closest("tr")[0]).children("td#totaldiscountamount")[0])[0]).children()[0]).children()[0]).val("")
            $("input#responsible-" + row).autocomplete();
            $("input#responsible-vert-" + row).autocomplete();
            $("input#responsible-" + row).val("");
            $("input#responsible-vert-" + row).val("");
            $("input#responsible-" + row).attr("src-length", 0);
            $("input#responsible-vert-" + row).attr("src-length", 0);
            $("div#responsible" + row).hide()
            $("div#responsible-vert" + row).hide()
            $("#loadingimg1-" + row).show()
            $("#loadingimg2-" + row).show()

            bradescoseguros.corp_solicitar_aprovacao_cotacao.buscaParametroDesbloqueio(row)
        } else {
            $($($($($($(obj).closest("tr")[0]).children("td#totaldiscountamount")[0])[0]).children()[0]).children()[0]).prop("disabled", false)
            $($($($($($(obj).closest("tr")[0]).children("td#totaldiscountamount")[0])[0]).children()[0]).children()[0]).val("")
            $("input#responsible-" + row).autocomplete();
            $("input#responsible-vert-" + row).autocomplete();
            $("input#responsible-" + row).val("");
            $("input#responsible-vert-" + row).val("");
            $("input#responsible-" + row).val("").prop("disabled", true)
            $("input#responsible-vert-" + row).val("").prop("disabled", true)
        }
    },
    toggleSearch: function (id) {
        if ($(id).attr("src-length") != 0 && $(id).attr("src-length") != null && $(id).is(':enabled')) {
            $(id).autocomplete("search", " ");
        }
    },
    buscaParametroDesbloqueio: function (row) {
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_parametros?$expand=bso_bso_parametro_bso_usuariovertical($select=bso_email,bso_name,bso_usuarioverticalid),bso_bso_parametro_systemuser($select=fullname,systemuserid)&$filter=bso_tipodeparametro eq 100000004",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: true,
            success: function (data, textStatus, xhr) {
                debugger
                var results = data;

                if (results.value.length != null && results.value.length > 0) {

                    for (var i = 0; i < results.value.length; i++) {
                        var urlRespOV = results.value[i]["bso_bso_parametro_systemuser@odata.nextLink"];
                        var urlRespVertical = results.value[i]["bso_bso_parametro_bso_usuariovertical@odata.nextLink"];
                        //RESPONSAVEL OV
                        if (urlRespOV != null) {
                            $.ajax({
                                type: "GET",
                                contentType: "application/json; charset=utf-8",
                                datatype: "json",
                                url: urlRespOV,
                                beforeSend: function (XMLHttpRequest) {
                                    XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                    XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                    XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                                },
                                async: true,
                                success: function (data1, textStatus, xhr) {
                                    var results1 = data1;
                                    debugger
                                    if (results1.value.length != null && results1.value.length > 0) {
                                        var arr1 = [];
                                        var arrSource1 = [];
                                        for (var i = 0; i < results1.value.length; i++) {

                                            var UserOV = {
                                                name: results1.value[i]["fullname"],
                                                userid: results1.value[i]["systemuserid"]
                                            }

                                            arr1.push(UserOV);
                                            arrSource1.push({ label: UserOV.name, value: UserOV.userid });
                                        }
                                        $("input#responsible-" + row).attr("src-length", results1.value.length);
                                        $("input#responsible-" + row).autocomplete({
                                            source: arrSource1,
                                            classes: {
                                                "ui-autocomplete": "highlight"
                                            },
                                            select: function (event, ui) {
                                                debugger
                                                $("input#" + event.target.id).attr("data-id", ui.item.value)
                                                $("input#" + event.target.id).val(ui.item.label)
                                                $("input#" + event.target.id).focus()
                                                return false;
                                            }
                                        });

                                        $("div#responsible" + row).show()
                                        $("#loadingimg1-" + row).hide()
                                        $("input#responsible-" + row).prop("disabled", false);

                                    } else {
                                        debugger
                                        $("#informativo p").text("")
                                        $("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-warning")
                                        $("#informativo p").text("Não foram encontrados responsáveis da organização para liberação de desconto informada.")
                                        $("input#responsible-" + row).text("");
                                        $("#informativo").show().delay(5000).fadeOut();
                                        $("div#responsible" + row).show()
                                        $("#loadingimg" + row).hide()
                                    }

                                },
                                error: function (xhr, textStatus, errorThrown) {
                                    Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                                }
                            });
                        } else {
                            $("div#responsible" + row).show()
                            $("input#responsible-" + row).prop("disabled", true);
                            $("input#responsible-" + row).text("");
                            $("#loadingimg1-" + row).hide()
                        }

                        debugger
                        //RESPONSAVEL VERTICAL
                        if (urlRespVertical != null) {
                            $.ajax({
                                type: "GET",
                                contentType: "application/json; charset=utf-8",
                                datatype: "json",
                                url: urlRespVertical,
                                beforeSend: function (XMLHttpRequest) {
                                    XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                    XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                    XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                                },
                                async: true,
                                success: function (data2, textStatus, xhr) {
                                    var results2 = data2;
                                    debugger
                                    if (results2.value.length != null && results2.value.length > 0) {
                                        var arr2 = [];
                                        var arrSource2 = [];
                                        for (var i = 0; i < results2.value.length; i++) {

                                            var UserVertical = {
                                                email: results2.value[i]["bso_email"],
                                                name: results2.value[i]["bso_name"],
                                                userid: results2.value[i]["bso_usuarioverticalid"]
                                            }
                                            arr2.push(UserVertical)
                                            arrSource2.push({ label: UserVertical.name, value: UserVertical.userid });
                                        }
                                        $("input#responsible-vert-" + row).attr("src-length", results2.value.length);
                                        $("input#responsible-vert-" + row).autocomplete({
                                            source: arrSource2,
                                            select: function (event, ui) {
                                                debugger
                                                $("input#" + event.target.id).attr("data-id", ui.item.value)
                                                $("input#" + event.target.id).val(ui.item.label)
                                                $("input#" + event.target.id).focus()
                                                return false;
                                            }
                                        });


                                        $("div#responsible-vert" + row).show()
                                        $("#loadingimg2-" + row).hide()
                                        $("input#responsible-vert-" + row).prop("disabled", false);
                                    } else {
                                        debugger
                                        $("#informativo p").text("")
                                        $("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-warning")
                                        $("#informativo p").text("Não foram encontrados responsáveis externos para liberação de desconto informado.")
                                        $("#informativo").show().delay(5000).fadeOut();
                                        $("div#responsible-vert" + row).show()
                                        $("input#responsible-vert-" + row).prop("disabled", true);
                                        $("input#responsible-vert-" + row).text("");
                                        $("#loadingimg2-" + row).hide()
                                    }

                                },
                                error: function (xhr, textStatus, errorThrown) {
                                    Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                                }
                            });
                        } else {
                            $("div#responsible-vert" + row).show()
                            $("input#responsible-vert-" + row).prop("disabled", true);
                            $("input#responsible-vert-" + row).text("");
                            $("#loadingimg2-" + row).hide()
                        }

                    }
                }
                else {
                    debugger
                    $("#informativo p").text("")
                    $("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-danger")
                    $("#informativo p").text("Não foram encontrados responsáveis para liberação de desconto informado.")
                    $("#informativo").show().delay(5000).fadeOut();
                    $("div#responsible" + row).show()
                    $("input#responsible-" + row).prop("disabled", true);
                    $("input#responsible-" + row).val("");
                    $("#loadingimg1-" + row).hide()
                    $("input#discount" + row).val("")
                    $("div#responsible-vert" + row).show()
                    $("input#responsible-vert-" + row).prop("disabled", true);
                    $("input#responsible-vert-" + row).val("");
                    $("#loadingimg2-" + row).hide()

                    return
                }

            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });
    },
    verificarResponsavelOnChange: function (id) {
        debugger
        if ($("input#responsible-" + id).val() == "" && $("input#responsible-vert-" + id).attr("src-lenght") != 0)
            $("input#responsible-vert-" + id).prop("disabled", false)
        else
            $("input#responsible-vert-" + id).prop("disabled", true)
    },
    verificarResponsavelVertOnChange: function (id,td) {
        debugger
        if ($("input#responsible-vert-" + id).val() == "" && $("input#responsible-" + id).attr("src-lenght") != 0)
            $("input#responsible-" + id).prop("disabled", false)
        else
            $("input#responsible-" + id).prop("disabled", true)
    },
    checkAll: function () {
        debugger
        if ($("#select-all").is(':checked')) {
            $("input:checkbox").prop('checked', true);
        } else {
            $("input:checkbox").prop('checked', false);
        }
    },
    selectdiscount: function (row, evt) {
        debugger
        $("input#responsible-" + row).val("");
        $("input#responsible-vert-" + row).val("");
        $("input#responsible-" + row).autocomplete();
        $("input#responsible-" + row).attr("src-length", 0)
        $("input#responsible-" + row).attr("data-id","")
        $("input#responsible-vert-" + row).autocomplete();
        $("input#responsible-vert-" + row).attr("src-length", 0)
        $("input#responsible-vert-" + row).attr("data-id","")

        var charCode = (evt.which) ? evt.which : event.keyCode
        var key = $.isNumeric(evt.key) == true ? evt.key : "";
        var value = $("input#discount" + row).val() == "" ? key : $("input#discount" + row).val() + key;
        if (value == "") return;
        var dotcontains = value.indexOf(".") != -1;
        if (dotcontains)
            if (charCode == 46) value = 0;
        if (charCode == 46) return;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            $("input#discount" + row).val("");
            $("input#discount" + row).text("")
            return
        }
        if (value > 100 || value < 0) {
            $("input#discount" + row).val("")
            $("input#discount" + row).text("")
            return
        }

        $("div#responsible" + row).hide()
        $("div#responsible-vert" + row).hide()
        $("#loadingimg1-" + row).show()
        $("#loadingimg2-" + row).show()

        var desconto = value;

        if (desconto != null && desconto != "")
			
			//------------ Obter listagem de todas as equipes do Ger. de Cotação (INÍCIO) ------------
			var gerCotacaoID = Xrm.Page.getAttribute("bso_gerente_cotacao").getValue()[0].id;
			var regiao1 = false;
			var regiao2 = false;
			
			$.ajax({
				type: "GET",
				contentType: "application/json; charset=utf-8",
				datatype: "json",
				url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers?$expand=teammembership_association($select=name, teamid)&$filter=systemuserid eq " + gerCotacaoID + ",
				beforeSend: function (XMLHttpRequest) {
					XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
					XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
					XMLHttpRequest.setRequestHeader("Accept", "application/json");
					XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
				},
				async: true,
				success: function (data, textStatus, xhr) {
					debugger
					var results = data;
					if (results.value.length != null && results.value.length > 0) {
						for (var i = 0; i < results.value.length; i++) {
							var urlEquipes = results.value[i]["teammembership_association@odata.nextLink"];
							if (urlEquipes != null) {
								$.ajax({
									type: "GET",
									contentType: "application/json; charset=utf-8",
									datatype: "json",
									url: urlEquipes,
									beforeSend: function (XMLHttpRequest) {
										XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
										XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
										XMLHttpRequest.setRequestHeader("Accept", "application/json");
										XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
									},
									async: true,
									success: function (data1, textStatus, xhr) {
										var results1 = data1;
										debugger
										if (results1.value.length != null && results1.value.length > 0) {
											var arr1 = [];
											var arrSource1 = [];
											for (var i = 0; i < results1.value.length; i++) {

												var equipe = {
													name: results1.value[i]["name"],
													id: results1.value[i]["teamid"]
												}
												
												if (results1.value[i]["name"].trim() == "Região I" || results1.value[i]["name"].trim() == "Região I - Custom"){
													regiao1 = true;
												}
												else if (results1.value[i]["name"].trim() == "Região II" || results1.value[i]["name"].trim() == "Região II - Custom"){
													regiao2 = true;
												}
												
												arr1.push(equipe);
												arrSource1.push({ label: equipe.name, value: equipe.id });
											}
											
											arrEquipes = arrSource1;
										}
									},
									error: function (xhr, textStatus, errorThrown) {
										Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
									}
								});
							}
						}
					}
				},
				error: function (xhr, textStatus, errorThrown) {
					Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
				}
			});
			//------------ Obter listagem de todas as equipes do Ger. de Cotação (FIM) ------------
			
			
			//------------ Se Ger. Cotação pertence à Região 1 (INÍCIO) ------------
			
			if (regiao1){
				$.ajax({
					type: "GET",
					contentType: "application/json; charset=utf-8",
					datatype: "json",
					url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_parametros?$expand=bso_bso_parametro_bso_usuariovertical($select=bso_email,bso_name,bso_usuarioverticalid),bso_bso_parametro_systemuser($select=fullname,systemuserid))&$filter=bso_descontoate ge " + desconto + " and bso_descontode le " + desconto + " and bso_tipodeparametro eq 100000003 and bso_name contains 'Região 1'"",
					beforeSend: function (XMLHttpRequest) {
						XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
						XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
						XMLHttpRequest.setRequestHeader("Accept", "application/json");
						XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
					},
					async: true,
					success: function (data, textStatus, xhr) {
						debugger
						var results = data;
						if (results.value.length != null && results.value.length > 0) {
							for (var i = 0; i < results.value.length; i++) {
								var urlRespOV = results.value[i]["bso_bso_parametro_systemuser@odata.nextLink"];
								var urlRespVertical = results.value[i]["bso_bso_parametro_bso_usuariovertical@odata.nextLink"];
								//RESPONSAVEL OV
								if (urlRespOV != null) {
									$.ajax({
										type: "GET",
										contentType: "application/json; charset=utf-8",
										datatype: "json",
										url: urlRespOV,
										beforeSend: function (XMLHttpRequest) {
											XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
											XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
											XMLHttpRequest.setRequestHeader("Accept", "application/json");
											XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
										},
										async: true,
										success: function (data1, textStatus, xhr) {
											var results1 = data1;
											debugger
											if (results1.value.length != null && results1.value.length > 0) {
												var arr1 = [];
												var arrSource1 = [];
												for (var i = 0; i < results1.value.length; i++) {

													var UserOV = {
														name: results1.value[i]["fullname"],
														userid: results1.value[i]["systemuserid"]
													}

													arr1.push(UserOV);
													arrSource1.push({ label: UserOV.name, value: UserOV.userid });
												}
												$("input#responsible-" + row).attr("src-length", results1.value.length )
												$("input#responsible-" + row).autocomplete({
													source: arrSource1,
													classes: {
														"ui-autocomplete": "highlight"
													},
													select: function (event, ui) {
														debugger
														$("input#" + event.target.id).attr("data-id", ui.item.value)
														$("input#" + event.target.id).val(ui.item.label)
														$("input#" + event.target.id).focus()
														return false;
													}
												});

												$("div#responsible" + row).show()
												$("#loadingimg1-" + row).hide()
												$("input#responsible-" + row).prop("disabled", false);

											} else {
												debugger
												$("#informativo p").text("")
												$("input#responsible-" + row).attr("src-length", 0)
												$("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-warning")
												$("#informativo p").text("Não foram encontrados responsáveis da organização para liberação de desconto informada.")
												$("input#responsible-" + row).text("");
												$("#informativo").show().delay(5000).fadeOut();
												$("div#responsible" + row).show()
												$("#loadingimg" + row).hide()
											}

										},
										error: function (xhr, textStatus, errorThrown) {
											Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
										}
									});
								} else {
									$("div#responsible" + row).show()
									$("input#responsible-" + row).prop("disabled", true);
									$("input#responsible-" + row).text("");
									$("#loadingimg1-" + row).hide()
								}

								debugger
								//RESPONSAVEL VERTICAL
								if (urlRespVertical != null) {
									$.ajax({
										type: "GET",
										contentType: "application/json; charset=utf-8",
										datatype: "json",
										url: urlRespVertical,
										beforeSend: function (XMLHttpRequest) {
											XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
											XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
											XMLHttpRequest.setRequestHeader("Accept", "application/json");
											XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
										},
										async: true,
										success: function (data2, textStatus, xhr) {
											var results2 = data2;
											debugger
											if (results2.value.length != null && results2.value.length > 0) {
												var arr2 = [];
												var arrSource2 = [];
												for (var i = 0; i < results2.value.length; i++) {

													var UserVertical = {
														email: results2.value[i]["bso_email"],
														name: results2.value[i]["bso_name"],
														userid: results2.value[i]["bso_usuarioverticalid"]
													}
													arr2.push(UserVertical)
													arrSource2.push({ label: UserVertical.name, value: UserVertical.userid });
												}
												$("input#responsible-vert-" + row).attr("src-length", results2.value.length)
												$("input#responsible-vert-" + row).autocomplete({
													source: arrSource2,
													select: function (event, ui) {
														debugger
														$("input#" + event.target.id).attr("data-id", ui.item.value)
														$("input#" + event.target.id).val(ui.item.label)
														$("input#" + event.target.id).focus()
														return false;
													}
												});


												$("div#responsible-vert" + row).show()
												$("#loadingimg2-" + row).hide()
												$("input#responsible-vert-" + row).prop("disabled", false);
											} else {
												debugger
												$("#informativo p").text("")
												$("input#responsible-vert-" + row).attr("src-length", 0)
												$("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-warning")
												$("#informativo p").text("Não foram encontrados responsáveis externos para liberação de desconto informado.")
												$("#informativo").show().delay(5000).fadeOut();
												$("div#responsible-vert" + row).show()
												$("input#responsible-vert-" + row).prop("disabled", true);
												$("input#responsible-vert-" + row).text("");
												$("#loadingimg2-" + row).hide()
											}

										},
										error: function (xhr, textStatus, errorThrown) {
											Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
										}
									});
								} else {
									$("div#responsible-vert" + row).show()
									$("input#responsible-vert-" + row).prop("disabled", true);
									$("input#responsible-vert-" + row).text("");
									$("#loadingimg2-" + row).hide()
								}

							}
						}
						else {
							debugger
							$("#informativo p").text("")
							$("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-danger")
							$("#informativo p").text("Não foram encontrados responsáveis para liberação de desconto informado.")
							$("#informativo").show().delay(5000).fadeOut();
							$("div#responsible" + row).show()
							$("input#responsible-" + row).prop("disabled", true);
							$("input#responsible-" + row).val("");
							$("#loadingimg1-" + row).hide()
							$("input#discount" + row).val("")
							$("div#responsible-vert" + row).show()
							$("input#responsible-vert-" + row).prop("disabled", true);
							$("input#responsible-vert-" + row).val("");
							$("#loadingimg2-" + row).hide()

							return
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
					}
				});
			}
			
			//------------ Se Ger. Cotação pertence à Região 1 (FIM) ------------
			
			
			//------------ Se Ger. Cotação pertence à Região 2 (INÍCIO) ------------
			
			if (regiao2){
				$.ajax({
					type: "GET",
					contentType: "application/json; charset=utf-8",
					datatype: "json",
					beforeSend: function (XMLHttpRequest) {
					url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_parametros?$expand=bso_bso_parametro_bso_usuariovertical($select=bso_email,bso_name,bso_usuarioverticalid),bso_bso_parametro_systemuser($select=fullname,systemuserid))&$filter=bso_descontoate ge " + desconto + " and bso_descontode le " + desconto + " and bso_tipodeparametro eq 100000003 and bso_name contains 'Região 2'",
						XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
						XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
						XMLHttpRequest.setRequestHeader("Accept", "application/json");
						XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
					},
					async: true,
					success: function (data, textStatus, xhr) {
						debugger
						var results = data;
						if (results.value.length != null && results.value.length > 0) {
							for (var i = 0; i < results.value.length; i++) {
								var urlRespOV = results.value[i]["bso_bso_parametro_systemuser@odata.nextLink"];
								var urlRespVertical = results.value[i]["bso_bso_parametro_bso_usuariovertical@odata.nextLink"];
								//RESPONSAVEL OV
								if (urlRespOV != null) {
									$.ajax({
										type: "GET",
										contentType: "application/json; charset=utf-8",
										datatype: "json",
										url: urlRespOV,
										beforeSend: function (XMLHttpRequest) {
											XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
											XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
											XMLHttpRequest.setRequestHeader("Accept", "application/json");
											XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
										},
										async: true,
										success: function (data1, textStatus, xhr) {
											var results1 = data1;
											debugger
											if (results1.value.length != null && results1.value.length > 0) {
												var arr1 = [];
												var arrSource1 = [];
												for (var i = 0; i < results1.value.length; i++) {

													var UserOV = {
														name: results1.value[i]["fullname"],
														userid: results1.value[i]["systemuserid"]
													}

													arr1.push(UserOV);
													arrSource1.push({ label: UserOV.name, value: UserOV.userid });
												}
												$("input#responsible-" + row).attr("src-length", results1.value.length )
												$("input#responsible-" + row).autocomplete({
													source: arrSource1,
													classes: {
														"ui-autocomplete": "highlight"
													},
													select: function (event, ui) {
														debugger
														$("input#" + event.target.id).attr("data-id", ui.item.value)
														$("input#" + event.target.id).val(ui.item.label)
														$("input#" + event.target.id).focus()
														return false;
													}
												});

												$("div#responsible" + row).show()
												$("#loadingimg1-" + row).hide()
												$("input#responsible-" + row).prop("disabled", false);

											} else {
												debugger
												$("#informativo p").text("")
												$("input#responsible-" + row).attr("src-length", 0)
												$("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-warning")
												$("#informativo p").text("Não foram encontrados responsáveis da organização para liberação de desconto informada.")
												$("input#responsible-" + row).text("");
												$("#informativo").show().delay(5000).fadeOut();
												$("div#responsible" + row).show()
												$("#loadingimg" + row).hide()
											}

										},
										error: function (xhr, textStatus, errorThrown) {
											Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
										}
									});
								} else {
									$("div#responsible" + row).show()
									$("input#responsible-" + row).prop("disabled", true);
									$("input#responsible-" + row).text("");
									$("#loadingimg1-" + row).hide()
								}

								debugger
								//RESPONSAVEL VERTICAL
								if (urlRespVertical != null) {
									$.ajax({
										type: "GET",
										contentType: "application/json; charset=utf-8",
										datatype: "json",
										url: urlRespVertical,
										beforeSend: function (XMLHttpRequest) {
											XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
											XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
											XMLHttpRequest.setRequestHeader("Accept", "application/json");
											XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
										},
										async: true,
										success: function (data2, textStatus, xhr) {
											var results2 = data2;
											debugger
											if (results2.value.length != null && results2.value.length > 0) {
												var arr2 = [];
												var arrSource2 = [];
												for (var i = 0; i < results2.value.length; i++) {

													var UserVertical = {
														email: results2.value[i]["bso_email"],
														name: results2.value[i]["bso_name"],
														userid: results2.value[i]["bso_usuarioverticalid"]
													}
													arr2.push(UserVertical)
													arrSource2.push({ label: UserVertical.name, value: UserVertical.userid });
												}
												$("input#responsible-vert-" + row).attr("src-length", results2.value.length)
												$("input#responsible-vert-" + row).autocomplete({
													source: arrSource2,
													select: function (event, ui) {
														debugger
														$("input#" + event.target.id).attr("data-id", ui.item.value)
														$("input#" + event.target.id).val(ui.item.label)
														$("input#" + event.target.id).focus()
														return false;
													}
												});


												$("div#responsible-vert" + row).show()
												$("#loadingimg2-" + row).hide()
												$("input#responsible-vert-" + row).prop("disabled", false);
											} else {
												debugger
												$("#informativo p").text("")
												$("input#responsible-vert-" + row).attr("src-length", 0)
												$("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-warning")
												$("#informativo p").text("Não foram encontrados responsáveis externos para liberação de desconto informado.")
												$("#informativo").show().delay(5000).fadeOut();
												$("div#responsible-vert" + row).show()
												$("input#responsible-vert-" + row).prop("disabled", true);
												$("input#responsible-vert-" + row).text("");
												$("#loadingimg2-" + row).hide()
											}

										},
										error: function (xhr, textStatus, errorThrown) {
											Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
										}
									});
								} else {
									$("div#responsible-vert" + row).show()
									$("input#responsible-vert-" + row).prop("disabled", true);
									$("input#responsible-vert-" + row).text("");
									$("#loadingimg2-" + row).hide()
								}

							}
						}
						else {
							debugger
							$("#informativo p").text("")
							$("#informativo").removeClass("alert-danger").removeClass("alert-warning").addClass("alert-danger")
							$("#informativo p").text("Não foram encontrados responsáveis para liberação de desconto informado.")
							$("#informativo").show().delay(5000).fadeOut();
							$("div#responsible" + row).show()
							$("input#responsible-" + row).prop("disabled", true);
							$("input#responsible-" + row).val("");
							$("#loadingimg1-" + row).hide()
							$("input#discount" + row).val("")
							$("div#responsible-vert" + row).show()
							$("input#responsible-vert-" + row).prop("disabled", true);
							$("input#responsible-vert-" + row).val("");
							$("#loadingimg2-" + row).hide()

							return
						}
					},
					error: function (xhr, textStatus, errorThrown) {
						Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
					}
				});
			}
			
			//------------ Se Ger. Cotação pertence à Região 2 (FIM) ------------
			
            

    },
    showTextArea: function (trId) {

        debugger
        var id = "#TRDID" + trId;
        if ($(id).is(":visible") == true) {
            $(id).hide()
        } else {
            $(id).show()
        }

    },
    RetornarCotacoes: async function (id) {
        debugger
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/quotes?$select=name,_opportunityid_value,quoteid,quotenumber,totalamount,totaldiscountamount&$filter=_opportunityid_value eq " + id,
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: false,
            success: function (data, textStatus, xhr) {
                debugger
                var results = data;
                var arr = [];
                for (var i = 0; i < results.value.length; i++) {
                    formatedObject = {
                        name: results.value[i]["name"],
                        _opportunityid_value: results.value[i]["_opportunityid_value"],
                        _opportunityid_value_formatted: results.value[i]["_opportunityid_value@OData.Community.Display.V1.FormattedValue"],
                        _opportunityid_value_lookuplogicalname: results.value[i]["_opportunityid_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        quoteid: results.value[i]["quoteid"],
                        quotenumber: results.value[i]["quotenumber"],
                        totalamount: results.value[i]["totalamount"],
                        totalamount_formatted: results.value[i]["totalamount@OData.Community.Display.V1.FormattedValue"],
                        totaldiscountamount: results.value[i]["totaldiscountamount"],
                        totaldiscountamount_formatted: results.value[i]["totaldiscountamount@OData.Community.Display.V1.FormattedValue"]
                    }
                    arr.push(formatedObject);
                }
                bradescoseguros.corp_solicitar_aprovacao_cotacao.MontaTabelaCotacao(arr);
            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });

    }
}
$(document).ready(function () {
    console.log("teste OK")
    bradescoseguros.corp_solicitar_aprovacao_cotacao.carregarListaCotacoes();
    debugger
    $("th").css("border-bottom-color", "darkred")
})

