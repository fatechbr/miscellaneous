﻿var entity = "phonecall";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_phonecall) === "undefined") { bradescoseguros.corp_phonecall = {}; }

bradescoseguros.corp_phonecall = {
    onload: function (event) {
        context = event.getFormContext();
        debugger
        //add on change
        context.getAttribute("regardingobjectid").addOnChange(bradescoseguros.corp_phonecall.getphone);
    },
    onsave: function (event) {
        context = event.getFormContext();
        debugger
        var savemode = event.getEventArgs().getSaveMode();
        if (savemode == 58 || savemode == 5) //Close activity event
        {
            var today = new Date();
            if (context.getAttribute("scheduledend").getValue() < today) {
                if (context.getAttribute("description").getValue() == "" || context.getAttribute("description").getValue() == null || context.getAttribute("description").getValue() == undefined) {
                    bradescoseguros.corp_common.message.alertasync("M_A_1000008");
                    event.getEventArgs().preventDefault();
                    return
                }
            }
        }
    },
    getphone: function () {

        context.getAttribute("phonenumber").setValue("");

        var id = context.getAttribute("regardingobjectid").getValue()[0].id.replace("{", "").replace("}", "");
        switch (context.getAttribute("regardingobjectid").getValue()[0].entityType) {
            case "account":

                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + id + ")?$select=telephone1", true);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {

                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            debugger
                            var result = JSON.parse(this.response);
                            if (result["telephone1"] != null && result["telephone1"] != "") {
                                var telephone1 = result["telephone1"];
                                context.getAttribute("phonenumber").setValue(telephone1)
                            } else {
                                bradescoseguros.corp_common.message.alertasync("M_A_1000009");
                            }
                        } 
                    }
                };
                req.send();

                break;
            case "contact":
                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts(" + id + ")?$select=telephone1", true);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                   
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            debugger
                            var result = JSON.parse(this.response);
                            if (result["telephone1"] != null && result["telephone1"] != "") {
                                var telephone1 = result["telephone1"];
                                context.getAttribute("phonenumber").setValue(telephone1)
                            } else {
                                bradescoseguros.corp_common.message.alertasync("M_A_1000009");
                            }
                        }
                    }
                };
                req.send();
                break;

            
            default:
                break;
        }



    }
}