/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />


var entity = "opportunities";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_opportunity_ribbon) === "undefined") { bradescoseguros.corp_opportunity_ribbon = {}; }

bradescoseguros.corp_opportunity_ribbon = {

    chamadaEmissaoExpressa: async function () {

        debugger;

        if ((Xrm.Page.getAttribute("bso_produto").getValue() != null) &&
            (Xrm.Page.getAttribute("bso_subproduto").getValue() != null) &&
            (Xrm.Page.getAttribute("customerid").getValue() != null) &&
            (Xrm.Page.getAttribute("bso_corretora").getValue() != null) &&
            (Xrm.Page.getAttribute("ownerid").getValue() != null) &&
            (Xrm.Page.getAttribute("bso_sucursal").getValue() != null)) {
            if (Xrm.Page.getAttribute("bso_numero_do_estudo").getValue() != null &&
                Xrm.Page.getAttribute("bso_numero_do_estudo").getValue() != "") {

                var numero = Xrm.Page.getAttribute("bso_numero_do_estudo").getValue();
                Alert.show("Emitir um novo estudo?", "Já existe um estudo para essa oportunidade.", [
                    new Alert.Button("Criar Emissao", function () {

                        bradescoseguros.corp_opportunity_ribbon.criaremissao();


                    }, true, true),
                    new Alert.Button("Agora não")
                ], "QUESTION", 500, 200);
            }
            else {
                bradescoseguros.corp_opportunity_ribbon.criaremissao();
            }
        } else
            Alert.show("ERRO", "Preencher os campos obrigatórios antes de acionar o botão da Emissão.", null, "ERROR", 400, 200);
    },

    criaremissao: async function (parameters) {
        var accounts = await bradescoseguros.corp_opportunity_ribbon.accountRequest();
        var corretoras = await bradescoseguros.corp_opportunity_ribbon.corretoraRequest();
        var usuarios = await bradescoseguros.corp_opportunity_ribbon.usuarioRequest();
        var sucursal = await bradescoseguros.corp_opportunity_ribbon.sucursalRequest();
        var Id = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');

        var parameters = {};
        if (accounts.bso_cnpj != null && accounts.bso_cnpj != "") {

            
            parameters.numeroMatricula = usuarios.bso_matricula;
            parameters.sucursal = sucursal.camp_codigosucursal;
            parameters.corretora = corretoras.bso_cnpj.slice(1);
            parameters.tipoProduto = Xrm.Page.getAttribute("bso_produto").getValue();
            parameters.subProduto = Xrm.Page.getAttribute("bso_subproduto").getValue();
            parameters.cnpj = accounts.bso_cnpj;
            parameters.numeroOportunidade = Xrm.Page.getAttribute("bso_opportunitycode").getValue();
        }

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            data: JSON.stringify(parameters),
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/opportunities(" + Id + ")/Microsoft.Dynamics.CRM.bso_ChamarEmissaoExpressa",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
            },
            async: true,
            success: function (data, textStatus, xhr) {
                Xrm.Page.getAttribute("bso_numero_do_estudo").setValue(xhr.responseJSON.numeroEstudo);
                Alert.show("SUCESSO", "Estudo nº " + xhr.responseJSON.numeroEstudo + " criado com sucesso!", null, "SUCCESS", 350, 200);
                //return xhr.responseJSON.numeroEstudo;
            },
            error: function (xhr, textStatus, errorThrown) {
                Alert.show("ERRO", xhr.responseJSON.error.message, null, "ERROR", 400, 200);
                //return xhr.responseJSON.error.message;
            }
        });
    },

    accountRequest: async function () {

        var idDaConta = Xrm.Page.getAttribute("customerid").getValue()[0].id.replace("{", "").replace("}", "");
        var entity = "accounts(" + idDaConta + ")";
        var option = "select=bso_cnpj,name";
        var accounts = await bradescoseguros.corp_xmlhttprequest.getasync(entity, option);

        return JSON.parse(accounts);

    },

    corretoraRequest: async function () {

        var idcorretora = Xrm.Page.getAttribute("bso_corretora").getValue()[0].id.replace("{", "").replace("}", "");
        var entity = "bso_corretoras(" + idcorretora + ")";
        var option = "select=bso_succpd,bso_sucursal,bso_cnpj";

        var corretoras = await bradescoseguros.corp_xmlhttprequest.getasync(entity, option);

        return JSON.parse(corretoras);
    },

    usuarioRequest: async function () {

        var idusuario = Xrm.Page.getAttribute("ownerid").getValue()[0].id.replace("{", "").replace("}", "");
        var entity = "systemusers(" + idusuario + ")";
        var option = "select=bso_matricula";

        var usuarios = await bradescoseguros.corp_xmlhttprequest.getasync(entity, option);

        return JSON.parse(usuarios);

    },
    sucursalRequest: async function () {

        var idsucursal = Xrm.Page.getAttribute("bso_sucursal").getValue()[0].id.replace("{", "").replace("}", "");
        var entity = "camp_sucursals(" + idsucursal + ")";
        var option = "select=camp_codigosucursal";
        var oportunidades = await bradescoseguros.corp_xmlhttprequest.getasync(entity, option);

        return JSON.parse(oportunidades);
    }
}