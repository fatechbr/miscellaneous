﻿var entity = "task";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_task) === "undefined") { bradescoseguros.corp_task = {}; }

bradescoseguros.corp_task = {
    onsave: function (event) {
        context = event.getFormContext();
        debugger
        var savemode = event.getEventArgs().getSaveMode();
        if (savemode == 58 || savemode == 5 ) //Close activity event
        {
            var today = new Date();
            if (context.getAttribute("scheduledend").getValue() < today) {
                if (context.getAttribute("description").getValue() == "" || context.getAttribute("description").getValue() == null || context.getAttribute("description").getValue() == undefined) {
                    bradescoseguros.corp_common.message.alertasync("M_A_1000008");
                    event.getEventArgs().preventDefault();
                    return
                }
            }
        }
    }
}