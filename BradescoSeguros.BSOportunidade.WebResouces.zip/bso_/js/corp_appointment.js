var entity = "appointment";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_appointment) === "undefined") { bradescoseguros.corp_appointment = {}; }

bradescoseguros.corp_appointment = {
    onload: function (event) {
        debugger
        context = event.getFormContext();

        if (context.getControl("regardingobjectid") !== null && context.getAttribute("regardingobjectid").getValue() !== null) {
            var regardingobjectid = context.getAttribute("regardingobjectid").getValue()[0].id.replace("{", "").replace("}", "");
            var clientURL = context.context.getClientUrl();
            var req = new XMLHttpRequest();
            var query = "/api/data/v8.2/opportunities(" + regardingobjectid + ")?$select=bso_canal";
            req.open("GET", encodeURI(clientURL + query), true);
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json;charset=utf-8");
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.onreadystatechange = function () {
                if (this.readyState == 4) {
                    req.onreadystatechange = null;
                    if (this.status == 200) {
                        var data = JSON.parse(this.response);

                        var today = new Date();
                        if (context.getAttribute("scheduledend").getValue() < today && data && data.bso_canal === 861500002) {
                            if (context.getAttribute("description").getValue() === "" || context.getAttribute("description").getValue() === null || context.getAttribute("description").getValue() === undefined) {
                                bradescoseguros.corp_common.message.alertasync("M_A_1000008");
                                context.getAttribute("description").setRequiredLevel("required");
                            }
                        }
                    }
                    else {
                        var error = JSON.parse(this.response).error; 
                    }
                }
            };
            req.send();
        }
    }    
}