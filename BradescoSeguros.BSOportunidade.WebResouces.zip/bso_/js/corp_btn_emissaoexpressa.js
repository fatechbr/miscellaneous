/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />


if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_btn_emissaoexpressa) === "undefined") { bradescoseguros.corp_btn_emissaoexpressa = {}; }



bradescoseguros.corp_btn_emissaoexpressa = {

    showemissaoexpressa: function () {
        debugger;
        
var temp = window.open("http://www.bradseg.com.br/login-publique/bs-valida-login-AD.asp?forward-url-sucesso=http://www.bradseg.com.br/admin_frames.asp?URL=http://www.bradseg.com.br/Minhas_Aplicacoes.asp", "MsgWindow", "width=1000,height=900");

setTimeout(function() {
    temp.close();

setTimeout(function() {
    window.open("http://www.bradseg.com.br/admin_frames.asp?URL=http://www3.bradseg.com.br/saude/intranet.asp?aplicacao=EEE_SOLICITACAO_ESTUDO&CodAplicacao=1010&Rodape=True&Tela=False", "MsgWindow", "width=1000,height=900");
    }, 500);
    

    }, 1000);
    


    }

}