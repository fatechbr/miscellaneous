﻿/// <reference path="common/xmlhttprequest.js" />
/// <reference path="common/oauth.js" />

var entity = "accounts";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_accounts) === "undefined") { bradescoseguros.corp_accounts = {}; }



bradescoseguros.corp_accounts = {
    onload: function () {
        debugger;

        Xrm.Page.getAttribute("bso_cnpj").setSubmitMode("never");

        bradescoseguros.corp_common.cnpj.mask_cnpj("bso_cnpj");
        
        //add on change
        Xrm.Page.getAttribute("bso_cnpj").addOnChange(bradescoseguros.corp_accounts.checkdocument);
        Xrm.Page.getAttribute("bso_cnpj").addOnChange(bradescoseguros.corp_accounts.cnpjmask);

    },

    cnpjmask: function () {
        bradescoseguros.corp_common.cnpj.mask_cnpj("bso_cnpj");
    },

    onsave: function (context) {
        debugger;

        var eventArgs = context.getEventArgs();

        bradescoseguros.corp_accounts.prevent_save(eventArgs);

    },

    prevent_save: function (eventArgs) {


        //deactivate
        if (eventArgs.getSaveMode() == 5) {
            var id = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
            var opp = bradescoseguros.corp_opportunities.getbyaccount(id, false);

            if (opp !== null) {
                bradescoseguros.corp_common.message.alertasync("M_A_1000006");
                eventArgs.preventDefault();
            }
        }


    },

    /// * Verifica o campo CNPJ
    /// ** Caso o CNPJ exista na base do CRM 
    checkdocument: async function () {
        Xrm.Page.getAttribute("bso_cnpj").setSubmitMode("always");

        var cnpj = Xrm.Page.getAttribute("bso_cnpj").getValue();

        if (cnpj == "" || cnpj == null)
            return;

        if (!bradescoseguros.corp_common.cnpj.validation_cnpj(cnpj)) {
            var message = await bradescoseguros.corp_common.message.get("M_A_1000000"); //CNPJ Inválido
            Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, 500, 250);
            Xrm.Page.getAttribute("bso_cnpj").setValue(null);
            return;
        }

        var accountid = await bradescoseguros.corp_accounts.get_cnpj(cnpj);

        if (accountid !== null) {
            var id = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
            if (accountid.accountid !== id) {
                var message = await bradescoseguros.corp_common.message.get("M_A_1000002"); //CNPJ já existe
                Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, 500, 250);
                Xrm.Page.getAttribute("bso_cnpj").setValue(null);

                window.open(Xrm.Page.context.getClientUrl() + "/main.aspx?etc=1&id=%7b" + accountid.accountid + "%7d&pagetype=entityrecord")
            }
            
        }


    },

    get_cnpj: async function (cnpj) {

        cnpj = cnpj.replace(/[^\d]+/g, '');

        var select = "select=";
        var selectparam = "accountid,name,bso_cnpj";

        select += selectparam;

        var filter = "filter="
        var filterparam = "bso_cnpj eq '" + cnpj + "'";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = await bradescoseguros.corp_xmlhttprequest.get("accounts", option);

        var json = JSON.parse(response);

        if (json.value.length > 0)
            return json.value[0];
        else
            return null;
    }
};