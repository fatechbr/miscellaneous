
if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_common) === "undefined") { bradescoseguros.corp_common = {}; }



bradescoseguros.corp_common.cnpj = {

    validation_cnpj: function (cnpj) {

        cnpj = cnpj.replace(/[^\d]+/g, '');

        if (cnpj == '') return false;

        if (cnpj.length != 14)
            return false;


        if (cnpj == "00000000000000" ||
            cnpj == "11111111111111" ||
            cnpj == "22222222222222" ||
            cnpj == "33333333333333" ||
            cnpj == "44444444444444" ||
            cnpj == "55555555555555" ||
            cnpj == "66666666666666" ||
            cnpj == "77777777777777" ||
            cnpj == "88888888888888" ||
            cnpj == "99999999999999")
            return false;

        // Valida DVs
        var lenght = cnpj.length - 2
        var numbers = cnpj.substring(0, lenght);
        var dig = cnpj.substring(lenght);
        var sum = 0;
        var pos = lenght - 7;
        for (i = lenght; i >= 1; i--) {
            sum += numbers.charAt(lenght - i) * pos--;
            if (pos < 2)
                pos = 9;
        }

        var result = sum % 11 < 2 ? 0 : 11 - sum % 11;
        if (result != dig.charAt(0))
            return false;

        lenght = lenght + 1;
        numbers = cnpj.substring(0, lenght);
        sum = 0;
        pos = lenght - 7;
        for (i = lenght; i >= 1; i--) {
            sum += numbers.charAt(lenght - i) * pos--;
            if (pos < 2)
                pos = 9;
        }
        result = sum % 11 < 2 ? 0 : 11 - sum % 11;
        if (result != dig.charAt(1))
            return false;

        return true;

    },
	
	 mask_cei: function (fieldname) {
        debugger;
        if (Xrm.Page.getAttribute(fieldname).getValue() == null)
            return;
		
		var cnpj = Xrm.Page.getAttribute(fieldname).getValue();
        var mask_cnpj = cnpj.substring(0, 2) + "." + cnpj.substring(2, 5) + (".") + cnpj.substring(5, 10) + ("/") + cnpj.substring(10, 12);
        
        Xrm.Page.getAttribute(fieldname).setValue(mask_cnpj);
    },

    mask_cnpj: function (fieldname) {
        debugger;
        if (Xrm.Page.getAttribute(fieldname).getValue() == null)
            return;

        var mask_cnpj = Xrm.Page.getAttribute(fieldname).getValue().replace(/[^\d]+/g, "").replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/g, "\$1.\$2.\$3\/\$4\-\$5");

        Xrm.Page.getAttribute(fieldname).setValue(mask_cnpj);
    }

};

bradescoseguros.corp_common.cpf = {

    validation_cpf: function (CPF) {
        CPF = CPF.replace(/[^\d]+/g, '');

        if (CPF == '') return false;

        if (CPF.length != 11)
            return false;


        if (CPF == "00000000000" ||
            CPF == "11111111111" ||
            CPF == "22222222222" ||
            CPF == "33333333333" ||
            CPF == "44444444444" ||
            CPF == "55555555555" ||
            CPF == "66666666666" ||
            CPF == "77777777777" ||
            CPF == "88888888888" ||
            CPF == "99999999999")
            return false;

        var sum = 0;
        for (i = 0; i < 9; i++) {
            sum += parseInt(CPF.charAt(i)) * (10 - i);
        }
        var r = 11 - (sum % 11);
        if (r == 10 || r == 11) {
            r = 0;
        }
        if (r != parseInt(CPF.charAt(9))) {
            return false;
        }
        sum = 0;
        for (i = 0; i < 10; i++) {
            sum += parseInt(CPF.charAt(i)) * (11 - i);
        }
        r = 11 - (sum % 11);
        if (r == 10 || r == 11) {
            r = 0;
        }
        if (r != parseInt(CPF.charAt(10))) {
            return false;
        }
        return true;
    },

    mask_cpf: function () {

        if (Xrm.Page.getAttribute("bso_cpf").getValue() == null)
            return;

        var mask_cpf = Xrm.Page.getAttribute("bso_cpf").getValue().replace(/[^\d]+/g, "").replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g, "\$1.\$2.\$3\-\$4");

        Xrm.Page.getAttribute("bso_cpf").setValue(mask_cpf);
    }

};

bradescoseguros.corp_common.lookup = {
    set: function (entityId, entityName, entityType, fieldName) {

        var lookupValue = new Array();

        lookupValue[0] = new Object();

        lookupValue[0].id = entityId;

        lookupValue[0].name = entityName;

        lookupValue[0].entityType = entityType;

        if (lookupValue[0].id !== null) {

            Xrm.Page.getAttribute(fieldName).setValue(lookupValue);

        }
    },

};

bradescoseguros.corp_common.message = {

    get: async function (messageid) {

        var select = "select=";
        var selectparam = "bso_name, bso_valor, bso_titulodamensagem, bso_tipodemensagem, bso_alturadopainel, bso_larguradopainel";

        select += selectparam;

        var filter = "filter="
        var filterparam = "bso_name eq '" + messageid + "'";

        filter += filterparam;

        var option = select + "&$" + filter;

        var response = await bradescoseguros.corp_xmlhttprequest.get("bso_parametros", option);

        var json = JSON.parse(response);

        if (json.value.length > 0)
            return json.value[0];
        else
            return alert("Erro não identificado!");
    },

    alertasync: async function (idmessage) {
        var message = await bradescoseguros.corp_common.message.get(idmessage); 
        Alert.show(message.bso_titulodamensagem, message.bso_valor, null, message.bso_tipodemensagem, message.bso_larguradopainel, message.bso_alturadopainel);
    },


};

bradescoseguros.corp_common.display = {

    set_display_properties: async function (fields, property) {
        for (var i = 0; i < fields.length; i++) {
            Xrm.Page.getControl(fields[i]).setVisible(property);
        }
    }

};

bradescoseguros.corp_common.user = {

    get_current_userid: function () {
        return Xrm.Page.context.getUserId().replace("{", "").replace("}", "").toLowerCase();
    }

};

bradescoseguros.corp_common.collapsed = {

    collapseBusinessProcess: function (){
        if (Xrm.Page.ui.process != null)
            Xrm.Page.ui.process.setDisplayState("collapsed");
    }

};