﻿/// <reference path="_corp_common.js" />
/// <reference path="_corp_xmlhttprequest.js" />


if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_concorrente) === "undefined") { bradescoseguros.corp_concorrente = {}; }

bradescoseguros.corp_concorrentes = {

    obterOportunidade: async function () {
        debugger

        var Xrm = window.parent.Xrm;
        var myId = Xrm.Page.data.entity.getId();
        var urlF = Xrm.Page.context.getClientUrl();
        myId = myId.replace("{","");
        myId = myId.replace("}","");
        var idString = myId.toString();
        if (idString != "") {            

            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/opportunities("+idString+")?$select=_customerid_value,opportunityid",
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                    XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                    XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                },
                async: true,
                success: function (data, textStatus, xhr) {
                    var result = data;
                    var _customerid_value = result["_customerid_value"];
                    var _customerid_value_formatted = result["_customerid_value@OData.Community.Display.V1.FormattedValue"];
                    var _customerid_value_lookuplogicalname = result["_customerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    var opportunityid = result["opportunityid"];

                    var idCustomer = _customerid_value.toString();

                    bradescoseguros.corp_concorrentes.obterConcorrentes(idCustomer);
                    // obterConcorrentes(opportunityid);

                },
                error: function (xhr, textStatus, errorThrown) {
                    Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                }
            });
        }
    },

    obterConcorrentes: async function (myId) {
        debugger

        var Xrm = window.parent.Xrm;

        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/bso_mapeamento_dos_produtos_corporates?$select=bso_mapeamento_dos_produtos_corporateid,bso_aniversario,_bso_cliente_value,bso_faturamento,_bso_provedor_value,bso_ramo&$filter=_bso_cliente_value eq "+ myId,
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: true,
            success: function (data, textStatus, xhr) {
                debugger
                var results = data;
                var vetor = []
                var vetorId = [];
                var vetorF = new Array();


                for (var i = 0; i < results.value.length; i++){
                    vetorF = {
                        bso_aniversario: results.value[i]["bso_aniversario@OData.Community.Display.V1.FormattedValue"],
                        bso_faturamento: results.value[i]["bso_faturamento@OData.Community.Display.V1.FormattedValue"],                                         
                        _bso_provedor_value_formatted : results.value[i]["_bso_provedor_value@OData.Community.Display.V1.FormattedValue"],                                                
                        bso_ramo_formatted: results.value[i]["bso_ramo@OData.Community.Display.V1.FormattedValue"], 
                        bso_mapeamento_dos_produtos_corporateid: results.value[i]["bso_mapeamento_dos_produtos_corporateid"]
                    }                    
                    vetor.push(vetorF);                          
                }
                bradescoseguros.corp_concorrentes.buildListaProdutos(vetor);
            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });

    },

    buildListaProdutos: function (linha) {
        debugger

        
        for (var i = 0; i < linha.length; i++)
        {
            if (typeof linha[i].bso_faturamento == "undefined")
                linha[i].bso_faturamento = "R$0,00";

            if (typeof linha[i].bso_ramo_formatted == "undefined")
                linha[i].bso_ramo_formatted = "";
             
            if (typeof linha[i]._bso_provedor_value_formatted == "undefined")
                linha[i]._bso_provedor_value_formatted = "";

            if (typeof linha[i].bso_aniversario == "undefined")
                linha[i].bso_aniversario = "";

            var tabela = "<tr class='trId' data-id='" + linha[i].bso_mapeamento_dos_produtos_corporateid + "'><td class='primeirovalor'><input type='checkbox'/></td>" +
                "<td><div>" + linha[i]._bso_provedor_value_formatted + "</div></td>" +
                "<td><div>" + linha[i].bso_ramo_formatted + "</div></td>" +
                "<td><div>" + linha[i].bso_faturamento + "</div></td>" +
                //"<td><div>" + linha[i].bso_mapeamento_dos_produtos_corporateid + "</div></td></tr>";       
                "<td><div>" + linha[i].bso_aniversario + "</div></td></tr>";                
            $("#minhaTable tbody").append(tabela);              
        }

        $('#minhaTable').DataTable({
            "searching": false,
            "lengthChange": false,
            "ordering": false
        });

        $('.tabela tr').click(function (event) {
            if (event.target.type !== 'checkbox') {
                $(':checkbox', this).trigger('click');
            }
        });

        $("input[type='checkbox']").change(function (e) {
            if ($(this).is(":checked")) {
                $(this).closest('tr').addClass("highlight_row");
            } else {
                $(this).closest('tr').removeClass("highlight_row");
            }
        });  

        $('.trId').dblclick(function (e) {
            debugger
            var Xrm = window.parent.Xrm;            
            var Guid = $($(e.currentTarget)[0]).attr("data-id");
            var windowOptions = {
                openInNewWindow: true
            };
            Xrm.Utility.openEntityForm("bso_mapeamento_dos_produtos_corporate", Guid, null, windowOptions);
        });
   
    }
}

$(document).ready(function () {
    debugger

    bradescoseguros.corp_concorrentes.obterOportunidade();


});