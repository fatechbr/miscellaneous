﻿var entity = "activity";

if (typeof (bradescoseguros) === "undefined") { bradescoseguros = {}; }
if (typeof (bradescoseguros.corp_activity) === "undefined") { bradescoseguros.corp_activity = {}; }

bradescoseguros.corp_activity = {
    onsave: function (event) {
        if (event.Mode == 5) //Close activity event
        {
            alert("teste");
            //you code to implement your logic

        }
    }
}