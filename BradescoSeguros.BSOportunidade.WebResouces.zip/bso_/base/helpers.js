var Helpers = {

    UrlApiCrm: function ()
    {
        return Xrm.Page.context.getClientUrl() + "/api/data/v8.2/";
    },

    UsuarioPossuiDireitoDeAcesso: function (nomeDireitoDeAcesso, usuarioid) {
        var roles = null;

        if (usuarioid != null) {
            var resultado = Helpers.Buscar("systemuserrolescollection?$filter=systemuserid eq " + usuarioid);
            var roles = new Array();
            for (var i = 0; i < resultado.length; i++) {
                roles.push(resultado[i].roleid);
            }
        }
        else
            roles = Xrm.Page.context.getUserRoles();

        if (roles != null) {
            for (var i = 0; i < roles.length; i++) {
                var role = Helpers.Buscar("roles?$filter=roleid eq " + roles[i]);
                if (role)
                    if (role[0].name.toUpperCase() == nomeDireitoDeAcesso.toUpperCase())
                        return true;
            }
        }

        return false;
    },

    ExecutarWorkflowSobDemanda: function (nomeWorkflow, nomeEntidade, idEntidade, async)
    {
        var resultado = "";
        var workflow = Helpers.Buscar("workflows?$filter=name eq '" + nomeWorkflow + "' and primaryentity eq '" + nomeEntidade + "' and statecode eq 1 and type eq 1");
        if (workflow)
        {
            var dados = {
                "EntityId": idEntidade.replace('{', '').replace('}', '')
            };
            resultado = Helpers.ExecutarAcao("workflows(" + workflow[0].workflowid + ")/Microsoft.Dynamics.CRM.ExecuteWorkflow", dados, async);
        } else
        {
            resultado = "Não foi possível encontrar o workflow";
        }
        return resultado;
    },

    //obter lista
    //var emailid = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
    //var email = Helpers.Buscar("emails?$select=_parentactivityid_value&$filter=activityid eq " + emailid);
    //var id = email[0].acitivityid;

    //obter único registro
    //var emailid = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
    //var email = Helpers.Buscar("emails("+ emailid+")");
    //var id = email.acitivityid;
    Buscar: function (query, nextLink, records)
    {
        var result = null;
        var resultOneRecord = null;
        var url = "";

        if (nextLink)
            url = nextLink;
        else
        {
            url = Helpers.UrlApiCrm() + query;
        }

        jQuery.ajax({
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: url,
            beforeSend: function (XMLHttpRequest)
            {
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=*");
            },
            success: function (data, textStatus, XmlHttpRequest)
            {
                if (data)
                {
                    if (data.value)
                    {
                        result = data.value;

                        if (data["@odata.nextLink"])
                            nextLink = data["@odata.nextLink"];
                        else
                            nextLink = null;
                    }
                    else
                    {
                        resultOneRecord = data;
                    }
                }
            },
            error: function (XmlHttpRequest, textStatus, errorThrown)
            {
                result = null;
            }
        });

        if (resultOneRecord)
        {
            return resultOneRecord;
        }

        if (result)
        {
            if (records)
            {
                for (var i = 0; i < result.length; i++)
                {
                    records.push(result[i]);
                }
            }
            else
            {
                records = [];
                for (var i = 0; i < result.length; i++)
                {
                    records.push(result[i]);
                }
            }

            if (nextLink)
                records = Helpers.RetrieveMultiple(query, nextLink, records);

            return records;
        }
    },

    //var visita = {};
    //visita.statecode = 2;
    //visita.statuscode = 3;
    //var id = Xrm.Page.data.entity.getId().substr(1, 36);
    //var query = "bso_visitacorporates(" + id + ")";
    //var retorno = Helpers.Atualizar(query, visita);
    Atualizar: function (query, dados)
    {
        var result = null;

        jQuery.ajax({
            type: "PATCH",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Helpers.UrlApiCrm() + query,
            async: false,
            data: window.JSON.stringify(dados),
            beforeSend: function (XMLHttpRequest)
            {
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "return=representation");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE");
            },
            success: function (data, textStatus, XmlHttpRequest)
            {
                result = null;
            },
            error: function (XmlHttpRequest, textStatus, errorThrown)
            {
                result = textStatus;
            }
        });

        return result;
    },

    //var data = { NumeroCEP: cep.replace("-", "").toString() };
    //var endereco = Helpers.ExecutarAcao("bso_buscarcep", data);
    ExecutarAcao: function (nomeProcesso, dados, async)
    {
        var resultado = "";

        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Helpers.UrlApiCrm() + nomeProcesso,
            async: async,
            data: dados != null ? window.JSON.stringify(dados) : null,
            beforeSend: function (req)
            {
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
            },
            success: function (data, textStatus, XmlHttpRequest)
            {
                resultado = data;

            },
            error: function (XmlHttpRequest, textStatus, errorThrown)
            {
                var parse = JSON.parse(XmlHttpRequest.responseText);
                resultado = parse.error.message;
            }
        });

        return resultado;
    },

    ChamarServico: function (url, method)
    {
        var servico = this;
        var parameter = "";
        var obj = new Object();
        obj.Success = true;
        obj.ReturnValue = null;

        servico.SetParameter = function (name, value)
        {
            parameter += '"' + name + '": "' + value + '",';
        }

        servico.Execute = function ()
        {
            jQuery.ajax({
                async: false,
                type: "POST",
                url: url + "/" + method,
                data: configureParameter(),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                processdata: true,
                beforeSend: function (XMLHttpRequest)
                {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest)
                {
                    obj.ReturnValue = data;
                },
                error: function (XmlHttpRequest, textStatus, errorThrown)
                {
                    alert("Falha na chamada do método:" + method);
                    obj.Success = false;
                }
            });
            return configureReturn(obj);
        }

        function configureReturn()
        {
            if (obj.ReturnValue == undefined || obj.ReturnValue == null)
                return obj;

            if (obj.ReturnValue.hasOwnProperty("d"))
                obj.ReturnValue = obj.ReturnValue.d;

            return obj;
        }

        function configureParameter()
        {
            parameter = parameter.length == 0 ? "," : parameter;
            return "{" + parameter.substr(0, parameter.length - 1) + "}";
        }
    },

    CreateLookup: function (id, name, type)
    {
        var value = new Array();
        value[0] = new Object();
        value[0].id = id;
        value[0].name = name;
        value[0].entityType = type;

        return value;
    },

    Mascara: function (nomeCampo, tipo)
    {
        var campo = Xrm.Page.getAttribute(nomeCampo);
        if (campo.getValue() != "undefined" && campo.getValue() != null)
        {
            var valor = campo.getValue().replace(/[^0-9]/g, "");

            switch (tipo)
            {
                case "cep":
                    valor = valor.substr(0, 5) + "-" + valor.substr(5, 3);
                    break;
                case "cpf":
                    valor = valor.substr(0, 3) + "." + valor.substr(3, 3) + "." + valor.substr(6, 3) + "-" + valor.substr(9, 2);
                    break;
                case "cnpj":
                    valor = valor.substr(0, 2) + "." + valor.substr(2, 3) + "." + valor.substr(5, 3) + "/" + valor.substr(8, 4) + "-" + valor.substr(12, 2);
                    break;
                case "telefone":
                    if (valor.length == 10)
                        valor = "(" + valor.substr(0, 2) + ") " + valor.substr(2, 4) + "-" + valor.substr(6, 4);
                    else if (valor.length == 11)
                        valor = "(" + valor.substr(0, 2) + ") " + valor.substr(2, 5) + "-" + valor.substr(7, 4);
                    break;

            }

            campo.setValue(valor);
        }
    },

    GetParameterByName: function (name)
    {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },

    VerificarCamposAlterados: function ()
    {
        var controles = Xrm.Page.getControl();
        for (var i = 0; i < controles.length; i++)
        {
            if (Xrm.Page.getAttribute(controles[i].getName()) != null)
                if (Xrm.Page.getAttribute(controles[i].getName()).getIsDirty())
                    alert(controles[i].getName())
        }
    },

    ObterDataComHorarioFinal: function (data)
    {
        if (data)
            return new Date(data.getFullYear(), data.getMonth(), data.getDate(), 23, 59, 59, 999);
        else
            return null;
    },

    DatasIguais: function (data1, data2)
    {
        var valor1 = null;
        var valor2 = null;
        if (data1)
            valor1 = data1.getFullYear() + "-" + data1.getMonth() + "-" + data1.getDate();
        if (data2)
            valor2 = data2.getFullYear() + "-" + data2.getMonth() + "-" + data2.getDate();
        return valor1 == valor2;
    },

    RemoverChaves: function (variavel)
    {
        return variavel.replace("{", "").replace("}", "");
    },

    //Helpers.PreencheEnderecoPorCEP("address1_postalcode", "address1_line1", "bso_numero", "address1_line3", "address1_city", "address1_stateorprovince", "address1_country");
    PreencheEnderecoPorCEP: function (cep, logradouro, numero, bairro, cidade, estado, pais)
    {
        Xrm.Page.getAttribute(logradouro).setValue(null);
        Xrm.Page.getAttribute(numero).setValue(null);
        Xrm.Page.getAttribute(bairro).setValue(null);
        Xrm.Page.getAttribute(cidade).setValue(null);
        Xrm.Page.getAttribute(estado).setValue(null);
        if (pais != null)
        {
            Xrm.Page.getAttribute(pais).setValue(null);
        }
        if (Xrm.Page.getAttribute(cep).getValue())
        {
            var cep = Xrm.Page.getAttribute(cep).getValue();
            var data = { NumeroCEP: cep.replace("-", "").toString() };
            var endereco = Helpers.ExecutarAcao("bso_buscarcep", data);
            if (endereco != null)
            {
                Xrm.Page.getAttribute(logradouro).setValue(endereco.Logradouro);
                Xrm.Page.getAttribute(bairro).setValue(endereco.Bairro);
                Xrm.Page.getAttribute(cidade).setValue(endereco.Cidade);
                Xrm.Page.getAttribute(estado).setValue(endereco.Estado);
                if (pais != null)
                {
                    Xrm.Page.getAttribute(pais).setValue("BRASIL");
                }
            }
        }
    },
};

if (typeof (SDK) == "undefined")
{ SDK = {}; }

SDK.DependentOptionSet = {};
SDK.DependentOptionSet.config = null;


SDK.DependentOptionSet.init = function (parameters)
{
    if (SDK.DependentOptionSet.config == null)
    {
        SDK.DependentOptionSet.config = parameters;
        SDK.DependentOptionSet.completeInitialization();
    }
};

SDK.DependentOptionSet.completeInitialization = function ()
{

    for (var i = 0; i < SDK.DependentOptionSet.config.length; i++)
    {
        var parentAttribute = Xrm.Page.getAttribute(SDK.DependentOptionSet.config[i].parent);
        var parentFieldValue = parentAttribute.getValue();
        if (parentFieldValue == null || parentFieldValue == -1)
        {
            var childAttribute = Xrm.Page.getAttribute(SDK.DependentOptionSet.config[i].child);
            childAttribute.setValue(null);
            childAttribute.controls.forEach(function (c) { c.setDisabled(true); });
        }
        else
        {
            parentAttribute.fireOnChange();
        }
    }
}

SDK.DependentOptionSet.filterDependentField = function (parentFieldParam, childFieldParam)
{

    for (var i = 0; i < SDK.DependentOptionSet.config.length; i++)
    {

        var dependentOptionSet = SDK.DependentOptionSet.config[i];

        if ((dependentOptionSet.parent == parentFieldParam) &&
            (dependentOptionSet.child == childFieldParam))
        {

            setTimeout(SDK.DependentOptionSet.filterOptions,
                100, parentFieldParam,
                childFieldParam,
                dependentOptionSet);
        }
    }
};

SDK.DependentOptionSet.filterOptions = function (parentFieldParam, childFieldParam, dependentOptionSet)
{

    var parentField = Xrm.Page.getAttribute(parentFieldParam);
    var parentFieldValue = parentField.getValue();
    var childField = Xrm.Page.getAttribute(childFieldParam);

    var currentChildFieldValue = childField.getValue();

    if (parentFieldValue == null || parentFieldValue == -1)
    {
        childField.setValue(null);
        childField.fireOnChange();
        childField.controls.forEach(function (c)
        {
            c.setDisabled(true);
        });

        return;
    }

    var validOptionValues = dependentOptionSet.options[parentFieldValue.toString()];

    childField.controls.forEach(function (c)
    {
        c.setDisabled(false);
        c.clearOptions();

        var childFieldAttribute = c.getAttribute();

        if (Xrm.Page.context.client.getClient() == "Mobile")
        {
            c.addOption({ text: "", value: -1 });
        }

        validOptionValues.forEach(function (optionValue)
        {
            var option = childFieldAttribute.getOption(parseInt(optionValue));

            c.addOption(option);
        })
    });

    if (currentChildFieldValue != null &&
        validOptionValues.indexOf(currentChildFieldValue.toString()) > -1)
    {
        childField.setValue(currentChildFieldValue);
    }
    else
    {

        childField.setValue(null);
        childField.fireOnChange();
    }
}
