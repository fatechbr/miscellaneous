﻿// UII_*.* Error Msgs 
var jsErr_InvalidName = "Geben Sie einen gültigen Namen ohne Sonderzeichen an."; 
var jsErr_InvalidExtnXml = "Die Erweiterungs-XML ist nicht ordnungsgemäß formatiert."; 
var jsErr_InvalidAutoXml = "Die Automatisierungs-XML ist nicht ordnungsgemäß formatiert."; 
var jsErr_InvalidWrkflowXml = "Die Workflow-XAML ist nicht ordnungsgemäß formatiert."; 
var jsErr_InvalidSeqNumber = "Geben Sie eine gültige Sequenznummer (zwischen 1 und 2147483647) an."; 
//End UII_*.* Error Msgs 
//UII_Common.js Msgs 
var jsErr_XmlLoad = "Ihr Browser ist nicht für die XML-Überprüfung geeignet."; 
var jsErr_Reason = "Fehlerursache: "; 
var jsErr_ErrorLine = "Fehlerzeile: "; 
//UII_Common.js Msgs 
