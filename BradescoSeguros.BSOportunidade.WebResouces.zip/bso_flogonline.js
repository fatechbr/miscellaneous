﻿/// <reference path="bso_scripts_common.js" />
var OPT_CANAL_REDE = 861500001;


var FLOGOnline = {

    OnLoad: function () {
        FLOGOnline.ObterCanalAtendimentoUsuario();
        if (GEM.Crm.Common.Methods.isCreateForm() == true) {
            FLOGOnline.ZerarValores("bso_valorsimpliempresa,bso_valorbilhete,bso_valorauto,bso_valoroutros,bso_valorsaude,bso_valorre,bso_valorvida,bso_valordentalpf,bso_valorprevidencia,bso_valordentalpj");
            FLOGOnline.ZerarValores("bso_quantidadesimpliempresa,bso_quantidadeoutros,bso_quantidadebilhete,bso_quantidadecartoesbs");
        }
        Xrm.Page.data.entity.addOnSave(FLOGOnline.OnSave);
        Xrm.Page.getAttribute("bso_producaodia").addOnChange(FLOGOnline.OnChangeProducao);
    },

    OnSave: function (evt) {
        var eventArgs = evt.getEventArgs();
        var listaProdutos = "bso_valorsimpliempresa,bso_valorbilhete,bso_valorauto,bso_valoroutros,bso_valorsaude,bso_valorre,bso_valorvida,bso_valordentalpf,bso_valorprevidencia,bso_valordentalpj,bso_quantidadesimpliempresa,bso_quantidadeoutros,bso_quantidadebilhete,bso_quantidadecartoesbs";
        if (FLOGOnline.PossuiProdutoPreenchido(listaProdutos) == false) {
            Xrm.Utility.alertDialog("Para que o cadastro seja salvo, é necessário preenhcer o valor ou quantidade em pelo menos um dos produtos.");
            eventArgs.preventDefault();
            return;
        } 
    },

    //Carrega guia de acordo com o Canal de Atendimento do usuário.
    ObterCanalAtendimentoUsuario: function () {
        var userId = Xrm.Page.context.getUserId();
        //Remove braces
        userId = userId.substr(1, 36);
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers(" + userId + ")?$select=bso_canal_atendimento_usuario", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    var bso_canaldeatendimento = result["bso_canal_atendimento_usuario"];
                    if (bso_canaldeatendimento != OPT_CANAL_REDE) {
                        GEM.Crm.Common.Methods.disableAllFields();
                    }
                } 
            }
        };
        req.send();
    },

    OnChangeProducao: function (){
        var assunto = Xrm.Page.getAttribute("subject");
        if (assunto) {
                GEM.Crm.Common.Functions.concatenateString("Produção do dia : ,- ,bso_producaodia", "subject");
        }
    },

    ZerarValores: function (listaCampos) {
        var campos = listaCampos.split(",");

        for (var i = 0; i < campos.length; i++) {
            var campo = Xrm.Page.getAttribute(campos[i]);

            if (campo) {
                campo.setValue(0);
            }
        }
    },

    PossuiProdutoPreenchido: function (listaCampos) {
        var campos = listaCampos.split(",");

        for (var i = 0; i < campos.length; i++) {
            var campo = Xrm.Page.getAttribute(campos[i]);

            if (campo) {
                if (campo.getValue() != 0) {
                    return true;
                }
            }
        }
        return false;
    }
}