﻿// UII_*.* Error Msgs 
var jsErr_InvalidName = "आपको बिना किसी विशिष्ट वर्ण का एक मान्य नाम और पासवर्ड प्रदान करना होगा."; 
var jsErr_InvalidExtnXml = "एक्सटेंशन XML सुस्वरूपित नहीं है"; 
var jsErr_InvalidAutoXml = "स्वचालन XML सुस्वरूपित नहीं है"; 
var jsErr_InvalidWrkflowXml = "कार्यप्रवाह XML सुस्वरूपित नहीं है"; 
var jsErr_InvalidSeqNumber = "आपको एक मान्य अनुक्रम क्रमांक देना होगा उसे 1 और 2147483647 के बीच होना चाहिए"; 
//End UII_*.* Error Msgs 
//UII_Common.js Msgs 
var jsErr_XmlLoad = "आपका ब्राउज़र XML सत्यापन को हैंडल नहीं कर सकता"; 
var jsErr_Reason = "त्रुटि का कारण: "; 
var jsErr_ErrorLine = "त्रुटि पंक्ति: "; 
//UII_Common.js Msgs 
