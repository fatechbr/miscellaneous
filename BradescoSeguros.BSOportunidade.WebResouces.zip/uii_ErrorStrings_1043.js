﻿// UII_*.* Error Msgs 
var jsErr_InvalidName = "U moet een geldige naam opgeven zonder speciale tekens"; 
var jsErr_InvalidExtnXml = "Extensies-XML heeft niet de juiste indeling"; 
var jsErr_InvalidAutoXml = "Automatisering-XML heeft niet de juiste indeling"; 
var jsErr_InvalidWrkflowXml = "Werkstroom-XAML heeft niet de juiste indeling"; 
var jsErr_InvalidSeqNumber = "U moet een geldig volgnummer opgeven tussen 1 en 2147483647"; 
//End UII_*.* Error Msgs 
//UII_Common.js Msgs 
var jsErr_XmlLoad = "Uw browser kan geen XML-validatie uitvoeren"; 
var jsErr_Reason = "Foutreden: "; 
var jsErr_ErrorLine = "Foutenregel: "; 
//UII_Common.js Msgs 
