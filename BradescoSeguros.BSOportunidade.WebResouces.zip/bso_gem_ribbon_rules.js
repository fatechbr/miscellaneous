﻿RibbonRules = {


    PossuiPermissaoAprovar: function () {
        var funcLikeAdm = "Sistema";
        var funcLikeSucom = "Sucursal";
        var funcEqSucom = "Superintendente Sucursal - Rede";
        var funcEqAdm = "Administrador do Sistema";

        if (RibbonRules.isCurrentUserMemberOfRole(funcEqSucom) == true
            || RibbonRules.isCurrentUserMemberOfRole(funcEqAdm) == true) {
            return true;
        } else {
            return false;
        }
    },

    isCurrentUserMemberOfRole: function (roleName) {

        var isMemberOfRole = false;

        var currentUserRoles = Xrm.Page.context.getUserRoles();

        for (var i = 0; i < currentUserRoles.length; i++) {
            var roleNameById=RibbonRules.ObterDireitoAcessoPorId(currentUserRoles[i]);
            if (roleName == roleNameById) {
                isMemberOfRole = true;
                break;
            }
        }
        return isMemberOfRole;
    },

    ObterDireitoAcessoPorId: function (roleId) {
        var name="";
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/roles(" + roleId + ")?$select=name", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var direitoAcesso = JSON.parse(this.response);
                    if (direitoAcesso) {
                        name = direitoAcesso["name"];
                    }
                } else {
                    console.log("Direito de Acesso nao encontrado");
                    return null;
                }
            }
        };
        req.send();
        return name;
    }
}