﻿// UII_*.* Error Msgs 
var jsErr_InvalidName = "‏‏يجب توفير اسم صالح دون أي حروف خاصة"; 
var jsErr_InvalidExtnXml = "لم يتم تكوين ملف XML للملحقات بشكلٍ صحيح"; 
var jsErr_InvalidAutoXml = "لم يتم تكوين ملف XML للأتمتة بشكلٍ صحيح"; 
var jsErr_InvalidWrkflowXml = "لم يتم تكوين ملف XAML لسير العمل بشكلٍ صحيح"; 
var jsErr_InvalidSeqNumber = "يجب إدخال رقم تسلسلي صالح بين 1 و2147483647"; 
//End UII_*.* Error Msgs 
//UII_Common.js Msgs 
var jsErr_XmlLoad = "يتعذر على المستعرض لديك معالجة التحقق من صحة ملف XML"; 
var jsErr_Reason = "سبب الخطأ: "; 
var jsErr_ErrorLine = "سطر الخطأ: "; 
//UII_Common.js Msgs 
