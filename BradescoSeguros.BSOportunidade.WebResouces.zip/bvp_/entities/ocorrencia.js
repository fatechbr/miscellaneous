var Ocorrencia = {
    OnLoad: function () {
        Xrm.Page.getAttribute("bvp_tipodesolicitao").addOnChange(Ocorrencia.OnChangeTipoDeSolicitacao);
    },
    OnChangeTipoDeSolicitacao: function () {
        if (Xrm.Page.getAttribute("bvp_tipodesolicitao").getValue() == 916380000) {//se for tipo Carteira
            Ocorrencia.FiltrarCampoTipoDeAcao();
        } else {
            Ocorrencia.RemoverFiltroDoCampoTipoDeAção();
        }
    },
    FiltrarCampoTipoDeAcao: function () {
        Xrm.Page.getControl("bvp_tipodeacao").addPreSearch(Ocorrencia.FiltroDoCampoTipoDeAcao);
    },
    RemoverFiltroDoCampoTipoDeAção: function () {
        Xrm.Page.getControl("bvp_tipodeacao").removePreSearch(Ocorrencia.FiltroDoCampoTipoDeAcao);
    },

    FiltroDoCampoTipoDeAcao: function () {
        var NomeDoTipoDeAcaoASerRemovido = "Portabilidade"
        var filter = " <filter type='and'><condition attribute='bvp_name' operator='ne' value='" + NomeDoTipoDeAcaoASerRemovido + "' /></filter>>";
        Xrm.Page.getControl("bvp_tipodeacao").addCustomFilter(filter, "bvp_tipodeacao");
    }
}