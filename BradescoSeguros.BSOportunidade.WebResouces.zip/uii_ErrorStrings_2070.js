﻿// UII_*.* Error Msgs 
var jsErr_InvalidName = "Tem de fornecer um Nome sem caracteres especiais"; 
var jsErr_InvalidExtnXml = "O XML de Extensões não está formado corretamente"; 
var jsErr_InvalidAutoXml = "O XML de Automatização não está formado corretamente"; 
var jsErr_InvalidWrkflowXml = "O XAML de Fluxo de Trabalho não está formado corretamente"; 
var jsErr_InvalidSeqNumber = "Tem de fornecer um Número de Sequência válido entre 1 e 2147483647"; 
//End UII_*.* Error Msgs 
//UII_Common.js Msgs 
var jsErr_XmlLoad = "O seu browser não suporta a validação de XML"; 
var jsErr_Reason = "Razão do Erro: "; 
var jsErr_ErrorLine = "Linha do Erro: "; 
//UII_Common.js Msgs 
