﻿// UII_*.* Error Msgs 
var jsErr_InvalidName = "Необходимо указать допустимое имя без использования специальных символов."; 
var jsErr_InvalidExtnXml = "Расширение XML сформировано неправильно"; 
var jsErr_InvalidAutoXml = "Автоматизация XML сформирована неправильно"; 
var jsErr_InvalidWrkflowXml = "Бизнес-процесс XAML сформирован неправильно"; 
var jsErr_InvalidSeqNumber = "Необходимо предоставить допустимую последовательность номеров от 1 до 2147483647"; 
//End UII_*.* Error Msgs 
//UII_Common.js Msgs 
var jsErr_XmlLoad = "Ваш браузер не может обработать проверку XML"; 
var jsErr_Reason = "Причина ошибки: "; 
var jsErr_ErrorLine = "Строка ошибки: "; 
//UII_Common.js Msgs 
